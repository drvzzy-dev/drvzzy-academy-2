import React, { useState } from 'react';
import { Trophy, Award, Lock, CheckCircle2, Star, Shield, ArrowUpRight } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { ProgressBar } from '../components/common/ProgressBar';
import { RANKS_DATA, DEMO_ACHIEVEMENTS } from '../data/initialData';
import { FighterProfile, Rank } from '../types/academy';
import { calculateLevelProgress, formatTechNumber } from '../utils/progression';

export interface ProgressionPageProps {
  fighter: FighterProfile;
  currentRank: Rank;
}

export const ProgressionPage: React.FC<ProgressionPageProps> = ({
  fighter,
  currentRank,
}) => {
  const [selectedRank, setSelectedRank] = useState<Rank>(currentRank);
  const progress = calculateLevelProgress(fighter.currentXp, fighter.currentLevel);

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="RPG PROGRESSION SYSTEM"
        title="8-RANK TIER LADDER & ACHIEVEMENTS"
        subtitle="Rank is not bought; it is forged across 24 levels of kinetic discipline. Each tier unlocks advanced tactical modules and sparring privileges."
        actions={
          <Badge variant="accent">TIER {currentRank.insignia} // {currentRank.name}</Badge>
        }
      />

      {/* Active Level & XP Overview */}
      <Card variant="accent-border" withCrosshairs>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div>
            <div className="font-mono-tech text-xs text-[#A3A3A3] mb-1">
              CURRENT STATUS
            </div>
            <div className="font-condensed text-4xl font-black uppercase text-[#F5F5F5]">
              LEVEL {fighter.currentLevel} // {currentRank.name}
            </div>
            <p className="text-xs text-[#CCCCCC] mt-1">
              {currentRank.title}
            </p>
          </div>

          <div className="md:col-span-2 space-y-2">
            <div className="flex justify-between items-baseline text-xs font-mono-tech">
              <span className="text-[#A3A3A3]">
                XP TO LEVEL {fighter.currentLevel + 1}
              </span>
              <span className="text-[#D7263D] font-bold">
                {formatTechNumber(progress.currentLevelXp)} / {formatTechNumber(progress.nextLevelXp)} XP ({progress.progressPercent}%)
              </span>
            </div>
            <ProgressBar value={progress.progressPercent} height="lg" variant="accent" showPercent={false} />
            <div className="flex justify-between text-[11px] font-mono-tech text-[#777777]">
              <span>TIER MIN: LVL {currentRank.minLevel}</span>
              <span>TIER MAX: LVL {currentRank.maxLevel}</span>
            </div>
          </div>
        </div>
      </Card>

      {/* The 8 Ranks Roadmap */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
            THE 8 PUGILISTIC RANKS
          </div>
          <span className="text-xs font-mono-tech text-[#777777]">
            CLICK A RANK TO INSPECT PRIVILEGES
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {RANKS_DATA.map((rank) => {
            const isCurrent = currentRank.id === rank.id;
            const isUnlocked = fighter.currentLevel >= rank.minLevel;
            const isSelected = selectedRank.id === rank.id;

            return (
              <div
                key={rank.id}
                onClick={() => setSelectedRank(rank)}
                className={`p-5 border transition-all cursor-pointer flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-[#191919] border-l-4 border-l-[#D7263D] border-[#404040] shadow-md'
                    : isSelected
                    ? 'bg-[#161616] border-[#D7263D]'
                    : isUnlocked
                    ? 'bg-[#141414] border-[#303030]'
                    : 'bg-[#0f0f0f] border-[#202020] opacity-80'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono-tech mb-2">
                    <span className="text-[#D7263D] font-bold">{rank.code}</span>
                    <span className="text-[#A3A3A3]">LVL {rank.minLevel}-{rank.maxLevel}</span>
                  </div>

                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="font-condensed text-3xl font-black text-[#F5F5F5]">
                      {rank.insignia}
                    </span>
                    <span className="font-condensed text-xl font-bold uppercase text-[#F5F5F5]">
                      {rank.name}
                    </span>
                  </div>

                  <div className="font-mono-tech text-[11px] text-[#A3A3A3] mb-2">
                    {rank.title}
                  </div>

                  <p className="text-xs text-[#888888] font-sans leading-relaxed">
                    {rank.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#262626] flex items-center justify-between text-[11px] font-mono-tech">
                  <span className="text-[#777777]">FOCUS:</span>
                  <span className="text-[#CCCCCC]">{rank.tacticalFocus}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Rank Focus Panel */}
      <div className="bg-[#141414] border border-[#303030] p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#262626] pb-3 mb-3">
          <div className="font-mono-tech text-xs text-[#D7263D]">
            SELECTED RANK SPECIFICATION: {selectedRank.insignia} // {selectedRank.name}
          </div>
          <span className="font-mono-tech text-xs text-[#A3A3A3]">
            LEVEL REQUIREMENTS: {selectedRank.minLevel} TO {selectedRank.maxLevel}
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
          <div>
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block mb-1">
              SYLLABUS FOCUS & RING PERMISSIONS:
            </span>
            <p className="text-[#CCCCCC] leading-relaxed">
              {selectedRank.description}
            </p>
          </div>
          <div>
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block mb-1">
              TACTICAL INTELLECT DISCIPLINE:
            </span>
            <p className="text-[#CCCCCC] leading-relaxed">
              {selectedRank.tacticalFocus}
            </p>
          </div>
        </div>
      </div>

      {/* Achievements Matrix */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
            ACHIEVEMENT DOSSIER ({DEMO_ACHIEVEMENTS.filter((a) => a.unlocked).length}/{DEMO_ACHIEVEMENTS.length} UNLOCKED)
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {DEMO_ACHIEVEMENTS.map((ach) => (
            <div
              key={ach.id}
              className={`p-4 border flex items-start gap-3.5 ${
                ach.unlocked
                  ? 'bg-[#161616] border-[#383838]'
                  : 'bg-[#101010] border-[#222222]'
              }`}
            >
              <div
                className={`w-10 h-10 border flex items-center justify-center flex-shrink-0 ${
                  ach.unlocked
                    ? 'bg-[#D7263D]/20 border-[#D7263D] text-[#D7263D]'
                    : 'bg-[#141414] border-[#262626] text-[#555555]'
                }`}
              >
                {ach.unlocked ? <CheckCircle2 className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono-tech">
                  <span className="text-[#A3A3A3]">{ach.category}</span>
                  <span className="text-[#D7263D] font-bold">+{ach.xpValue} XP</span>
                </div>
                <h4 className="font-condensed text-lg font-bold uppercase text-[#F5F5F5]">
                  {ach.title}
                </h4>
                <p className="text-xs text-[#888888]">
                  {ach.description}
                </p>

                <div className="pt-2">
                  <div className="flex justify-between text-[10px] font-mono-tech text-[#777777] mb-1">
                    <span>PROGRESS</span>
                    <span>{ach.progressPercent}%</span>
                  </div>
                  <ProgressBar
                    value={ach.progressPercent}
                    height="sm"
                    variant={ach.unlocked ? 'accent' : 'neutral'}
                    showPercent={false}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
