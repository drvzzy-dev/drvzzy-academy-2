import React, { useState, useEffect } from 'react';
import {
  Lock,
  CheckCircle2,
  ChevronRight,
  BookOpen,
  Award,
  Sparkles,
  Check,
  Search,
  Filter,
  Layers,
  ArrowRight,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/FormField';
import {
  CURRICULUM_PHASES,
  CURRICULUM_LEVELS,
  LESSON_CATALOG,
  STANDARDIZED_PILLARS,
  TECHNIQUE_CATALOG,
} from '../data/curriculumData';
import {
  CurriculumLevel,
  LessonItem,
  KnowledgeCheckSubmission,
} from '../types/academy';
import {
  isLessonUnlocked,
  getLessonStatus,
  calculateCurriculumProgress,
  calculatePhaseProgress,
  getNextRecommendedLesson,
  filterLessons,
} from '../utils/curriculum';
import { formatTechNumber } from '../utils/progression';
import { LessonDetailModal } from '../components/curriculum/LessonDetailModal';

export interface AcademyPageProps {
  completedLevelIds?: number[];
  completedLessonIds?: string[];
  inProgressLessonIds?: string[];
  knowledgeCheckResults?: Record<string, KnowledgeCheckSubmission>;
  onCompleteLevel?: (level: CurriculumLevel) => void;
  onCompleteLesson?: (lessonId: string, reflection?: string) => void;
  onSaveKnowledgeCheck?: (lessonId: string, submission: KnowledgeCheckSubmission) => void;
  onNavigateToTechnique?: (techniqueId: string) => void;
  externalSelectedLessonId?: string | null;
  onClearExternalLessonId?: () => void;
}

export const AcademyPage: React.FC<AcademyPageProps> = ({
  completedLevelIds = [],
  completedLessonIds = [],
  inProgressLessonIds = [],
  knowledgeCheckResults = {},
  onCompleteLevel,
  onCompleteLesson,
  onSaveKnowledgeCheck,
  onNavigateToTechnique,
  externalSelectedLessonId,
  onClearExternalLessonId,
}) => {
  const [selectedPhase, setSelectedPhase] = useState<number | 'all'>('all');
  const [selectedPillar, setSelectedPillar] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'available' | 'completed' | 'locked'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active Lesson for Modal
  const [activeLesson, setActiveLesson] = useState<LessonItem | null>(null);

  // If external lesson is requested (e.g. from technique or dashboard)
  useEffect(() => {
    if (externalSelectedLessonId) {
      const found = LESSON_CATALOG.find((l) => l.id === externalSelectedLessonId);
      if (found) {
        setActiveLesson(found);
      }
      if (onClearExternalLessonId) onClearExternalLessonId();
    }
  }, [externalSelectedLessonId, onClearExternalLessonId]);

  const curriculumProgress = calculateCurriculumProgress(completedLessonIds, LESSON_CATALOG);
  const nextLesson = getNextRecommendedLesson(completedLessonIds, LESSON_CATALOG);

  // Filter lessons based on active controls
  const filteredLessons = filterLessons(
    LESSON_CATALOG,
    completedLessonIds,
    inProgressLessonIds,
    {
      query: searchQuery,
      phase: selectedPhase,
      pillar: selectedPillar,
      difficulty: selectedDifficulty,
      status: selectedStatus,
    }
  );

  const getPrerequisiteTitles = (lesson: LessonItem): string[] => {
    return lesson.prerequisiteLessonIds.map((id) => {
      const match = LESSON_CATALOG.find((l) => l.id === id);
      return match ? match.title : id;
    });
  };

  const handleOpenLesson = (lesson: LessonItem) => {
    setActiveLesson(lesson);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="ACADEMY CURRICULUM ARCHITECTURE"
        title="24-LEVEL BOXING EDUCATION BLUEPRINT"
        subtitle="A disciplined five-phase curriculum progressing from novice bio-mechanics to grandmaster ring command. Every level is connected to the six standardized training pillars."
        actions={
          <div className="flex items-center gap-2">
            <Badge variant="accent">5 PHASES</Badge>
            <Badge variant="neutral">{curriculumProgress.percent}% ACADEMY PROGRESS</Badge>
          </div>
        }
      />

      {/* Hero Overview Card: Progress & Next Recommended Lesson */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Progress Bar & Stats (7 cols) */}
        <div className="lg:col-span-7 bg-[#141414] border border-[#303030] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold tracking-wider">
                CURRICULUM COMPLETION AUDIT
              </span>
              <span className="font-mono-tech text-xs text-[#A3A3A3]">
                {curriculumProgress.completedCount} OF {curriculumProgress.totalLessons} LESSONS COMPLETED
              </span>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full h-3 bg-[#1e1e1e] border border-[#333333] mb-4 overflow-hidden">
              <div
                className="h-full bg-[#D7263D] transition-all duration-300"
                style={{ width: `${curriculumProgress.percent}%` }}
              />
            </div>

            {/* Phase-by-Phase Mini Grid */}
            <div className="grid grid-cols-5 gap-2 pt-2 border-t border-[#262626]">
              {CURRICULUM_PHASES.map((p) => {
                const phaseStats = calculatePhaseProgress(p.phaseNumber, completedLessonIds, LESSON_CATALOG);
                return (
                  <div key={p.phaseNumber} className="text-center font-mono-tech">
                    <div className="text-[10px] text-[#777777] uppercase">P-{p.phaseNumber}</div>
                    <div className="text-xs font-bold text-[#F5F5F5]">{phaseStats.percent}%</div>
                    <div className="text-[9px] text-[#555555]">
                      {phaseStats.completedInPhase}/{phaseStats.totalInPhase}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#262626] flex items-center justify-between text-xs font-mono-tech text-[#888888]">
            <span>
              TOTAL XP EARNED FROM SYLLABUS:{' '}
              <strong className="text-[#F5F5F5]">{formatTechNumber(curriculumProgress.earnedXp)} XP</strong>
            </span>
            <span>
              AVAILABLE: <strong className="text-[#A3A3A3]">{formatTechNumber(curriculumProgress.totalXpAvailable)} XP</strong>
            </span>
          </div>
        </div>

        {/* Next Recommended Lesson Card (5 cols) */}
        <div className="lg:col-span-5 bg-[#171717] border-l-4 border-l-[#D7263D] border border-[#303030] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-mono-tech mb-2">
              <span className="text-[#D7263D] font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> RECOMMENDED NEXT PROTOCOL
              </span>
              {nextLesson && (
                <Badge variant="accent" size="sm">
                  LEVEL {nextLesson.levelNumber}
                </Badge>
              )}
            </div>

            {nextLesson ? (
              <>
                <h3 className="font-condensed text-xl font-black uppercase text-[#F5F5F5] tracking-wide mb-1">
                  {nextLesson.title}
                </h3>
                <p className="text-xs text-[#A3A3A3] line-clamp-2 font-sans mb-3">
                  {nextLesson.description}
                </p>
                <div className="flex flex-wrap gap-1.5 font-mono-tech text-[10px] text-[#777777]">
                  <span>EST. {nextLesson.estimatedDurationMin} MIN</span>
                  <span>•</span>
                  <span>+{nextLesson.xpReward} XP</span>
                  <span>•</span>
                  <span>{nextLesson.difficulty}</span>
                </div>
              </>
            ) : (
              <div className="py-4 text-center">
                <p className="font-condensed text-lg text-[#10B981] uppercase font-bold">
                  ALL CURRICULUM LESSONS COMPLETED
                </p>
                <p className="text-xs text-[#777777] font-mono-tech mt-1">
                  Grandmaster status achieved. Maintain cadence through Training Pillars.
                </p>
              </div>
            )}
          </div>

          {nextLesson && (
            <div className="mt-4 pt-3 border-t border-[#262626]">
              <Button
                variant="primary"
                size="sm"
                fullWidth
                rightIcon={<ArrowRight className="w-4 h-4" />}
                onClick={() => handleOpenLesson(nextLesson)}
              >
                OPEN NEXT LESSON
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Phase Selection Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-[#303030] pb-3">
        <button
          onClick={() => setSelectedPhase('all')}
          className={`px-3 py-1.5 font-mono-tech text-xs uppercase tracking-wider border cursor-pointer ${
            selectedPhase === 'all'
              ? 'bg-[#D7263D] text-[#F5F5F5] border-[#D7263D] font-bold'
              : 'bg-[#141414] text-[#A3A3A3] border-[#303030] hover:text-[#F5F5F5]'
          }`}
        >
          ALL 24 LEVELS ({LESSON_CATALOG.length} LESSONS)
        </button>
        {CURRICULUM_PHASES.map((phase) => (
          <button
            key={phase.phaseNumber}
            onClick={() => setSelectedPhase(phase.phaseNumber)}
            className={`px-3 py-1.5 font-mono-tech text-xs uppercase tracking-wider border cursor-pointer ${
              selectedPhase === phase.phaseNumber
                ? 'bg-[#D7263D] text-[#F5F5F5] border-[#D7263D] font-bold'
                : 'bg-[#141414] text-[#A3A3A3] border-[#303030] hover:text-[#F5F5F5]'
            }`}
          >
            {phase.romanId}: LVL {phase.levelRange[0]}-{phase.levelRange[1]}
          </button>
        ))}
      </div>

      {/* Multi-Filter & Search Bar */}
      <div className="bg-[#121212] border border-[#2b2b2b] p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        {/* Dropdowns */}
        <div className="flex flex-wrap gap-2">
          {/* Pillar Filter */}
          <select
            value={selectedPillar}
            onChange={(e) => setSelectedPillar(e.target.value)}
            className="bg-[#181818] border border-[#333333] px-2.5 py-1.5 font-mono-tech text-xs text-[#CCCCCC] cursor-pointer"
          >
            <option value="all">ALL TRAINING PILLARS</option>
            {STANDARDIZED_PILLARS.map((p) => (
              <option key={p.id} value={p.name}>
                {p.name}
              </option>
            ))}
          </select>

          {/* Difficulty Filter */}
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-[#181818] border border-[#333333] px-2.5 py-1.5 font-mono-tech text-xs text-[#CCCCCC] cursor-pointer"
          >
            <option value="all">ALL DIFFICULTIES</option>
            <option value="Novice">Novice</option>
            <option value="Fundamental">Fundamental</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
            <option value="Mastery">Mastery</option>
          </select>

          {/* Completion Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as any)}
            className="bg-[#181818] border border-[#333333] px-2.5 py-1.5 font-mono-tech text-xs text-[#CCCCCC] cursor-pointer"
          >
            <option value="all">ALL STATUSES</option>
            <option value="available">Available / In Progress</option>
            <option value="completed">Completed Only</option>
            <option value="locked">Prerequisite Locked</option>
          </select>
        </div>

        {/* Search Input */}
        <div className="w-full md:w-72">
          <Input
            placeholder="SEARCH LESSONS OR TOPICS..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Active Phase Overview Banner */}
      {selectedPhase !== 'all' && (
        <div className="bg-[#161616] border-l-4 border-l-[#D7263D] border border-[#303030] p-5">
          {(() => {
            const p = CURRICULUM_PHASES.find((cp) => cp.phaseNumber === selectedPhase)!;
            const pStats = calculatePhaseProgress(p.phaseNumber, completedLessonIds, LESSON_CATALOG);
            return (
              <div>
                <div className="flex items-center justify-between font-mono-tech text-xs mb-1">
                  <span className="text-[#D7263D] uppercase tracking-widest font-bold">
                    // {p.romanId} BLUEPRINT: {p.subtitle}
                  </span>
                  <span className="text-[#A3A3A3]">
                    PHASE PROGRESS: {pStats.completedInPhase} / {pStats.totalInPhase} ({pStats.percent}%)
                  </span>
                </div>
                <h2 className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]">
                  {p.title}
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 max-w-3xl">
                  {p.description}
                </p>
                <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-[#262626]">
                  {p.coreThemes.map((theme, i) => (
                    <span
                      key={i}
                      className="font-mono-tech text-[10px] bg-[#1a1a1a] border border-[#333333] px-2 py-0.5 text-[#CCCCCC]"
                    >
                      • {theme}
                    </span>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Filtered Lessons List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono-tech text-xs text-[#777777] uppercase">
            DISPLAYING {filteredLessons.length} MATCHING SYLLABUS LESSONS
          </span>
          {(selectedPhase !== 'all' ||
            selectedPillar !== 'all' ||
            selectedDifficulty !== 'all' ||
            selectedStatus !== 'all' ||
            searchQuery) && (
            <button
              onClick={() => {
                setSelectedPhase('all');
                setSelectedPillar('all');
                setSelectedDifficulty('all');
                setSelectedStatus('all');
                setSearchQuery('');
              }}
              className="text-xs font-mono-tech text-[#D7263D] hover:underline cursor-pointer"
            >
              RESET ALL FILTERS
            </button>
          )}
        </div>

        {filteredLessons.length === 0 ? (
          <div className="bg-[#141414] border border-[#2b2b2b] p-8 text-center space-y-2">
            <p className="font-condensed text-xl text-[#F5F5F5] uppercase font-bold">
              NO MATCHING LESSONS FOUND
            </p>
            <p className="text-xs font-mono-tech text-[#777777]">
              Adjust your search keywords, pillar filters, or status selections.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLessons.map((lesson) => {
              const isCompleted = completedLessonIds.includes(lesson.id);
              const isUnlocked = isLessonUnlocked(lesson.id, completedLessonIds, LESSON_CATALOG);
              const status = getLessonStatus(
                lesson.id,
                completedLessonIds,
                inProgressLessonIds,
                LESSON_CATALOG
              );
              const prereqTitles = getPrerequisiteTitles(lesson);

              return (
                <div
                  key={lesson.id}
                  className={`p-5 border transition-all relative flex flex-col justify-between ${
                    isCompleted
                      ? 'bg-[#131d15] border-[#224426]'
                      : status === 'in_progress'
                      ? 'bg-[#1a1715] border-l-4 border-l-[#F59E0B] border-[#383025]'
                      : isUnlocked
                      ? 'bg-[#181818] border-l-4 border-l-[#D7263D] border-[#383838] shadow-md hover:border-[#4d4d4d]'
                      : 'bg-[#111111] border-[#242424] opacity-75'
                  }`}
                >
                  <div>
                    {/* Top Status Header */}
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono-tech text-xs text-[#D7263D] font-bold">
                        LVL {lesson.levelNumber < 10 ? `0${lesson.levelNumber}` : lesson.levelNumber} // P-{lesson.phaseNumber}
                      </span>

                      {isCompleted ? (
                        <span className="flex items-center gap-1 font-mono-tech text-[10px] text-[#34D399] font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5" /> COMPLETED
                        </span>
                      ) : status === 'in_progress' ? (
                        <Badge variant="accent" hasDot size="sm">
                          IN PROGRESS
                        </Badge>
                      ) : isUnlocked ? (
                        <Badge variant="neutral" size="sm">
                          AVAILABLE
                        </Badge>
                      ) : (
                        <span className="flex items-center gap-1 font-mono-tech text-[10px] text-[#666666]">
                          <Lock className="w-3 h-3" /> LOCKED
                        </span>
                      )}
                    </div>

                    <h3 className="font-condensed text-xl font-bold uppercase tracking-wide text-[#F5F5F5] leading-snug mb-1">
                      {lesson.title}
                    </h3>
                    <p className="text-xs text-[#888888] font-sans line-clamp-2 mb-3">
                      {lesson.description}
                    </p>

                    {/* Pillar & Difficulty Meta */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {lesson.pillars.slice(0, 1).map((p, idx) => (
                        <span
                          key={idx}
                          className="font-mono-tech text-[10px] bg-[#0c0c0c] text-[#A3A3A3] px-1.5 py-0.5 border border-[#262626]"
                        >
                          {p}
                        </span>
                      ))}
                      <Badge variant="muted" size="sm">
                        {lesson.difficulty}
                      </Badge>
                    </div>

                    {/* Prerequisite warning note if locked */}
                    {!isUnlocked && prereqTitles.length > 0 && (
                      <div className="p-2 bg-[#181112] border border-[#3b1c21] text-[10px] font-mono-tech text-[#F87171] mb-2">
                        REQUIRES: {prereqTitles.join(', ')}
                      </div>
                    )}
                  </div>

                  {/* Card Footer Actions */}
                  <div className="mt-4 pt-3 border-t border-[#262626] flex items-center justify-between">
                    <div className="font-mono-tech text-[11px] text-[#777777]">
                      {lesson.estimatedDurationMin} MIN •{' '}
                      <span className="text-[#CCCCCC]">+{lesson.xpReward} XP</span>
                    </div>

                    <Button
                      variant={isCompleted ? 'secondary' : isUnlocked ? 'primary' : 'outline'}
                      size="sm"
                      onClick={() => handleOpenLesson(lesson)}
                    >
                      {isCompleted ? 'REVIEW' : isUnlocked ? 'STUDY LESSON' : 'EXAMINE'}
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Lesson Detail Modal */}
      {activeLesson && (
        <LessonDetailModal
          lesson={activeLesson}
          isOpen={Boolean(activeLesson)}
          onClose={() => setActiveLesson(null)}
          isUnlocked={isLessonUnlocked(activeLesson.id, completedLessonIds, LESSON_CATALOG)}
          isCompleted={completedLessonIds.includes(activeLesson.id)}
          prerequisiteTitles={getPrerequisiteTitles(activeLesson)}
          existingSubmission={knowledgeCheckResults[activeLesson.id]}
          onCompleteLesson={(id, reflection) => {
            if (onCompleteLesson) {
              onCompleteLesson(id, reflection);
            }
          }}
          onSaveKnowledgeCheck={onSaveKnowledgeCheck}
          onOpenRelatedTechnique={(techId) => {
            setActiveLesson(null);
            if (onNavigateToTechnique) onNavigateToTechnique(techId);
          }}
          allTechniques={TECHNIQUE_CATALOG}
          allLessons={LESSON_CATALOG}
        />
      )}
    </div>
  );
};
