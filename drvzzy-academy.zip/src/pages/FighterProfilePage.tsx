import React, { useState } from 'react';
import { User, Shield, Flame, Activity, Edit3, Check, Save } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Input, Select } from '../components/common/FormField';
import { FighterProfile, Rank, StanceType, OnboardingProfile } from '../types/academy';

export interface FighterProfilePageProps {
  fighter: FighterProfile;
  currentRank: Rank;
  onboarding?: OnboardingProfile | null;
  onUpdateFighter: (updated: Partial<FighterProfile>) => void;
  onOpenOnboarding?: () => void;
}

export const FighterProfilePage: React.FC<FighterProfilePageProps> = ({
  fighter,
  currentRank,
  onboarding,
  onUpdateFighter,
  onOpenOnboarding,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [callsign, setCallsign] = useState(fighter.callsign);
  const [fullName, setFullName] = useState(fighter.fullName);
  const [stance, setStance] = useState<StanceType>(fighter.stance);
  const [weightClass, setWeightClass] = useState(fighter.weightClass);
  const [reachInches, setReachInches] = useState(fighter.reachInches);
  const [heightCm, setHeightCm] = useState(fighter.heightCm);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateFighter({
      callsign,
      fullName,
      stance,
      weightClass,
      reachInches: Number(reachInches),
      heightCm: Number(heightCm),
    });
    setIsEditing(false);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="FIGHTER IDENTIFICATION"
        title="ACADEMY FIGHTER DOSSIER"
        subtitle="Individual biometric profile, mechanical stance specialization, and certified academic credentials."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {onOpenOnboarding && (
              <Button
                variant="outline"
                size="md"
                onClick={onOpenOnboarding}
              >
                {onboarding ? 'EDIT ONBOARDING PROFILE' : 'START ONBOARDING'}
              </Button>
            )}
            <Button
              variant={isEditing ? 'outline' : 'primary'}
              size="md"
              leftIcon={isEditing ? <Check className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? 'CANCEL EDITING' : 'EDIT DOSSIER'}
            </Button>
          </div>
        }
      />

      {savedNotice && (
        <div className="bg-[#122416] border border-[#1b4324] text-[#34D399] p-3 text-xs font-mono-tech flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>FIGHTER DOSSIER COMMITTED TO ACADEMY DATABASE.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Fighter Physical ID Card (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#141414] border border-[#303030] p-6 text-center space-y-4 relative overflow-hidden">
            <div className="absolute top-2 left-2 text-[#444444] font-mono-tech text-[9px]">
              CERTIFIED SEC-A //
            </div>
            <div className="absolute top-2 right-2 text-[#444444] font-mono-tech text-[9px]">
              ID: {fighter.id}
            </div>

            {/* Profile Avatar Frame */}
            <div className="w-24 h-24 mx-auto bg-[#1b1b1b] border-2 border-[#D7263D] flex items-center justify-center text-[#D7263D] font-condensed font-black text-4xl">
              {fighter.callsign.substring(0, 2)}
            </div>

            <div>
              <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
                CALLSIGN
              </div>
              <h2 className="font-condensed text-3xl font-black uppercase text-[#F5F5F5] tracking-wide">
                {fighter.callsign}
              </h2>
              <div className="text-xs text-[#A3A3A3] font-sans">
                {fighter.fullName}
              </div>
            </div>

            <div className="pt-2 flex flex-wrap justify-center gap-2">
              <Badge variant="accent">{fighter.stance}</Badge>
              <Badge variant="neutral">{currentRank.name} (LVL {fighter.currentLevel})</Badge>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-4 border-t border-[#262626] font-mono-tech text-xs text-left">
              <div className="p-2.5 bg-[#0e0e0e] border border-[#222222]">
                <span className="text-[#666666] block text-[10px]">WEIGHT CLASS</span>
                <span className="text-[#CCCCCC]">{fighter.weightClass.split('(')[0].trim()}</span>
              </div>
              <div className="p-2.5 bg-[#0e0e0e] border border-[#222222]">
                <span className="text-[#666666] block text-[10px]">REACH</span>
                <span className="text-[#CCCCCC]">{fighter.reachInches} INCHES</span>
              </div>
              <div className="p-2.5 bg-[#0e0e0e] border border-[#222222]">
                <span className="text-[#666666] block text-[10px]">HEIGHT</span>
                <span className="text-[#CCCCCC]">{fighter.heightCm} CM</span>
              </div>
              <div className="p-2.5 bg-[#0e0e0e] border border-[#222222]">
                <span className="text-[#666666] block text-[10px]">SAFETY CLEARANCE</span>
                <span className="text-[#10B981] font-bold">VERIFIED</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Detailed Dossier Form / Details (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <Card
            variant="surface"
            headerBar={
              <>
                <span>BIOMETRIC & ACADEMIC CREDENTIALS</span>
                <span className="text-[#A3A3A3]">SERIAL: {fighter.id}</span>
              </>
            }
          >
            {isEditing ? (
              <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <Input
                    label="FIGHTER FULL NAME"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                  <Input
                    label="CALLSIGN / RING MONIKER"
                    value={callsign}
                    onChange={(e) => setCallsign(e.target.value)}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <Select
                    label="COMBAT STANCE"
                    value={stance}
                    onChange={(e) => setStance(e.target.value as StanceType)}
                    options={[
                      { value: 'Orthodox', label: 'Orthodox (Left Lead)' },
                      { value: 'Southpaw', label: 'Southpaw (Right Lead)' },
                      { value: 'Switch', label: 'Switch Hitter (Ambidextrous)' },
                    ]}
                  />
                  <Input
                    label="WEIGHT CLASS"
                    value={weightClass}
                    onChange={(e) => setWeightClass(e.target.value)}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <Input
                    label="REACH (INCHES)"
                    type="number"
                    value={reachInches}
                    onChange={(e) => setReachInches(Number(e.target.value))}
                    required
                  />
                  <Input
                    label="HEIGHT (CM)"
                    type="number"
                    value={heightCm}
                    onChange={(e) => setHeightCm(Number(e.target.value))}
                    required
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3 border-t border-[#262626]">
                  <Button variant="ghost" size="sm" type="button" onClick={() => setIsEditing(false)}>
                    CANCEL
                  </Button>
                  <Button variant="primary" size="sm" type="submit" leftIcon={<Save className="w-4 h-4" />}>
                    SAVE CHANGES
                  </Button>
                </div>
              </form>
            ) : (
              <div className="space-y-5">
                <div className="space-y-2">
                  <div className="font-mono-tech text-xs text-[#777777] uppercase">
                    PRIMARY BIOMECHANICAL STANCE & AXIS
                  </div>
                  <p className="text-sm text-[#E0E0E0] leading-relaxed">
                    Fighting out of <strong className="text-[#D7263D]">{fighter.stance}</strong> stance. Center of gravity anchored at 55% rear leg, 45% lead leg with chin aligned inside the lead clavicle pocket.
                  </p>
                </div>

                <div className="space-y-2 border-t border-[#262626] pt-4">
                  <div className="font-mono-tech text-xs text-[#777777] uppercase">
                    ACADEMY SPECIALIZATION TRACK
                  </div>
                  <p className="text-sm text-[#CCCCCC]">
                    {fighter.primaryFocus}
                  </p>
                </div>

                <div className="space-y-2 border-t border-[#262626] pt-4">
                  <div className="font-mono-tech text-xs text-[#777777] uppercase">
                    DISCIPLINARY RECORD & LOGGED TIME
                  </div>
                  <div className="grid grid-cols-3 gap-2 font-mono-tech text-xs">
                    <div className="p-3 bg-[#121212] border border-[#2b2b2b]">
                      <span className="text-[#666666] block text-[10px]">ENROLLED</span>
                      <span className="text-[#F5F5F5]">{fighter.joinedDate}</span>
                    </div>
                    <div className="p-3 bg-[#121212] border border-[#2b2b2b]">
                      <span className="text-[#666666] block text-[10px]">TOTAL ROUNDS</span>
                      <span className="text-[#F5F5F5]">{fighter.totalRoundsLogged}</span>
                    </div>
                    <div className="p-3 bg-[#121212] border border-[#2b2b2b]">
                      <span className="text-[#666666] block text-[10px]">TOTAL HOURS</span>
                      <span className="text-[#F5F5F5]">{fighter.totalHoursTrained}H</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};
