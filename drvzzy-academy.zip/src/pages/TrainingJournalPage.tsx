import React, { useState } from 'react';
import { Plus, ScrollText, Calendar, Dumbbell, Award, Flame, Filter, Trash2 } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { EmptyState } from '../components/common/EmptyState';
import { Modal } from '../components/common/Modal';
import { Input, Select, Textarea } from '../components/common/FormField';
import { TRAINING_PILLARS } from '../data/initialData';
import { JournalSession } from '../types/academy';

export interface TrainingJournalPageProps {
  sessions?: JournalSession[];
  onSessionLogged?: (session: JournalSession) => void;
}

export const TrainingJournalPage: React.FC<TrainingJournalPageProps> = ({
  sessions = [],
  onSessionLogged,
}) => {
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  // Form State
  const [sessionType, setSessionType] = useState<JournalSession['sessionType']>('Shadowboxing');
  const [rounds, setRounds] = useState<number>(6);
  const [intensity, setIntensity] = useState<JournalSession['intensity']>('Moderate Cadence');
  const [focusPillar, setFocusPillar] = useState<string>('Footwork & Stance');
  const [notes, setNotes] = useState<string>('');
  const [drillsInput, setDrillsInput] = useState<string>('Pendulum Steps, Double-Jab Slip');

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    const newEntry: JournalSession = {
      id: `sess-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase(),
      sessionType,
      rounds: Number(rounds),
      roundMinutes: 3,
      intensity,
      focusPillar,
      notes: notes || 'Pugilistic session completed with disciplined form.',
      drillsCompleted: drillsInput.split(',').map((d) => d.trim()).filter(Boolean),
      xpEarned: Number(rounds) * 25,
    };

    if (onSessionLogged) {
      onSessionLogged(newEntry);
    }
    setIsLogModalOpen(false);
    setNotes('');
  };

  const totalRoundsLogged = sessions.reduce((acc, s) => acc + s.rounds, 0);
  const totalXpEarned = sessions.reduce((acc, s) => acc + s.xpEarned, 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="DISCIPLINE LEDGER"
        title="TRAINING JOURNAL & ROUND LOG"
        subtitle="Every round thrown, slipped, and absorbed must be accounted for. Consistency and honest technical reflection build champions."
        actions={
          <Button
            variant="primary"
            size="md"
            leftIcon={<Plus className="w-4 h-4" />}
            onClick={() => setIsLogModalOpen(true)}
          >
            LOG TRAINING SESSION
          </Button>
        }
      />

      {/* Aggregate Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card variant="surface" withCrosshairs>
          <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-1">
            <span>TOTAL ROUNDS IN LEDGER</span>
            <Dumbbell className="w-4 h-4 text-[#D7263D]" />
          </div>
          <div className="font-condensed text-4xl font-black text-[#F5F5F5]">
            {totalRoundsLogged}
          </div>
          <div className="text-[11px] font-mono-tech text-[#777777] mt-1">
            ACROSS {sessions.length} VERIFIED SESSIONS
          </div>
        </Card>

        <Card variant="surface" withCrosshairs>
          <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-1">
            <span>XP EARNED VIA TRAINING</span>
            <Award className="w-4 h-4 text-[#D7263D]" />
          </div>
          <div className="font-condensed text-4xl font-black text-[#D7263D]">
            +{totalXpEarned}
          </div>
          <div className="text-[11px] font-mono-tech text-[#777777] mt-1">
            REAL CUMULATIVE REPUTATION
          </div>
        </Card>

        <Card variant="surface" withCrosshairs>
          <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-1">
            <span>DATA STORAGE LEDGER</span>
            <span className="w-2 h-2 bg-[#10B981]" />
          </div>
          <div className="font-condensed text-2xl font-bold uppercase text-[#F5F5F5] mt-1">
            LOCAL PERSISTENCE
          </div>
          <div className="text-[10px] font-mono-tech text-[#777777] mt-1">
            SYNCHRONIZED WITH DASHBOARD
          </div>
        </Card>
      </div>

      {/* Main Journal Sessions List or Empty State */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
            RECORDED SESSIONS ({sessions.length})
          </div>
        </div>

        {sessions.length === 0 ? (
          <EmptyState
            title="TRAINING LEDGER IS CURRENTLY BLANK"
            description="No rounds or sparring notes have been entered. Logging each workout calculates your XP progression, reinforces technical cues, and triggers milestone achievements."
            actionLabel="RECORD YOUR FIRST ROUND"
            onAction={() => setIsLogModalOpen(true)}
            icon="workout"
          />
        ) : (
          <div className="space-y-3">
            {sessions.map((session) => (
              <div
                key={session.id}
                className="bg-[#141414] border border-[#303030] p-5 hover:border-[#454545] transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#242424] pb-3 mb-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono-tech text-xs text-[#A3A3A3] bg-[#0c0c0c] px-2 py-0.5 border border-[#202020]">
                      {session.date}
                    </span>
                    <Badge variant="accent">{session.sessionType}</Badge>
                    <Badge variant="neutral">{session.intensity}</Badge>
                  </div>
                  <div className="font-mono-tech text-xs text-[#D7263D] font-bold">
                    +{session.xpEarned} XP GAINED
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <h3 className="font-condensed text-xl font-bold uppercase text-[#F5F5F5]">
                      {session.rounds} Rounds (3 Min) • {session.focusPillar}
                    </h3>
                  </div>

                  <p className="text-xs sm:text-sm text-[#CCCCCC] font-sans leading-relaxed">
                    "{session.notes}"
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {session.drillsCompleted.map((drill, idx) => (
                      <span
                        key={idx}
                        className="font-mono-tech text-[10px] bg-[#1a1a1a] border border-[#2b2b2b] text-[#A3A3A3] px-2 py-0.5"
                      >
                        ✓ {drill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Log Session Modal */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="RECORD PUGILISTIC SESSION"
        subtitle="OFFICIAL ACADEMY LEDGER ENTRY"
      >
        <form onSubmit={handleCreateSession} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select
              label="SESSION TYPE"
              value={sessionType}
              onChange={(e) => setSessionType(e.target.value as any)}
              options={[
                { value: 'Shadowboxing', label: 'Shadowboxing (Biomechanical)' },
                { value: 'Heavy Bag', label: 'Heavy Bag (Kinetic Power)' },
                { value: 'Pads / Mitts', label: 'Pads / Mitts (Precision Speed)' },
                { value: 'Technical Sparring', label: 'Technical Sparring (Controlled)' },
                { value: 'Conditioning & Roadwork', label: 'Conditioning & Roadwork' },
                { value: 'Footwork Matrix', label: 'Footwork Matrix / Agility' },
              ]}
            />
            <Input
              label="TOTAL ROUNDS COMPLETED"
              type="number"
              min={1}
              max={20}
              value={rounds}
              onChange={(e) => setRounds(Number(e.target.value))}
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select
              label="INTENSITY CADENCE"
              value={intensity}
              onChange={(e) => setIntensity(e.target.value as any)}
              options={[
                { value: 'Technical Recovery', label: 'Technical Recovery (Low)' },
                { value: 'Moderate Cadence', label: 'Moderate Cadence (Working)' },
                { value: 'High Championship Intensity', label: 'High Championship (Max)' },
              ]}
            />
            <Select
              label="CORE PILLAR EMPHASIZED"
              value={focusPillar}
              onChange={(e) => setFocusPillar(e.target.value)}
              options={TRAINING_PILLARS.map((p) => ({
                value: p.name,
                label: p.name,
              }))}
            />
          </div>

          <Input
            label="DRILLS COMPLETED (COMMA SEPARATED)"
            value={drillsInput}
            onChange={(e) => setDrillsInput(e.target.value)}
            helperText="e.g. Pendulum Steps, Double-Jab Slip, High Guard Reset"
          />

          <Textarea
            label="TECHNICAL NOTES & SENSATIONS"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Document what went well and what felt loose (e.g. rear heel stayed high; need to sharpen lead check hook exit)..."
            required
          />

          <div className="pt-2 flex justify-end gap-3">
            <Button variant="ghost" size="sm" type="button" onClick={() => setIsLogModalOpen(false)}>
              CANCEL
            </Button>
            <Button variant="primary" size="sm" type="submit">
              COMMIT TO LEDGER (+{rounds * 25} XP)
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
