import React, { useState } from 'react';
import {
  Search,
  Filter,
  AlertOctagon,
  Check,
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  ShieldCheck,
  GraduationCap,
  Sparkles,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { Input } from '../components/common/FormField';
import { TECHNIQUE_CATALOG, STANDARDIZED_PILLARS, LESSON_CATALOG } from '../data/curriculumData';
import { TechniqueItem, LessonItem } from '../types/academy';
import { filterTechniques } from '../utils/curriculum';

export interface TechniqueLibraryPageProps {
  bookmarkedTechniqueIds?: string[];
  onToggleBookmarkTechnique?: (techniqueId: string) => void;
  onOpenLesson?: (lessonId: string) => void;
}

export const TechniqueLibraryPage: React.FC<TechniqueLibraryPageProps> = ({
  bookmarkedTechniqueIds = [],
  onToggleBookmarkTechnique,
  onOpenLesson,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedPillar, setSelectedPillar] = useState<string>('All');
  const [onlyBookmarked, setOnlyBookmarked] = useState<boolean>(false);
  const [selectedTechniqueId, setSelectedTechniqueId] = useState<string>(
    TECHNIQUE_CATALOG[0].id
  );

  const categories = [
    'All',
    'Stance & Guard',
    'Footwork',
    'Strikes & Mechanics',
    'Defense & Evasion',
    'Ring Awareness & Tactics',
    'Recovery & Training Safety',
  ];

  const bookmarkedSet = new Set(bookmarkedTechniqueIds);

  const filteredTechniques = filterTechniques(TECHNIQUE_CATALOG, bookmarkedTechniqueIds, {
    query: searchQuery,
    category: selectedCategory,
    difficulty: selectedDifficulty,
    pillar: selectedPillar,
    onlyBookmarked,
  });

  const selectedTechnique =
    TECHNIQUE_CATALOG.find((t) => t.id === selectedTechniqueId) ||
    filteredTechniques[0] ||
    TECHNIQUE_CATALOG[0];

  const isCurrentBookmarked = bookmarkedSet.has(selectedTechnique.id);

  const relatedLessons = LESSON_CATALOG.filter((l) =>
    selectedTechnique.relatedLessonIds.includes(l.id)
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="TECHNICAL ARSENAL"
        title="BIOMECHANICAL TECHNIQUE LIBRARY"
        subtitle="Every strike, defensive evasion, and footwork shift deconstructed into strict kinetic mechanics. Master the mechanics before chasing speed."
        actions={
          <div className="flex items-center gap-2">
            <Badge variant="accent">{TECHNIQUE_CATALOG.length} TECHNIQUES CATALOGED</Badge>
            <Badge variant="neutral">
              {bookmarkedTechniqueIds.length} BOOKMARKED
            </Badge>
          </div>
        }
      />

      {/* Filter and Search Bar */}
      <div className="space-y-3">
        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 border-b border-[#262626] pb-3">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 font-mono-tech text-xs uppercase tracking-wider border cursor-pointer transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#D7263D] text-[#F5F5F5] border-[#D7263D] font-bold'
                  : 'bg-[#141414] text-[#A3A3A3] border-[#303030] hover:text-[#F5F5F5]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Dropdowns, Bookmarks toggle, and Search */}
        <div className="bg-[#121212] border border-[#2b2b2b] p-3 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="flex flex-wrap items-center gap-2">
            {/* Bookmarked toggle */}
            <button
              onClick={() => setOnlyBookmarked(!onlyBookmarked)}
              className={`px-3 py-1.5 font-mono-tech text-xs uppercase tracking-wider border cursor-pointer flex items-center gap-1.5 ${
                onlyBookmarked
                  ? 'bg-[#D7263D] text-[#FFFFFF] border-[#D7263D] font-bold'
                  : 'bg-[#181818] text-[#A3A3A3] border-[#333333] hover:text-[#F5F5F5]'
              }`}
            >
              {onlyBookmarked ? (
                <BookmarkCheck className="w-3.5 h-3.5 text-[#FFFFFF]" />
              ) : (
                <Bookmark className="w-3.5 h-3.5 text-[#777777]" />
              )}
              BOOKMARKED ONLY ({bookmarkedTechniqueIds.length})
            </button>

            {/* Difficulty Filter */}
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="bg-[#181818] border border-[#333333] px-2.5 py-1.5 font-mono-tech text-xs text-[#CCCCCC] cursor-pointer"
            >
              <option value="All">ALL DIFFICULTIES</option>
              <option value="Novice">Novice</option>
              <option value="Fundamental">Fundamental</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
              <option value="Mastery">Mastery</option>
            </select>

            {/* Pillar Filter */}
            <select
              value={selectedPillar}
              onChange={(e) => setSelectedPillar(e.target.value)}
              className="bg-[#181818] border border-[#333333] px-2.5 py-1.5 font-mono-tech text-xs text-[#CCCCCC] cursor-pointer"
            >
              <option value="All">ALL TRAINING PILLARS</option>
              {STANDARDIZED_PILLARS.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="w-full md:w-72">
            <Input
              placeholder="SEARCH PUNCH, MECHANIC, FAULT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Main Split View: Left List, Right Detailed Deep Dive */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Technique List (5 cols) */}
        <div className="lg:col-span-5 space-y-2.5 max-h-[850px] overflow-y-auto pr-1">
          {filteredTechniques.length === 0 ? (
            <div className="p-6 bg-[#141414] border border-[#262626] text-center font-mono-tech text-xs text-[#777777]">
              No techniques match the active filters or search terms.
            </div>
          ) : (
            filteredTechniques.map((tech) => {
              const isSelected = selectedTechnique.id === tech.id;
              const isBookmarked = bookmarkedSet.has(tech.id);

              return (
                <div
                  key={tech.id}
                  onClick={() => setSelectedTechniqueId(tech.id)}
                  className={`p-4 border transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-[#191919] border-l-4 border-l-[#D7263D] border-[#404040]'
                      : 'bg-[#141414] border-[#262626] hover:border-[#383838]'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-mono-tech mb-1">
                    <span className="text-[#D7263D] font-bold">{tech.code}</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="muted" size="sm">
                        {tech.category}
                      </Badge>
                      {onToggleBookmarkTechnique && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleBookmarkTechnique(tech.id);
                          }}
                          className={`p-1 hover:text-[#FFFFFF] cursor-pointer ${
                            isBookmarked ? 'text-[#D7263D]' : 'text-[#555555]'
                          }`}
                          title={isBookmarked ? 'Remove bookmark' : 'Bookmark technique'}
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                        </button>
                      )}
                    </div>
                  </div>

                  <h3 className="font-condensed text-xl font-bold uppercase tracking-wide text-[#F5F5F5]">
                    {tech.name}
                  </h3>

                  <div className="flex items-center gap-2 text-xs font-mono-tech text-[#777777] mt-1">
                    <span className="truncate max-w-[200px]">{tech.pillar}</span>
                    <span>•</span>
                    <span>{tech.difficulty}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right: Selected Technique Full Dossier (7 cols) */}
        <div className="lg:col-span-7 bg-[#161616] border border-[#303030] p-5 sm:p-6 space-y-6">
          <div className="border-b border-[#2b2b2b] pb-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <span className="font-mono-tech text-xs text-[#D7263D] font-bold">
                {selectedTechnique.code} // BIOMECHANICAL SPECIFICATION
              </span>

              <div className="flex items-center gap-2">
                <Badge variant="accent">{selectedTechnique.difficulty}</Badge>
                <Badge variant="neutral">PHASE {selectedTechnique.phase}</Badge>
                {onToggleBookmarkTechnique && (
                  <Button
                    variant={isCurrentBookmarked ? 'secondary' : 'outline'}
                    size="sm"
                    leftIcon={
                      <Bookmark
                        className={`w-3.5 h-3.5 ${isCurrentBookmarked ? 'fill-current' : ''}`}
                      />
                    }
                    onClick={() => onToggleBookmarkTechnique(selectedTechnique.id)}
                  >
                    {isCurrentBookmarked ? 'BOOKMARKED' : 'BOOKMARK'}
                  </Button>
                )}
              </div>
            </div>

            <h2 className="font-condensed text-3xl font-black uppercase text-[#F5F5F5] tracking-wide">
              {selectedTechnique.name}
            </h2>
            <div className="font-mono-tech text-xs text-[#A3A3A3] mt-1">
              PILLAR: <span className="text-[#F5F5F5]">{selectedTechnique.pillar}</span> • CATEGORY:{' '}
              <span className="text-[#F5F5F5]">{selectedTechnique.category}</span>
            </div>
            <p className="text-sm text-[#CCCCCC] mt-3 leading-relaxed font-sans">
              {selectedTechnique.description}
            </p>
          </div>

          {/* Educational Purpose */}
          <div className="bg-[#121212] border border-[#262626] p-4">
            <span className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold block mb-1">
              // EDUCATIONAL PURPOSE & VALUE
            </span>
            <p className="text-xs text-[#DDDDDD] font-sans leading-relaxed">
              {selectedTechnique.educationalExplanation}
            </p>
          </div>

          {/* Kinetic Execution Steps */}
          <div>
            <div className="font-mono-tech text-xs text-[#F5F5F5] uppercase tracking-wider font-bold mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#D7263D]" />
              KINETIC EXECUTION & BIOMECHANICAL SEQUENCE
            </div>
            <div className="space-y-2">
              {selectedTechnique.biomechanics.map((step, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-[#121212] border border-[#262626] flex items-start gap-3"
                >
                  <span className="font-mono-tech text-xs text-[#D7263D] font-bold mt-0.5">
                    0{idx + 1}
                  </span>
                  <p className="text-xs text-[#E0E0E0] font-sans leading-relaxed">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Common Mistakes & Safety Considerations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Faults */}
            <div>
              <div className="font-mono-tech text-xs text-[#F59E0B] uppercase tracking-wider font-bold mb-2 flex items-center gap-1.5">
                <AlertOctagon className="w-3.5 h-3.5 text-[#F59E0B]" />
                BIOMECHANICAL FAULTS
              </div>
              <div className="space-y-2">
                {selectedTechnique.commonMistakes.map((fault, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-[#181512] border border-[#3d2f1f] text-xs text-[#D1B48C] flex items-start gap-2"
                  >
                    <span className="text-[#F59E0B] font-bold">✕</span>
                    <span>{fault}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Safety Guidelines */}
            <div>
              <div className="font-mono-tech text-xs text-[#34D399] uppercase tracking-wider font-bold mb-2 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#34D399]" />
                RESPONSIBLE PRACTICE
              </div>
              <div className="space-y-2">
                {selectedTechnique.safetyConsiderations.map((safety, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-[#121915] border border-[#1b3d24] text-xs text-[#C5E5D0] flex items-start gap-2"
                  >
                    <span className="text-[#34D399] font-bold">✓</span>
                    <span>{safety}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Ring Application */}
          <div className="pt-4 border-t border-[#2b2b2b] bg-[#121212] p-4 border">
            <span className="font-mono-tech text-[10px] text-[#A3A3A3] uppercase block mb-1">
              TACTICAL APPLICATION IN THE SQUARED CIRCLE:
            </span>
            <p className="text-xs text-[#F5F5F5] leading-relaxed font-sans">
              {selectedTechnique.ringApplication}
            </p>
          </div>

          {/* Related Curriculum Lessons Cross-References */}
          {relatedLessons.length > 0 && (
            <div className="pt-4 border-t border-[#2b2b2b]">
              <span className="font-mono-tech text-xs text-[#777777] uppercase block mb-2">
                ASSOCIATED ACADEMY LESSONS:
              </span>
              <div className="space-y-2">
                {relatedLessons.map((l) => (
                  <div
                    key={l.id}
                    onClick={() => onOpenLesson && onOpenLesson(l.id)}
                    className="p-3 bg-[#111111] border border-[#2a2a2a] hover:border-[#D7263D] transition-all cursor-pointer flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <GraduationCap className="w-4 h-4 text-[#D7263D] group-hover:scale-110 transition-transform" />
                      <div>
                        <span className="font-condensed text-sm font-bold uppercase text-[#F5F5F5] block">
                          Level {l.levelNumber}: {l.title}
                        </span>
                        <span className="font-mono-tech text-[10px] text-[#777777]">
                          {l.estimatedDurationMin} MIN • +{l.xpReward} XP • {l.difficulty}
                        </span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      GO TO LESSON <ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
