import React, { useState } from 'react';
import { Settings, Shield, Bell, Eye, Database, AlertTriangle, Check, UserCheck, Compass } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Checkbox, Select, Input } from '../components/common/FormField';
import { Modal } from '../components/common/Modal';
import { Badge } from '../components/common/Badge';
import { OnboardingProfile } from '../types/academy';

export interface SettingsPageProps {
  onboarding: OnboardingProfile | null;
  onOpenOnboarding: () => void;
  weeklyGoalSessions: number;
  onUpdateWeeklyGoal: (goal: number) => void;
  onResetProgress: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  onboarding,
  onOpenOnboarding,
  weeklyGoalSessions,
  onUpdateWeeklyGoal,
  onResetProgress,
}) => {
  const [density, setDensity] = useState<'compact' | 'standard'>('standard');
  const [units, setUnits] = useState<'imperial' | 'metric'>('imperial');
  const [audioCues, setAudioCues] = useState<boolean>(true);
  const [safetyReminder, setSafetyReminder] = useState<boolean>(true);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetSuccessNotice, setResetSuccessNotice] = useState(false);

  const handleConfirmReset = () => {
    onResetProgress();
    setIsResetModalOpen(false);
    setResetSuccessNotice(true);
    setTimeout(() => setResetSuccessNotice(false), 3000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="SYSTEM CONFIGURATION"
        title="ACADEMY SETTINGS & PREFERENCES"
        subtitle="Manage interface metrics, audio training bells, safety prompts, and local progress storage."
      />

      {resetSuccessNotice && (
        <div className="bg-[#122416] border border-[#1b4324] text-[#34D399] p-3 text-xs font-mono-tech flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>TRAINING LEDGER AND XP PROGRESSION RESET TO FACTORY LEVEL 1.</span>
        </div>
      )}

      <div className="space-y-6 max-w-4xl">
        {/* Section 0: Personalized Onboarding & Roadmap Configuration */}
        <Card
          variant="surface"
          headerBar={
            <>
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#D7263D]" />
                <span className="font-bold">ADMISSIONS INTERVIEW & LEARNING ROADMAP</span>
              </div>
              <Badge variant={onboarding ? 'accent' : 'warning'}>
                {onboarding ? 'COMPLETED' : 'INCOMPLETE'}
              </Badge>
            </>
          }
        >
          <div className="space-y-3">
            <p className="text-xs text-[#CCCCCC] leading-relaxed font-sans">
              {onboarding ? (
                <>
                  Your personalized profile is configured for{' '}
                  <strong className="text-[#F5F5F5]">{onboarding.displayName}</strong> ({onboarding.experience.replace('_', ' ')}). 
                  Target cadence: <strong className="text-[#D7263D]">{onboarding.availableDays.length} sessions/week</strong> ({onboarding.availableDays.join(', ')}).
                </>
              ) : (
                'You have not completed the admissions interview. Completing it will personalize your dashboard, weekly goals, and training roadmap.'
              )}
            </p>

            <div className="pt-2">
              <Button
                variant="primary"
                size="sm"
                onClick={onOpenOnboarding}
              >
                {onboarding ? 'EDIT ONBOARDING & ROADMAP' : 'START ONBOARDING INTERVIEW'}
              </Button>
            </div>
          </div>
        </Card>

        {/* Section 1: Weekly Cadence Target */}
        <Card
          variant="surface"
          headerBar={
            <>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#D7263D]" />
                <span className="font-bold">WEEKLY COMMITMENT TARGET</span>
              </div>
              <span className="text-[#A3A3A3]">CADENCE GOAL</span>
            </>
          }
        >
          <div className="space-y-3">
            <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3]">
              TARGET SESSIONS PER CALENDAR WEEK ({weeklyGoalSessions} SESSIONS)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[2, 3, 4, 5, 6].map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => onUpdateWeeklyGoal(count)}
                  className={`p-2.5 border font-mono-tech text-xs uppercase cursor-pointer ${
                    weeklyGoalSessions === count
                      ? 'bg-[#D7263D] text-white border-[#D7263D] font-bold'
                      : 'bg-[#121212] border-[#2b2b2b] text-[#A3A3A3] hover:text-white'
                  }`}
                >
                  {count} Days / Wk
                </button>
              ))}
            </div>
            <p className="text-[11px] font-mono-tech text-[#777777]">
              The dashboard weekly progress bar benchmarks against this number.
            </p>
          </div>
        </Card>

        {/* Section 2: Display & Interface */}
        <Card
          variant="surface"
          headerBar={
            <>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#D7263D]" />
                <span className="font-bold">INTERFACE & DISPLAY DENSITY</span>
              </div>
              <span className="text-[#A3A3A3]">VISUAL SYSTEM</span>
            </>
          }
        >
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Select
                label="DISPLAY DENSITY"
                value={density}
                onChange={(e) => setDensity(e.target.value as any)}
                options={[
                  { value: 'standard', label: 'Industrial Standard (Balanced)' },
                  { value: 'compact', label: 'Technical High-Density (Data focused)' },
                ]}
                helperText="Controls vertical padding on drill cards and technique catalogs."
              />

              <Select
                label="MEASUREMENT UNITS"
                value={units}
                onChange={(e) => setUnits(e.target.value as any)}
                options={[
                  { value: 'imperial', label: 'Imperial (LBS / Inches)' },
                  { value: 'metric', label: 'Metric (KG / CM)' },
                ]}
                helperText="Weight classes and reach display units."
              />
            </div>
          </div>
        </Card>

        {/* Section 3: Audio & Bells */}
        <Card
          variant="surface"
          headerBar={
            <>
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#D7263D]" />
                <span className="font-bold">ROUND BELLS & AUDIO CUES</span>
              </div>
              <span className="text-[#A3A3A3]">CADENCE SIGNALS</span>
            </>
          }
        >
          <div className="space-y-3">
            <Checkbox
              label="Enable 10-Second Warning Clapper"
              helper="Plays acoustic clapper sound 10 seconds before the round interval ends."
              checked={audioCues}
              onChange={(e) => setAudioCues(e.target.checked)}
            />
            <Checkbox
              label="Mandatory Safety Hand-Wrap Confirmation"
              helper="Requires confirmation that 180-inch wraps are secured before launching live bag drills."
              checked={safetyReminder}
              onChange={(e) => setSafetyReminder(e.target.checked)}
            />
          </div>
        </Card>

        {/* Section 4: Danger Zone */}
        <div className="border border-[#3d181d] bg-[#140e10] p-5">
          <div className="flex items-center gap-2.5 text-[#D7263D] font-mono-tech text-xs uppercase font-bold mb-2">
            <AlertTriangle className="w-4 h-4" />
            <span>DANGER ZONE // DATA RESET</span>
          </div>
          <p className="text-xs text-[#CCCCCC] mb-4 leading-relaxed font-sans">
            Reset all completed rounds, XP progress, and customized fighter dossier back to Level 1 Novice state. 
            This action cannot be undone.
          </p>
          <Button
            variant="danger"
            size="sm"
            onClick={() => setIsResetModalOpen(true)}
          >
            RESET ACADEMY PROGRESS
          </Button>
        </div>
      </div>

      {/* Confirmation Dialog Modal */}
      <Modal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        title="CONFIRM PROGRESS PURGE"
        subtitle="IRREVERSIBLE ACTION"
        isDestructive
        confirmLabel="YES, PURGE ALL PROGRESS"
        cancelLabel="ABORT"
        onConfirm={handleConfirmReset}
      >
        <p className="text-sm text-[#E0E0E0] mb-3">
          Are you sure you want to reset your DRVZZY ACADEMY ledger?
        </p>
        <p className="text-xs text-[#A3A3A3] font-mono-tech">
          This will wipe your current XP, return your fighter to Level 1 Novice status, clear completed levels, and reset the journal ledger.
        </p>
      </Modal>
    </div>
  );
};
