import React, { useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Clock,
  Dumbbell,
  CheckCircle2,
  ChevronRight,
  BookOpen,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { STANDARDIZED_PILLARS, LESSON_CATALOG } from '../data/curriculumData';
import { calculatePillarProgress } from '../utils/curriculum';

export interface TrainingPageProps {
  completedLessonIds?: string[];
  onOpenLesson?: (lessonId: string) => void;
}

export const TrainingPage: React.FC<TrainingPageProps> = ({
  completedLessonIds = [],
  onOpenLesson,
}) => {
  const [selectedPillarId, setSelectedPillarId] = useState<string>('pillar-conditioning-movement');
  const [roundsCount, setRoundsCount] = useState<number>(6);
  const [roundMinutes, setRoundMinutes] = useState<number>(3);
  const [restSeconds, setRestSeconds] = useState<number>(60);

  // Round Simulator state
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(180);
  const [isRestPhase, setIsRestPhase] = useState<boolean>(false);

  const selectedPillar =
    STANDARDIZED_PILLARS.find((p) => p.id === selectedPillarId) || STANDARDIZED_PILLARS[0];

  const handleStartTimer = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setCurrentRound(1);
    setIsRestPhase(false);
    setSecondsRemaining(roundMinutes * 60);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Associated lessons for the selected pillar
  const pillarLessons = LESSON_CATALOG.filter((l) => l.pillars.includes(selectedPillar.name));
  const selectedPillarProgress = calculatePillarProgress(
    selectedPillar.name,
    completedLessonIds,
    LESSON_CATALOG
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="TRAINING ARCHITECTURE"
        title="THE 6 STANDARDIZED TRAINING PILLARS"
        subtitle="Boxing proficiency requires systemic balance across all six disciplines. Neglecting footwork ruins power; neglecting recovery breaks conditioning."
        actions={<Badge variant="accent">6 PILLARS STANDARDIZED</Badge>}
      />

      {/* 1. INTERACTIVE ROUND TIMER / WORKOUT SESSION CONTROLLER */}
      <Card
        variant="elevated"
        withCrosshairs
        headerBar={
          <>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-[#D7263D]" />
              <span className="text-[#F5F5F5] font-bold">
                PUGILISTIC ROUND TIMER & PROTOCOL CONTROLLER
              </span>
            </div>
            <span className="text-[#A3A3A3] font-mono-tech">PRECISION CADENCE</span>
          </>
        }
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Timer Display Console (5 cols) */}
          <div className="lg:col-span-5 bg-[#121212] border border-[#303030] p-6 text-center space-y-4">
            <div className="flex justify-between items-center text-xs font-mono-tech">
              <span className="text-[#777777]">
                ROUND {currentRound} OF {roundsCount}
              </span>
              <span className={isRestPhase ? 'text-[#F59E0B] font-bold' : 'text-[#D7263D] font-bold'}>
                {isRestPhase ? '// REST INTERVAL' : '// LIVE WORK INTERVAL'}
              </span>
            </div>

            <div className="py-4">
              <div className="font-mono-tech text-6xl sm:text-7xl font-bold tracking-tight text-[#F5F5F5]">
                {formatTime(secondsRemaining)}
              </div>
              <div className="font-mono-tech text-xs text-[#777777] uppercase tracking-widest mt-1">
                {isRestPhase ? 'RECOVER & BREATHE NASALLY' : 'MAINTAIN STANCE & SNAP'}
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <Button
                variant={isTimerRunning ? 'secondary' : 'primary'}
                size="md"
                leftIcon={
                  isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                onClick={handleStartTimer}
              >
                {isTimerRunning ? 'PAUSE CLOCK' : 'START ROUND'}
              </Button>
              <Button
                variant="outline"
                size="md"
                leftIcon={<RotateCcw className="w-4 h-4" />}
                onClick={handleResetTimer}
              >
                RESET
              </Button>
            </div>
          </div>

          {/* Session Setup Parameters (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
              SESSION CONFIGURATION
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3] mb-1">
                  TOTAL ROUNDS
                </label>
                <select
                  value={roundsCount}
                  onChange={(e) => setRoundsCount(Number(e.target.value))}
                  className="w-full bg-[#121212] border border-[#303030] px-3 py-2 text-sm text-[#F5F5F5] font-mono-tech cursor-pointer"
                >
                  <option value={3}>3 Rounds (Amateur sprint)</option>
                  <option value={6}>6 Rounds (Technical standard)</option>
                  <option value={8}>8 Rounds (Contender)</option>
                  <option value={10}>10 Rounds (Pro championship)</option>
                  <option value={12}>12 Rounds (Apex title)</option>
                </select>
              </div>

              <div>
                <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3] mb-1">
                  ROUND MINUTES
                </label>
                <select
                  value={roundMinutes}
                  onChange={(e) => {
                    const m = Number(e.target.value);
                    setRoundMinutes(m);
                    setSecondsRemaining(m * 60);
                  }}
                  className="w-full bg-[#121212] border border-[#303030] px-3 py-2 text-sm text-[#F5F5F5] font-mono-tech cursor-pointer"
                >
                  <option value={2}>2 Minutes (Beginner / Cadence)</option>
                  <option value={3}>3 Minutes (Championship)</option>
                </select>
              </div>

              <div>
                <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3] mb-1">
                  REST DURATION
                </label>
                <select
                  value={restSeconds}
                  onChange={(e) => setRestSeconds(Number(e.target.value))}
                  className="w-full bg-[#121212] border border-[#303030] px-3 py-2 text-sm text-[#F5F5F5] font-mono-tech cursor-pointer"
                >
                  <option value={30}>30s (Hyper-Cardio)</option>
                  <option value={60}>60s (Standard Bell)</option>
                </select>
              </div>
            </div>

            <div className="pt-2">
              <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3] mb-1">
                PRIMARY PILLAR FOCUS FOR THIS SESSION
              </label>
              <select
                value={selectedPillarId}
                onChange={(e) => setSelectedPillarId(e.target.value)}
                className="w-full bg-[#121212] border border-[#303030] px-3 py-2.5 text-sm text-[#F5F5F5] font-mono-tech cursor-pointer"
              >
                {STANDARDIZED_PILLARS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.code} // {p.name} — {p.shortDesc}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </Card>

      {/* 2. THE SIX TRAINING PILLARS DETAILED BREAKDOWN & COVERAGE */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
            PILLAR MATRIX & CURRICULUM COVERAGE
          </div>
          <span className="text-xs font-mono-tech text-[#777777]">
            CLICK A PILLAR TO INSPECT LESSONS & DRILLS
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {STANDARDIZED_PILLARS.map((pillar) => {
            const isSelected = selectedPillarId === pillar.id;
            const progress = calculatePillarProgress(pillar.name, completedLessonIds, LESSON_CATALOG);

            return (
              <div
                key={pillar.id}
                onClick={() => setSelectedPillarId(pillar.id)}
                className={`p-5 border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#191919] border-l-4 border-l-[#D7263D] border-[#3b3b3b] shadow-md'
                    : 'bg-[#141414] border-[#262626] hover:border-[#404040]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono-tech mb-2">
                    <span className="text-[#D7263D] font-bold">{pillar.code}</span>
                    <span className="text-[#777777] uppercase text-[10px]">
                      {progress.completedLessons} / {progress.totalLessons} LESSONS ({progress.percent}%)
                    </span>
                  </div>

                  <h3 className="font-condensed text-2xl font-bold uppercase tracking-wide text-[#F5F5F5]">
                    {pillar.name}
                  </h3>
                  <div className="font-mono-tech text-xs text-[#A3A3A3] mt-0.5 mb-2">
                    {pillar.shortDesc}
                  </div>

                  {/* Progress Mini Bar */}
                  <div className="w-full h-1.5 bg-[#202020] border border-[#303030] mb-3 overflow-hidden">
                    <div
                      className="h-full bg-[#D7263D] transition-all"
                      style={{ width: `${progress.percent}%` }}
                    />
                  </div>

                  <p className="text-xs text-[#CCCCCC] leading-relaxed font-sans mb-3">
                    {pillar.description}
                  </p>

                  <div className="pt-3 border-t border-[#262626] space-y-1">
                    <div className="font-mono-tech text-[10px] text-[#777777] uppercase">
                      STANDARDIZED PROTOCOLS:
                    </div>
                    {pillar.drillsOverview.map((drill, idx) => (
                      <div
                        key={idx}
                        className="text-[11px] font-sans text-[#A3A3A3] flex items-center gap-1.5"
                      >
                        <span className="w-1 h-1 bg-[#D7263D]" />
                        <span>{drill}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#262626] flex items-center justify-between text-[10px] font-mono-tech text-[#888888]">
                  <span>IMPACT: <strong className="text-[#F5F5F5]">{pillar.importanceMetric}</strong></span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#777777]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. SELECTED PILLAR SYLLABUS DRILL-DOWN */}
      <div className="bg-[#141414] border border-[#303030] p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#262626] pb-3">
          <div>
            <span className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold">
              // {selectedPillar.code} SYLLABUS INTEGRATION
            </span>
            <h3 className="font-condensed text-2xl font-black uppercase text-[#F5F5F5]">
              {selectedPillar.name}
            </h3>
          </div>
          <div className="font-mono-tech text-xs text-[#A3A3A3]">
            {selectedPillarProgress.completedLessons} OF {selectedPillarProgress.totalLessons} LESSONS COMPLETED ({selectedPillarProgress.percent}%)
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {pillarLessons.map((lesson) => {
            const isCompleted = completedLessonIds.includes(lesson.id);

            return (
              <div
                key={lesson.id}
                onClick={() => onOpenLesson && onOpenLesson(lesson.id)}
                className={`p-4 border transition-all cursor-pointer flex items-center justify-between ${
                  isCompleted
                    ? 'bg-[#121c14] border-[#1e4024]'
                    : 'bg-[#181818] border-[#2b2b2b] hover:border-[#D7263D]'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 font-mono-tech text-[10px] text-[#D7263D] mb-0.5">
                    <span>LVL {lesson.levelNumber}</span>
                    <span>•</span>
                    <Badge variant="muted" size="sm">{lesson.difficulty}</Badge>
                  </div>
                  <h4 className="font-condensed text-base font-bold uppercase text-[#F5F5F5]">
                    {lesson.title}
                  </h4>
                  <div className="text-[11px] font-mono-tech text-[#777777] mt-0.5">
                    {lesson.estimatedDurationMin} MIN • +{lesson.xpReward} XP
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isCompleted ? (
                    <span className="flex items-center gap-1 text-[10px] font-mono-tech text-[#34D399] font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" /> DONE
                    </span>
                  ) : (
                    <Button variant="ghost" size="sm">
                      OPEN <ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
