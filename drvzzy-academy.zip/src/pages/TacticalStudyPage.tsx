import React, { useState } from 'react';
import { Sword, Brain, Shield, Crosshair, ChevronRight, Bookmark } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Badge } from '../components/common/Badge';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { TACTICAL_LEGENDS } from '../data/initialData';
import { TacticalLegend } from '../types/academy';

export const TacticalStudyPage: React.FC = () => {
  const [selectedLegend, setSelectedLegend] = useState<TacticalLegend>(TACTICAL_LEGENDS[0]);
  const [savedNotes, setSavedNotes] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const handleSaveNotes = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="RING INTELLIGENCE"
        title="TACTICAL STUDY & BOXING LEGENDS"
        subtitle="Study the archetypes and masterclasses of history’s greatest pugilists. True ring craft is intellectual warfare conducted at high kinetic velocity."
        actions={
          <Badge variant="accent">CHAMPIONSHIP CASE STUDIES</Badge>
        }
      />

      {/* Legend Selector Carousel / Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {TACTICAL_LEGENDS.map((legend) => {
          const isSelected = selectedLegend.id === legend.id;
          return (
            <button
              key={legend.id}
              onClick={() => setSelectedLegend(legend)}
              className={`p-4 text-left border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#191919] border-l-4 border-l-[#D7263D] border-[#3b3b3b]'
                  : 'bg-[#121212] border-[#242424] hover:border-[#383838]'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-mono-tech text-[#777777] mb-1">
                <span>{legend.record}</span>
                <Badge variant="muted" size="sm">{legend.archetype}</Badge>
              </div>
              <h3 className="font-condensed text-xl font-bold uppercase text-[#F5F5F5]">
                {legend.name}
              </h3>
              <p className="text-xs font-mono-tech text-[#D7263D] mt-0.5">
                "{legend.epithet}"
              </p>
            </button>
          );
        })}
      </div>

      {/* Selected Legend Master Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Analysis (8 cols) */}
        <div className="lg:col-span-8 bg-[#161616] border border-[#303030] p-6 space-y-6">
          <div className="border-b border-[#2b2b2b] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider mb-1">
                TACTICAL DOSSIER // {selectedLegend.archetype}
              </div>
              <h2 className="font-condensed text-3xl sm:text-4xl font-black uppercase text-[#F5F5F5]">
                {selectedLegend.name}
              </h2>
              <div className="text-xs font-mono-tech text-[#A3A3A3] mt-1">
                RECORD: {selectedLegend.record} • KNOWN AS "{selectedLegend.epithet}"
              </div>
            </div>
            <Badge variant="accent" hasDot>
              VERIFIED HISTORICAL SYSTEM
            </Badge>
          </div>

          {/* Master Analysis Breakdown */}
          <div>
            <div className="font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3] mb-2 flex items-center gap-2">
              <Brain className="w-4 h-4 text-[#D7263D]" />
              SYSTEMIC MASTERY BREAKDOWN
            </div>
            <p className="text-sm text-[#E0E0E0] leading-relaxed bg-[#121212] p-4 border border-[#262626]">
              {selectedLegend.masteryBreakdown}
            </p>
          </div>

          {/* Signature Weapons */}
          <div>
            <div className="font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3] mb-2">
              CORE TECHNICAL ATTRIBUTES & WEAPONS:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {selectedLegend.signatureAttributes.map((attr, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-[#121212] border border-[#2b2b2b] text-xs text-[#CCCCCC] flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 bg-[#D7263D] flex-shrink-0" />
                  <span>{attr}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tactical Counters */}
          <div className="border border-[#3d181d] bg-[#171012] p-4">
            <div className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold tracking-wider mb-1 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              HOW TO NEUTRALIZE / TACTICAL COUNTER:
            </div>
            <p className="text-xs text-[#CCCCCC] leading-relaxed">
              {selectedLegend.tacticalCounters}
            </p>
          </div>
        </div>

        {/* Right: Interactive Fighter Study Notes (4 cols) */}
        <div className="lg:col-span-4 bg-[#141414] border border-[#303030] p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#262626] pb-3">
            <div className="flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-[#D7263D]" />
              <span className="font-mono-tech text-xs text-[#F5F5F5] uppercase font-bold">
                TACTICAL STUDY LOG
              </span>
            </div>
            <span className="text-[10px] font-mono-tech text-[#777777]">
              NOTES
            </span>
          </div>

          <p className="text-xs text-[#A3A3A3]">
            Record technical takeaways from {selectedLegend.name} to incorporate into your shadowboxing and sparring roadmaps.
          </p>

          <textarea
            rows={8}
            value={savedNotes}
            onChange={(e) => setSavedNotes(e.target.value)}
            placeholder={`Documenting key cues from ${selectedLegend.name}...\ne.g. Notice how the rear pivot creates an angle for the right straight.`}
            className="w-full bg-[#0d0d0d] border border-[#303030] p-3 text-xs text-[#F5F5F5] font-mono-tech focus:border-[#D7263D] focus:outline-none"
          />

          <Button
            variant="primary"
            size="sm"
            fullWidth
            onClick={handleSaveNotes}
          >
            {isSaved ? 'STUDY NOTES COMMITTED' : 'SAVE TO STUDY DOSSIER'}
          </Button>

          {isSaved && (
            <p className="text-[11px] font-mono-tech text-[#10B981] text-center">
              ✓ Study entry recorded in Academy memory.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
