import React from 'react';
import {
  Activity,
  Flame,
  Calendar,
  ChevronRight,
  Play,
  RotateCcw,
  Target,
  Clock,
  Sparkles,
  Award,
  Layers,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  Shield,
  Dumbbell,
  Compass,
} from 'lucide-react';
import {
  FighterProfile,
  Rank,
  NavigationPage,
  JournalSession,
  OnboardingProfile,
  CurriculumLevel,
  ActivityRecord,
} from '../types/academy';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { ProgressBar } from '../components/common/ProgressBar';
import { EmptyState } from '../components/common/EmptyState';
import { CURRICULUM_LEVELS, CURRICULUM_PHASES, TRAINING_PILLARS } from '../data/initialData';
import { calculateLevelProgress, formatTechNumber } from '../utils/progression';
import {
  getNextIncompleteLesson,
  calculateWeeklyActivityMetrics,
  getDurationMinutes,
} from '../utils/personalization';

export interface DashboardPageProps {
  fighter: FighterProfile;
  currentRank: Rank;
  onboarding: OnboardingProfile | null;
  completedLevelIds: number[];
  journalSessions: JournalSession[];
  activityHistory: ActivityRecord[];
  weeklyGoalSessions: number;
  onNavigate: (page: NavigationPage) => void;
  onStartTodayDrill: () => void;
  onOpenLesson: (level: CurriculumLevel) => void;
  onOpenOnboarding: () => void;
  onCompleteLessonQuick?: (levelNumber: number) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  fighter,
  currentRank,
  onboarding,
  completedLevelIds,
  journalSessions,
  activityHistory,
  weeklyGoalSessions,
  onNavigate,
  onStartTodayDrill,
  onOpenLesson,
  onOpenOnboarding,
}) => {
  const progress = calculateLevelProgress(fighter.currentXp, fighter.currentLevel);

  // Identify next uncompleted lesson from real curriculum data
  const nextLesson = getNextIncompleteLesson(completedLevelIds, CURRICULUM_LEVELS);
  const nextLessonPhase = CURRICULUM_PHASES.find((p) => p.phaseNumber === nextLesson.phaseNumber);

  // Derive weekly metrics from genuine logs
  const weeklyMetrics = calculateWeeklyActivityMetrics(
    journalSessions,
    completedLevelIds,
    weeklyGoalSessions
  );

  // Target duration from onboarding or standard 45 min
  const sessionDurationMin = onboarding ? getDurationMinutes(onboarding.sessionDuration) : 45;

  // Active days label
  const daysActive = onboarding?.availableDays?.length
    ? onboarding.availableDays.join(' • ')
    : 'Mon • Wed • Fri';

  // Greeting display name
  const greetingName = onboarding?.displayName || fighter.callsign || 'Fighter';

  // Pillar progress mapping based on genuine logs & completed lessons
  const pillarDistribution: Record<string, number> = {};
  TRAINING_PILLARS.forEach((p) => {
    pillarDistribution[p.name] = 0;
  });
  journalSessions.forEach((s) => {
    if (pillarDistribution[s.focusPillar] !== undefined) {
      pillarDistribution[s.focusPillar] += s.rounds;
    }
  });

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* 0. INCOMPLETE ONBOARDING PROMPT BANNER (IF APPLICABLE) */}
      {!onboarding && (
        <div className="bg-[#191113] border-l-4 border-l-[#D7263D] border border-[#3b181d] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Compass className="w-5 h-5 text-[#D7263D] flex-shrink-0" />
            <div>
              <div className="font-mono-tech text-xs text-[#D7263D] font-bold uppercase tracking-wider">
                ADMISSIONS INTERVIEW PENDING
              </div>
              <p className="text-xs text-[#CCCCCC] mt-0.5 font-sans">
                Complete your personalized onboarding questionnaire to generate a tailored training cadence, duration budget, and curriculum sequence.
              </p>
            </div>
          </div>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenOnboarding}
            className="flex-shrink-0 self-start sm:self-auto"
          >
            START ONBOARDING INTERVIEW
          </Button>
        </div>
      )}

      {/* 1. WELCOME SECTION */}
      <section className="relative bg-[#121212] border border-[#303030] p-5 sm:p-7 overflow-hidden">
        <div className="absolute inset-0 academy-grid-bg opacity-30 pointer-events-none" />
        <div className="absolute top-2 left-2 text-[#444444] font-mono-tech text-[10px] select-none">
          + DRVZZY//HQ
        </div>
        <div className="absolute top-2 right-2 text-[#444444] font-mono-tech text-[10px] select-none">
          SEC-01 // READY
        </div>

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6 pt-2">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="accent" hasDot>
                PRIVATE BOXING ACADEMY
              </Badge>
              <Badge variant="neutral">
                CALLSIGN: {greetingName.toUpperCase()}
              </Badge>
              <span className="font-mono-tech text-xs text-[#A3A3A3]">
                SERIAL: {fighter.id}
              </span>
              {onboarding && (
                <button
                  onClick={onOpenOnboarding}
                  className="font-mono-tech text-[11px] text-[#D7263D] hover:underline uppercase cursor-pointer"
                >
                  [EDIT ONBOARDING PROFILE]
                </button>
              )}
            </div>

            <h1 className="font-condensed text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-[#F5F5F5] leading-none pt-1">
              STUDY THE CRAFT. <span className="text-[#D7263D]">EARN YOUR LEVEL.</span>
            </h1>

            <p className="text-sm sm:text-base text-[#A3A3A3] leading-relaxed font-sans">
              Welcome back, <strong className="text-[#F5F5F5]">{greetingName}</strong>. You are currently positioned in{' '}
              <span className="text-[#F5F5F5] font-semibold">{nextLessonPhase?.title || 'Phase I: Foundation & Biomechanics'}</span>. 
              Precision is not an accident—it is the direct outcome of disciplined kinetic repetition.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 flex-shrink-0">
            <Button
              variant="primary"
              size="md"
              leftIcon={<Play className="w-4 h-4 fill-current" />}
              onClick={onStartTodayDrill}
            >
              EXECUTE TODAY'S SESSION
            </Button>
            <Button
              variant="secondary"
              size="md"
              leftIcon={<Layers className="w-4 h-4" />}
              onClick={() => onNavigate('academy')}
            >
              VIEW 24-LEVEL CURRICULUM
            </Button>
          </div>
        </div>
      </section>

      {/* 2. XP PROGRESSION & FIGHTER SUMMARY TILES */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card A: Current Rank & Level */}
        <Card variant="accent-border" withCrosshairs className="h-full flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-2">
              <span>RANK TIER</span>
              <span className="text-[#D7263D]">{currentRank.insignia}</span>
            </div>
            <div className="font-condensed text-3xl font-black uppercase tracking-wider text-[#F5F5F5]">
              {currentRank.name}
            </div>
            <div className="text-xs text-[#A3A3A3] font-mono-tech mt-1">
              LEVEL {fighter.currentLevel} OF 24
            </div>
            <p className="text-xs text-[#CCCCCC] mt-3 line-clamp-2">
              {currentRank.title} — {currentRank.tacticalFocus}
            </p>
          </div>
          <div className="pt-4 mt-4 border-t border-[#303030]">
            <Button
              variant="ghost"
              size="sm"
              className="p-0 text-[#D7263D] hover:text-[#F5F5F5] font-mono-tech text-xs justify-start"
              onClick={() => onNavigate('progression')}
            >
              VIEW 8-RANK ROADMAP →
            </Button>
          </div>
        </Card>

        {/* Card B: Real XP Progress */}
        <Card variant="elevated" withCrosshairs className="h-full flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-2">
              <span>XP PROGRESSION</span>
              <span className="text-[#F5F5F5] font-bold">
                {progress.progressPercent}%
              </span>
            </div>
            <div className="font-condensed text-3xl font-black tracking-tight text-[#F5F5F5]">
              {formatTechNumber(progress.currentLevelXp)}{' '}
              <span className="text-sm font-mono-tech text-[#777777] font-normal">
                / {formatTechNumber(progress.nextLevelXp)} XP
              </span>
            </div>
            <div className="mt-3">
              <ProgressBar
                value={progress.progressPercent}
                height="md"
                variant="accent"
                showPercent={false}
              />
            </div>
            <div className="text-[11px] font-mono-tech text-[#A3A3A3] mt-2 flex justify-between">
              <span>REMAINING:</span>
              <span className="text-[#D7263D] font-bold">
                {formatTechNumber(progress.xpRemaining)} XP TO LVL {fighter.currentLevel + 1}
              </span>
            </div>
          </div>
          <div className="pt-4 mt-4 border-t border-[#303030] flex items-center justify-between text-xs font-mono-tech text-[#777777]">
            <span>PHASE {nextLesson.phaseNumber}</span>
            <span>{completedLevelIds.length} COMPLETED</span>
          </div>
        </Card>

        {/* Card C: Bio-Metrics & Combat Stance */}
        <Card variant="elevated" withCrosshairs className="h-full flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-2">
              <span>FIGHTER PROFILE</span>
              <span className="text-[#10B981] font-bold">ACTIVE</span>
            </div>
            <div className="font-condensed text-2xl font-bold uppercase tracking-wider text-[#F5F5F5]">
              {fighter.stance}
            </div>
            <div className="text-xs font-mono-tech text-[#A3A3A3] mt-0.5">
              {fighter.weightClass}
            </div>

            <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#262626] font-mono-tech text-xs">
              <div>
                <span className="text-[#777777] block text-[10px]">REACH</span>
                <span className="text-[#F5F5F5] font-bold">{fighter.reachInches}"</span>
              </div>
              <div>
                <span className="text-[#777777] block text-[10px]">HEIGHT</span>
                <span className="text-[#F5F5F5] font-bold">{fighter.heightCm} CM</span>
              </div>
            </div>
          </div>
          <div className="pt-4 mt-4 border-t border-[#303030]">
            <Button
              variant="ghost"
              size="sm"
              className="p-0 text-[#A3A3A3] hover:text-[#F5F5F5] font-mono-tech text-xs justify-start"
              onClick={() => onNavigate('profile')}
            >
              INSPECT DOSSIER →
            </Button>
          </div>
        </Card>

        {/* Card D: Discipline Streak & Output */}
        <Card variant="elevated" withCrosshairs className="h-full flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-2">
              <span>DISCIPLINE METRICS</span>
              <Flame className="w-4 h-4 text-[#D7263D]" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="font-condensed text-4xl font-black text-[#F5F5F5]">
                {fighter.streakDays}
              </span>
              <span className="font-mono-tech text-xs text-[#A3A3A3] uppercase">
                DAYS CONTINUOUS
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#262626] font-mono-tech text-xs">
              <div>
                <span className="text-[#777777] block text-[10px]">ROUNDS LOGGED</span>
                <span className="text-[#F5F5F5] font-bold">{fighter.totalRoundsLogged}</span>
              </div>
              <div>
                <span className="text-[#777777] block text-[10px]">TOTAL HOURS</span>
                <span className="text-[#F5F5F5] font-bold">{fighter.totalHoursTrained}H</span>
              </div>
            </div>
          </div>
          <div className="pt-4 mt-4 border-t border-[#303030]">
            <Button
              variant="ghost"
              size="sm"
              className="p-0 text-[#A3A3A3] hover:text-[#F5F5F5] font-mono-tech text-xs justify-start"
              onClick={() => onNavigate('journal')}
            >
              OPEN TRAINING LOG →
            </Button>
          </div>
        </Card>
      </section>

      {/* 3. TODAY'S PLAN & CONTINUE LEARNING */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Today's Plan (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <Card
            variant="surface"
            headerBar={
              <>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-[#D7263D]" />
                  <span className="text-[#F5F5F5] font-bold">TODAY'S SCHEDULED SESSION</span>
                  <span className="text-[#777777] hidden sm:inline">• {daysActive}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[#A3A3A3]">
                  <Clock className="w-3.5 h-3.5 text-[#D7263D]" />
                  <span>{sessionDurationMin} MIN BUDGET</span>
                </div>
              </>
            }
          >
            <div className="mb-4">
              <div className="font-mono-tech text-[11px] text-[#D7263D] uppercase tracking-wider mb-1">
                PRESCRIBED PROTOCOL // LEVEL {nextLesson.levelNumber}
              </div>
              <h2 className="font-condensed text-2xl font-bold uppercase tracking-tight text-[#F5F5F5]">
                {nextLesson.title}
              </h2>
              <p className="text-xs text-[#A3A3A3] mt-1 font-sans">
                {nextLesson.subtitle}. Strict adherence to biomechanical cues is mandatory before power output.
              </p>
            </div>

            {/* Drill Rounds Checklist */}
            <div className="space-y-2.5 my-4">
              <div className="p-3 bg-[#161616] border border-[#2b2b2b] flex items-start gap-3">
                <span className="font-mono-tech text-xs text-[#D7263D] font-bold mt-0.5">01</span>
                <div>
                  <div className="font-condensed text-base font-bold text-[#F5F5F5] uppercase">
                    Kinetic Warmup & Stance Alignment
                  </div>
                  <p className="text-xs text-[#A3A3A3] font-sans">
                    3 Rounds mirror line work: 55/45 weight split, chin tucked, eyes level.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-[#161616] border border-[#2b2b2b] flex items-start gap-3">
                <span className="font-mono-tech text-xs text-[#D7263D] font-bold mt-0.5">02</span>
                <div>
                  <div className="font-condensed text-base font-bold text-[#F5F5F5] uppercase">
                    Core Technical Mechanics
                  </div>
                  <p className="text-xs text-[#A3A3A3] font-sans">
                    Primary focus: {nextLesson.keySkills.slice(0, 2).join(' and ')}.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-[#161616] border border-[#2b2b2b] flex items-start gap-3">
                <span className="font-mono-tech text-xs text-[#D7263D] font-bold mt-0.5">03</span>
                <div>
                  <div className="font-condensed text-base font-bold text-[#F5F5F5] uppercase">
                    Benchmark Evaluation Criteria
                  </div>
                  <p className="text-xs text-[#CCCCCC] font-sans">
                    {nextLesson.benchmarkTest}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-[#262626]">
              <div className="text-xs font-mono-tech text-[#A3A3A3]">
                ESTIMATED XP: <span className="text-[#D7263D] font-bold">+{nextLesson.levelNumber * 100 + 50} XP</span>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onOpenLesson(nextLesson)}
                  className="w-1/2 sm:w-auto"
                >
                  EXAMINE SYLLABUS
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  leftIcon={<Play className="w-4 h-4 fill-current" />}
                  onClick={onStartTodayDrill}
                  className="w-1/2 sm:w-auto"
                >
                  START SESSION
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Column: Continue Learning (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <Card
            variant="surface"
            headerBar={
              <>
                <div className="flex items-center gap-2">
                  <Target className="w-3.5 h-3.5 text-[#D7263D]" />
                  <span className="text-[#F5F5F5] font-bold">CONTINUE LEARNING</span>
                </div>
                <span className="text-[#A3A3A3]">MODULE {nextLesson.levelNumber}.1</span>
              </>
            }
          >
            <div className="space-y-3">
              <Badge variant="accent">
                PHASE {nextLesson.phaseNumber}: {nextLessonPhase?.title.toUpperCase()}
              </Badge>
              <h3 className="font-condensed text-xl font-bold uppercase tracking-wide text-[#F5F5F5]">
                LEVEL {nextLesson.levelNumber}: {nextLesson.title}
              </h3>
              <p className="text-xs text-[#A3A3A3] leading-relaxed">
                {nextLesson.subtitle}
              </p>

              <div className="space-y-1.5 pt-2">
                <div className="text-[11px] font-mono-tech uppercase text-[#777777]">
                  CORE COMPETENCIES:
                </div>
                <div className="space-y-1 text-xs text-[#CCCCCC]">
                  {nextLesson.keySkills.map((skill, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
                      <span>{skill}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-[#262626]">
                <Button
                  variant="secondary"
                  size="sm"
                  fullWidth
                  rightIcon={<ChevronRight className="w-4 h-4" />}
                  onClick={() => onOpenLesson(nextLesson)}
                >
                  OPEN LESSON DETAILS
                </Button>
              </div>
            </div>
          </Card>

          {/* Quick Access to Six Pillars */}
          <Card variant="elevated">
            <div className="flex items-center justify-between mb-3">
              <span className="font-mono-tech text-xs text-[#F5F5F5] uppercase tracking-wider font-bold">
                THE 6 TRAINING PILLARS
              </span>
              <button
                onClick={() => onNavigate('training')}
                className="text-[10px] font-mono-tech text-[#D7263D] hover:underline uppercase cursor-pointer"
              >
                VIEW ALL →
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono-tech">
              {TRAINING_PILLARS.slice(0, 4).map((p) => (
                <div key={p.id} className="p-2 bg-[#141414] border border-[#2b2b2b]">
                  <span className="text-[#D7263D] block text-[10px]">{p.code}</span>
                  <span className="text-[#CCCCCC]">{p.name}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* 4. WEEKLY OVERVIEW: REAL COUNTS & PROGRESS */}
      <Card
        variant="elevated"
        headerBar={
          <>
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-[#D7263D]" />
              <span className="text-[#F5F5F5] font-bold">WEEKLY DISCIPLINE CADENCE</span>
            </div>
            <span className="text-[#A3A3A3]">OCTOBER 2026 // WEEK 43</span>
          </>
        }
      >
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4">
          <div className="p-3 bg-[#141414] border border-[#2b2b2b]">
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block">
              SESSIONS COMPLETED
            </span>
            <div className="font-condensed text-3xl font-black text-[#F5F5F5] mt-1">
              {weeklyMetrics.sessionsCount} / {weeklyMetrics.weeklyGoalSessions}
            </div>
            <span className="text-[10px] font-mono-tech text-[#A3A3A3]">
              {weeklyMetrics.progressPercent}% of weekly goal
            </span>
          </div>

          <div className="p-3 bg-[#141414] border border-[#2b2b2b]">
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block">
              LESSONS COMPLETED
            </span>
            <div className="font-condensed text-3xl font-black text-[#F5F5F5] mt-1">
              {weeklyMetrics.lessonsCompletedCount}
            </div>
            <span className="text-[10px] font-mono-tech text-[#A3A3A3]">
              Across 24 curriculum tiers
            </span>
          </div>

          <div className="p-3 bg-[#141414] border border-[#2b2b2b]">
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block">
              ROUNDS LOGGED
            </span>
            <div className="font-condensed text-3xl font-black text-[#D7263D] mt-1">
              {weeklyMetrics.totalRounds}
            </div>
            <span className="text-[10px] font-mono-tech text-[#A3A3A3]">
              Verified training rounds
            </span>
          </div>

          <div className="p-3 bg-[#141414] border border-[#2b2b2b]">
            <span className="font-mono-tech text-[10px] text-[#777777] uppercase block">
              ACTIVITY LEDGER
            </span>
            <div className="font-condensed text-3xl font-black text-[#F5F5F5] mt-1">
              {activityHistory.length}
            </div>
            <span className="text-[10px] font-mono-tech text-[#A3A3A3]">
              Recorded events & entries
            </span>
          </div>
        </div>

        <div>
          <ProgressBar
            value={weeklyMetrics.progressPercent}
            label={`WEEKLY CADENCE GOAL (${weeklyMetrics.sessionsCount} OF ${weeklyMetrics.weeklyGoalSessions} SESSIONS)`}
            variant="accent"
            height="sm"
          />
        </div>
      </Card>

      {/* 5. PROGRESS SNAPSHOT: THE 6 PILLARS */}
      <Card variant="surface">
        <div className="flex items-center justify-between mb-4 border-b border-[#2b2b2b] pb-3">
          <div>
            <div className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold">
              PILLAR BALANCE SNAPSHOT
            </div>
            <h3 className="font-condensed text-xl font-bold uppercase text-[#F5F5F5]">
              PROGRESS ACROSS THE 6 FOUNDATIONS
            </h3>
          </div>
          <span className="text-xs font-mono-tech text-[#777777]">
            BASED ON LOGGED ROUNDS
          </span>
        </div>

        {journalSessions.length === 0 ? (
          <EmptyState
            title="NO PILLAR ROUNDS RECORDED YET"
            description="When you log shadowboxing, bag work, or mitts in the journal, your training distribution across the 6 pillars will appear here."
            actionLabel="LOG A PILLAR SESSION"
            onAction={() => onNavigate('journal')}
            icon="crosshair"
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {TRAINING_PILLARS.map((pillar) => {
              const rounds = pillarDistribution[pillar.name] || 0;
              const maxRounds = Math.max(1, ...Object.values(pillarDistribution));
              const percent = Math.min(100, Math.round((rounds / maxRounds) * 100));

              return (
                <div key={pillar.id} className="p-3 bg-[#141414] border border-[#262626] space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono-tech">
                    <span className="text-[#D7263D] font-bold">{pillar.code}</span>
                    <span className="text-[#F5F5F5]">{rounds} Rounds</span>
                  </div>
                  <div className="font-condensed text-base font-bold uppercase text-[#F5F5F5] truncate">
                    {pillar.name}
                  </div>
                  <ProgressBar value={percent} height="sm" showPercent={false} variant={rounds > 0 ? 'accent' : 'neutral'} />
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* 6. RECENT ACTIVITY SECTION */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider">
              GENUINE ACTIVITY AUDIT
            </div>
            <h3 className="font-condensed text-2xl font-bold uppercase tracking-tight text-[#F5F5F5]">
              RECENT ACADEMY EVENTS & LOGS
            </h3>
          </div>
          <span className="text-xs font-mono-tech text-[#777777]">
            {activityHistory.length} RECORDED
          </span>
        </div>

        {activityHistory.length === 0 && journalSessions.length === 0 ? (
          <EmptyState
            title="NO RECENT ACADEMY ACTIVITY RECORDED"
            description="You have not completed any curriculum lessons or logged any training rounds yet. Begin by completing your admissions interview or executing your first prescribed drill."
            actionLabel={onboarding ? "START TODAY'S DRILL" : "START ONBOARDING INTERVIEW"}
            onAction={onboarding ? onStartTodayDrill : onOpenOnboarding}
            icon="workout"
          />
        ) : (
          <div className="space-y-2.5">
            {activityHistory.map((act) => (
              <div
                key={act.id}
                onClick={() => {
                  if (act.targetPage) onNavigate(act.targetPage);
                }}
                className="bg-[#141414] border border-[#2b2b2b] p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#444444] transition-colors cursor-pointer"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant={act.type === 'lesson_completed' ? 'accent' : 'neutral'} size="sm">
                      {act.type.replace('_', ' ')}
                    </Badge>
                    <span className="font-mono-tech text-[10px] text-[#777777]">
                      {act.timestamp}
                    </span>
                  </div>
                  <div className="font-condensed text-base font-bold uppercase text-[#F5F5F5]">
                    {act.title}
                  </div>
                  <p className="text-xs text-[#A3A3A3] font-sans">
                    {act.subtitle}
                  </p>
                </div>

                <div className="flex items-center gap-3 flex-shrink-0 self-start sm:self-auto">
                  {act.xpEarned > 0 && (
                    <span className="font-mono-tech text-xs text-[#D7263D] font-bold">
                      +{act.xpEarned} XP
                    </span>
                  )}
                  <ChevronRight className="w-4 h-4 text-[#777777]" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
