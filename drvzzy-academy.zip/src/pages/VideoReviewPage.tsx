import React, { useState } from 'react';
import { Film, Play, Clock, Plus, Tag, Eye, ChevronRight } from 'lucide-react';
import { Heading } from '../components/common/Heading';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { VideoReviewItem } from '../types/academy';

const INITIAL_VIDEO_REVIEWS: VideoReviewItem[] = [
  {
    id: 'vid-01',
    title: 'Pull-Counter Execution vs Aggressive Orthodox Rusher',
    sourceFighters: 'Mayweather vs Marquez / Academy Slow-Mo Drill #14',
    category: 'Counter-Timing',
    durationMin: 4,
    analysisFocus:
      'Notice the millimeter backward lean without weight compromise on the rear heel. As the opponent commit their jab, the right hand fires over the shoulder with zero delay.',
    keyTimestamps: [
      { time: '00:42', cue: 'Opponent steps forward; lead foot plants.' },
      { time: '01:15', cue: 'Torso rotates 3 inches off center without losing vertical axis.' },
      { time: '02:08', cue: 'Right cross connects flush; immediate exit angle taken.' },
    ],
    annotated: true,
  },
  {
    id: 'vid-02',
    title: 'The 90-Degree Check Hook & Ring Exit',
    sourceFighters: 'Mayweather vs Hatton / Academy Sparring Session #04',
    category: 'Footwork Angles',
    durationMin: 3,
    analysisFocus:
      'Pivoting on the lead foot like a revolving door. Swarmers carry forward momentum into ring posts or open canvas.',
    keyTimestamps: [
      { time: '00:30', cue: 'Swarm incoming with head low; defensive framing established.' },
      { time: '01:02', cue: 'Lead hook lands; rear leg swings 90 degrees simultaneously.' },
    ],
    annotated: true,
  },
];

export const VideoReviewPage: React.FC = () => {
  const [reviews, setReviews] = useState<VideoReviewItem[]>(INITIAL_VIDEO_REVIEWS);
  const [selectedReview, setSelectedReview] = useState<VideoReviewItem>(INITIAL_VIDEO_REVIEWS[0]);
  const [activeTimestamp, setActiveTimestamp] = useState<string>('00:42');

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <Heading
        badge="FILM STUDY LAB"
        title="VIDEO REVIEW & TACTICAL ANALYSIS"
        subtitle="Frame-by-frame deconstruction of high-level bouts and personal sparring tape. The eye must see the micro-cues before the body can react."
        actions={
          <Badge variant="accent">SLOW-MO FRAME BREAKDOWN</Badge>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Film Player Simulation Frame (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative bg-[#0d0d0d] border border-[#303030] aspect-video flex flex-col items-center justify-center p-6 text-center overflow-hidden">
            <div className="absolute inset-0 academy-scanline opacity-25 pointer-events-none" />
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="w-2 h-2 bg-[#D7263D] animate-pulse" />
              <span className="font-mono-tech text-[10px] text-[#D7263D] font-bold">
                FRAME ANALYZER // ACTIVE
              </span>
            </div>
            <div className="absolute top-3 right-3 font-mono-tech text-[10px] text-[#777777]">
              CUE: {activeTimestamp}
            </div>

            <div className="w-16 h-16 bg-[#161616] border border-[#303030] flex items-center justify-center text-[#D7263D] mb-3 hover:scale-105 transition-transform cursor-pointer">
              <Play className="w-8 h-8 fill-current ml-1" />
            </div>

            <h3 className="font-condensed text-xl sm:text-2xl font-bold uppercase text-[#F5F5F5] max-w-md">
              {selectedReview.title}
            </h3>
            <p className="text-xs font-mono-tech text-[#A3A3A3] mt-1">
              SOURCE: {selectedReview.sourceFighters}
            </p>

            {/* Video timeline scrubber bar */}
            <div className="absolute bottom-3 inset-x-4 flex items-center gap-3">
              <span className="font-mono-tech text-[10px] text-[#A3A3A3]">{activeTimestamp}</span>
              <div className="flex-1 bg-[#202020] h-1.5 border border-[#303030] relative">
                <div className="bg-[#D7263D] h-full w-2/5" />
              </div>
              <span className="font-mono-tech text-[10px] text-[#777777]">
                0{selectedReview.durationMin}:00
              </span>
            </div>
          </div>

          {/* Analysis description */}
          <div className="bg-[#141414] border border-[#303030] p-4 text-xs font-sans space-y-2">
            <div className="font-mono-tech text-[10px] text-[#D7263D] uppercase font-bold">
              COACH'S BREAKDOWN NOTES:
            </div>
            <p className="text-[#CCCCCC] leading-relaxed">
              {selectedReview.analysisFocus}
            </p>
          </div>
        </div>

        {/* Right: Key Timestamps & Review Catalog (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <Card
            variant="surface"
            headerBar={
              <>
                <span>KEY TIMESTAMPS & CUES</span>
                <span className="text-[#D7263D]">{selectedReview.keyTimestamps.length} ANNOTATIONS</span>
              </>
            }
          >
            <div className="space-y-2.5">
              {selectedReview.keyTimestamps.map((ts, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveTimestamp(ts.time)}
                  className={`w-full text-left p-3 border transition-colors cursor-pointer flex items-start gap-3 ${
                    activeTimestamp === ts.time
                      ? 'bg-[#191919] border-[#D7263D]'
                      : 'bg-[#121212] border-[#262626] hover:border-[#383838]'
                  }`}
                >
                  <span className="font-mono-tech text-xs text-[#D7263D] font-bold bg-[#1d1214] px-1.5 py-0.5 border border-[#3d1a1e]">
                    {ts.time}
                  </span>
                  <p className="text-xs text-[#CCCCCC] font-sans">
                    {ts.cue}
                  </p>
                </button>
              ))}
            </div>
          </Card>

          {/* Other archived films */}
          <Card variant="elevated">
            <div className="font-mono-tech text-xs uppercase text-[#A3A3A3] mb-3">
              ACADEMY TAPE ARCHIVE
            </div>
            <div className="space-y-2">
              {reviews.map((rev) => (
                <button
                  key={rev.id}
                  onClick={() => {
                    setSelectedReview(rev);
                    setActiveTimestamp(rev.keyTimestamps[0]?.time || '00:00');
                  }}
                  className={`w-full p-2.5 text-left border flex items-center justify-between transition-colors cursor-pointer ${
                    selectedReview.id === rev.id
                      ? 'bg-[#1d1416] border-[#D7263D]'
                      : 'bg-[#121212] border-[#262626] hover:border-[#383838]'
                  }`}
                >
                  <div>
                    <div className="font-condensed text-sm font-bold uppercase text-[#F5F5F5] truncate">
                      {rev.title}
                    </div>
                    <span className="font-mono-tech text-[10px] text-[#777777]">
                      {rev.category} • {rev.durationMin} MIN
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#A3A3A3]" />
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
