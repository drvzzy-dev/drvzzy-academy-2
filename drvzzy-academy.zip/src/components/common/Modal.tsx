import React, { useEffect } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { Button } from './Button';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onConfirm?: () => void;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  isLoading?: boolean;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  onConfirm,
  confirmLabel = 'CONFIRM',
  cancelLabel = 'CANCEL',
  isDestructive = false,
  isLoading = false,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div
        className="w-full max-w-lg bg-[#191919] border border-[#303030] shadow-2xl relative animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top technical accent line */}
        <div className={`h-1 w-full ${isDestructive ? 'bg-[#D7263D]' : 'bg-[#303030]'}`} />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#303030] bg-[#141414]">
          <div className="flex items-center gap-2.5">
            {isDestructive && <AlertTriangle className="w-5 h-5 text-[#D7263D]" />}
            <div>
              <h2
                id="modal-title"
                className="font-condensed text-xl font-bold uppercase tracking-wider text-[#F5F5F5]"
              >
                {title}
              </h2>
              {subtitle && (
                <p className="font-mono-tech text-[11px] text-[#A3A3A3] uppercase">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#A3A3A3] hover:text-[#F5F5F5] p-1 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 text-sm text-[#CCCCCC] leading-relaxed">
          {children}
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-[#303030] bg-[#141414]">
          <Button variant="ghost" size="sm" onClick={onClose} disabled={isLoading}>
            {cancelLabel}
          </Button>
          {onConfirm && (
            <Button
              variant={isDestructive ? 'danger' : 'primary'}
              size="sm"
              onClick={onConfirm}
              isLoading={isLoading}
            >
              {confirmLabel}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
