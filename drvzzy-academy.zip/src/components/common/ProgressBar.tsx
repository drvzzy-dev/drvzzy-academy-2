import React from 'react';

export interface ProgressBarProps {
  value: number; // percentage 0 - 100
  label?: string;
  sublabel?: string;
  showPercent?: boolean;
  variant?: 'accent' | 'neutral' | 'segmented';
  segments?: number;
  height?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  label,
  sublabel,
  showPercent = true,
  variant = 'accent',
  segments = 10,
  height = 'md',
  className = '',
}) => {
  const clampedValue = Math.min(100, Math.max(0, value));

  const heightClasses = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-4',
  };

  const fillColors = {
    accent: 'bg-[#D7263D]',
    neutral: 'bg-[#F5F5F5]',
    segmented: 'bg-[#D7263D]',
  };

  if (variant === 'segmented') {
    const activeSegments = Math.round((clampedValue / 100) * segments);
    return (
      <div className={`w-full ${className}`}>
        {(label || showPercent) && (
          <div className="flex justify-between items-baseline mb-1.5 font-mono-tech text-xs">
            <span className="text-[#A3A3A3] uppercase tracking-wider">{label}</span>
            {showPercent && (
              <span className="text-[#F5F5F5] font-bold">{clampedValue}%</span>
            )}
          </div>
        )}
        <div className="flex gap-1">
          {Array.from({ length: segments }).map((_, idx) => (
            <div
              key={idx}
              className={`flex-1 ${heightClasses[height]} border border-[#303030] transition-colors duration-200 ${
                idx < activeSegments
                  ? 'bg-[#D7263D] border-[#D7263D]'
                  : 'bg-[#121212]'
              }`}
            />
          ))}
        </div>
        {sublabel && (
          <div className="mt-1 text-[11px] font-mono-tech text-[#A3A3A3]">
            {sublabel}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`w-full ${className}`}>
      {(label || showPercent) && (
        <div className="flex justify-between items-baseline mb-1.5 font-mono-tech text-xs">
          <span className="text-[#A3A3A3] uppercase tracking-wider">{label}</span>
          {showPercent && (
            <span className="text-[#F5F5F5] font-bold">{clampedValue}%</span>
          )}
        </div>
      )}
      <div
        className={`w-full ${heightClasses[height]} bg-[#121212] border border-[#303030] overflow-hidden relative`}
      >
        <div
          className={`h-full ${fillColors[variant]} transition-all duration-300 ease-out`}
          style={{ width: `${clampedValue}%` }}
        />
      </div>
      {sublabel && (
        <div className="mt-1 text-[11px] font-mono-tech text-[#A3A3A3]">
          {sublabel}
        </div>
      )}
    </div>
  );
};
