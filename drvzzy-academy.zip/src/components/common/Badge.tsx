import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  variant?: 'accent' | 'neutral' | 'success' | 'warning' | 'muted' | 'locked';
  size?: 'sm' | 'md';
  hasDot?: boolean;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  hasDot = false,
  className = '',
}) => {
  const variantStyles = {
    accent: 'bg-[#D7263D]/10 text-[#D7263D] border-[#D7263D]/40',
    neutral: 'bg-[#191919] text-[#F5F5F5] border-[#303030]',
    success: 'bg-[#163820] text-[#34D399] border-[#059669]/40',
    warning: 'bg-[#3b2a0c] text-[#FBBF24] border-[#D97706]/40',
    muted: 'bg-[#121212] text-[#A3A3A3] border-[#252525]',
    locked: 'bg-[#0f0f0f] text-[#666666] border-[#202020]',
  };

  const dotColors = {
    accent: 'bg-[#D7263D]',
    neutral: 'bg-[#A3A3A3]',
    success: 'bg-[#34D399]',
    warning: 'bg-[#FBBF24]',
    muted: 'bg-[#666666]',
    locked: 'bg-[#444444]',
  };

  const sizeStyles = {
    sm: 'text-[10px] px-1.5 py-0.5 tracking-wider',
    md: 'text-xs px-2.5 py-1 tracking-widest',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono-tech uppercase font-medium border ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {hasDot && (
        <span
          className={`w-1.5 h-1.5 rounded-none flex-shrink-0 ${dotColors[variant]}`}
          aria-hidden="true"
        />
      )}
      <span>{children}</span>
    </span>
  );
};
