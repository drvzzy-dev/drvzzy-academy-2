import React from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';

export interface StatusAlertProps {
  type?: 'error' | 'warning' | 'info' | 'success';
  title?: string;
  children: React.ReactNode;
  onDismiss?: () => void;
  className?: string;
}

export const StatusAlert: React.FC<StatusAlertProps> = ({
  type = 'info',
  title,
  children,
  onDismiss,
  className = '',
}) => {
  const styles = {
    error: {
      border: 'border-l-4 border-l-[#D7263D] border-[#303030]',
      bg: 'bg-[#181112]',
      icon: <AlertCircle className="w-5 h-5 text-[#D7263D] flex-shrink-0" />,
      titleColor: 'text-[#D7263D]',
    },
    warning: {
      border: 'border-l-4 border-l-[#F59E0B] border-[#303030]',
      bg: 'bg-[#18150f]',
      icon: <AlertTriangle className="w-5 h-5 text-[#F59E0B] flex-shrink-0" />,
      titleColor: 'text-[#F59E0B]',
    },
    success: {
      border: 'border-l-4 border-l-[#10B981] border-[#303030]',
      bg: 'bg-[#0f1712]',
      icon: <CheckCircle2 className="w-5 h-5 text-[#10B981] flex-shrink-0" />,
      titleColor: 'text-[#10B981]',
    },
    info: {
      border: 'border-l-4 border-l-[#A3A3A3] border-[#303030]',
      bg: 'bg-[#141414]',
      icon: <Info className="w-5 h-5 text-[#A3A3A3] flex-shrink-0" />,
      titleColor: 'text-[#F5F5F5]',
    },
  };

  const current = styles[type];

  return (
    <div
      role="alert"
      className={`border p-4 ${current.border} ${current.bg} flex items-start justify-between gap-3 ${className}`}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5">{current.icon}</div>
        <div>
          {title && (
            <h4
              className={`font-mono-tech text-xs uppercase font-bold tracking-wider mb-1 ${current.titleColor}`}
            >
              {title}
            </h4>
          )}
          <div className="text-xs text-[#CCCCCC] leading-relaxed font-sans">
            {children}
          </div>
        </div>
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="text-[#777777] hover:text-[#F5F5F5] transition-colors p-1"
          aria-label="Dismiss alert"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
