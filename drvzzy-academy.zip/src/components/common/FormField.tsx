import React from 'react';

export interface BaseFieldProps {
  label?: string;
  helperText?: string;
  error?: string;
  required?: boolean;
  className?: string;
}

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    BaseFieldProps {}

export const Input: React.FC<InputProps> = ({
  label,
  helperText,
  error,
  required,
  className = '',
  id,
  ...props
}) => {
  const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label
          htmlFor={inputId}
          className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3] mb-1.5"
        >
          {label} {required && <span className="text-[#D7263D]">*</span>}
        </label>
      )}
      <input
        id={inputId}
        className={`w-full bg-[#121212] text-[#F5F5F5] placeholder-[#555555] border px-3.5 py-2.5 text-sm font-sans focus:outline-none transition-colors duration-150 ${
          error
            ? 'border-[#D7263D] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
            : 'border-[#303030] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
        } disabled:opacity-50 disabled:cursor-not-allowed`}
        {...props}
      />
      {error ? (
        <p className="mt-1 font-mono-tech text-[11px] text-[#D7263D]">{error}</p>
      ) : helperText ? (
        <p className="mt-1 font-mono-tech text-[11px] text-[#777777]">{helperText}</p>
      ) : null}
    </div>
  );
};

export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement>,
    BaseFieldProps {
  options: { value: string; label: string }[];
}

export const Select: React.FC<SelectProps> = ({
  label,
  helperText,
  error,
  required,
  options,
  className = '',
  id,
  ...props
}) => {
  const selectId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label
          htmlFor={selectId}
          className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3] mb-1.5"
        >
          {label} {required && <span className="text-[#D7263D]">*</span>}
        </label>
      )}
      <select
        id={selectId}
        className={`w-full bg-[#121212] text-[#F5F5F5] border px-3.5 py-2.5 text-sm font-sans focus:outline-none transition-colors duration-150 cursor-pointer ${
          error
            ? 'border-[#D7263D] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
            : 'border-[#303030] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
        } disabled:opacity-50`}
        {...props}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[#121212] text-[#F5F5F5]">
            {opt.label}
          </option>
        ))}
      </select>
      {error && <p className="mt-1 font-mono-tech text-[11px] text-[#D7263D]">{error}</p>}
    </div>
  );
};

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement>,
    BaseFieldProps {}

export const Textarea: React.FC<TextareaProps> = ({
  label,
  helperText,
  error,
  required,
  className = '',
  id,
  rows = 4,
  ...props
}) => {
  const areaId = id || (label ? label.toLowerCase().replace(/\s+/g, '-') : undefined);

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label
          htmlFor={areaId}
          className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3] mb-1.5"
        >
          {label} {required && <span className="text-[#D7263D]">*</span>}
        </label>
      )}
      <textarea
        id={areaId}
        rows={rows}
        className={`w-full bg-[#121212] text-[#F5F5F5] placeholder-[#555555] border px-3.5 py-2.5 text-sm font-sans focus:outline-none transition-colors duration-150 ${
          error
            ? 'border-[#D7263D] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
            : 'border-[#303030] focus:border-[#D7263D] focus:ring-1 focus:ring-[#D7263D]'
        } disabled:opacity-50`}
        {...props}
      />
      {error && <p className="mt-1 font-mono-tech text-[11px] text-[#D7263D]">{error}</p>}
      {helperText && !error && (
        <p className="mt-1 font-mono-tech text-[11px] text-[#777777]">{helperText}</p>
      )}
    </div>
  );
};

export interface CheckboxProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  helper?: string;
}

export const Checkbox: React.FC<CheckboxProps> = ({
  label,
  helper,
  className = '',
  id,
  ...props
}) => {
  const checkId = id || label.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className={`flex items-start gap-3 ${className}`}>
      <input
        type="checkbox"
        id={checkId}
        className="w-4 h-4 mt-0.5 bg-[#121212] border border-[#303030] text-[#D7263D] focus:ring-[#D7263D] focus:ring-offset-0 rounded-none cursor-pointer"
        {...props}
      />
      <div>
        <label
          htmlFor={checkId}
          className="text-sm font-sans text-[#F5F5F5] cursor-pointer select-none"
        >
          {label}
        </label>
        {helper && (
          <p className="text-xs text-[#A3A3A3] font-mono-tech mt-0.5">{helper}</p>
        )}
      </div>
    </div>
  );
};
