import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'elevated' | 'surface' | 'accent-border' | 'ghost';
  withCrosshairs?: boolean;
  headerBar?: React.ReactNode;
  footerBar?: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'elevated',
  withCrosshairs = false,
  headerBar,
  footerBar,
  className = '',
  ...props
}) => {
  const variantStyles = {
    elevated: 'bg-[#191919] border-[#303030]',
    surface: 'bg-[#121212] border-[#262626]',
    'accent-border': 'bg-[#191919] border-[#303030] border-l-4 border-l-[#D7263D]',
    ghost: 'bg-transparent border-[#262626]',
  };

  return (
    <div
      className={`relative border text-[#F5F5F5] ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {/* Optional technical corner marks */}
      {withCrosshairs && (
        <>
          <div className="absolute -top-1 -left-1 w-2 h-2 text-[#D7263D] font-mono-tech text-[8px] leading-none select-none pointer-events-none">
            +
          </div>
          <div className="absolute -top-1 -right-1 w-2 h-2 text-[#D7263D] font-mono-tech text-[8px] leading-none select-none pointer-events-none">
            +
          </div>
          <div className="absolute -bottom-1 -left-1 w-2 h-2 text-[#303030] font-mono-tech text-[8px] leading-none select-none pointer-events-none">
            +
          </div>
          <div className="absolute -bottom-1 -right-1 w-2 h-2 text-[#303030] font-mono-tech text-[8px] leading-none select-none pointer-events-none">
            +
          </div>
        </>
      )}

      {headerBar && (
        <div className="border-b border-[#303030] bg-[#141414] px-4 py-2 flex items-center justify-between text-xs font-mono-tech uppercase tracking-wider text-[#A3A3A3]">
          {headerBar}
        </div>
      )}

      <div className="p-4 sm:p-5">{children}</div>

      {footerBar && (
        <div className="border-t border-[#303030] bg-[#141414] px-4 py-2.5 flex items-center justify-between text-xs">
          {footerBar}
        </div>
      )}
    </div>
  );
};
