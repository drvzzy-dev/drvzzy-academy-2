import React from 'react';

export interface HeadingProps {
  badge?: string;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  level?: 1 | 2 | 3;
  className?: string;
}

export const Heading: React.FC<HeadingProps> = ({
  badge,
  title,
  subtitle,
  actions,
  level = 1,
  className = '',
}) => {
  const titleClasses = {
    1: 'text-2xl sm:text-4xl lg:text-5xl font-black',
    2: 'text-xl sm:text-2xl lg:text-3xl font-black',
    3: 'text-lg sm:text-xl font-bold',
  };

  return (
    <div
      className={`border-b border-[#303030] pb-4 mb-6 flex flex-col md:flex-row md:items-end justify-between gap-4 ${className}`}
    >
      <div>
        {badge && (
          <div className="font-mono-tech text-[11px] text-[#D7263D] uppercase tracking-widest mb-1.5 flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[#D7263D]" />
            <span>{badge}</span>
          </div>
        )}
        <h1
          className={`font-condensed uppercase tracking-tight text-[#F5F5F5] ${titleClasses[level]}`}
        >
          {title}
        </h1>
        {subtitle && (
          <p className="mt-1 text-sm text-[#A3A3A3] max-w-2xl font-normal leading-relaxed">
            {subtitle}
          </p>
        )}
      </div>
      {actions && (
        <div className="flex items-center gap-2 flex-shrink-0 self-start md:self-auto">
          {actions}
        </div>
      )}
    </div>
  );
};
