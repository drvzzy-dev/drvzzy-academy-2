import React from 'react';
import { ShieldAlert, Crosshair, Dumbbell } from 'lucide-react';
import { Button } from './Button';

export interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: 'crosshair' | 'shield' | 'workout';
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionLabel,
  onAction,
  icon = 'crosshair',
  className = '',
}) => {
  const renderIcon = () => {
    switch (icon) {
      case 'shield':
        return <ShieldAlert className="w-8 h-8 text-[#A3A3A3]" />;
      case 'workout':
        return <Dumbbell className="w-8 h-8 text-[#A3A3A3]" />;
      default:
        return <Crosshair className="w-8 h-8 text-[#A3A3A3]" />;
    }
  };

  return (
    <div
      className={`border border-dashed border-[#303030] bg-[#121212]/60 p-8 sm:p-12 text-center flex flex-col items-center justify-center ${className}`}
    >
      <div className="w-14 h-14 bg-[#191919] border border-[#303030] flex items-center justify-center mb-4 text-[#D7263D]">
        {renderIcon()}
      </div>
      <div className="font-mono-tech text-[10px] text-[#D7263D] uppercase tracking-widest mb-1">
        // NO RECORDS FOUND
      </div>
      <h3 className="font-condensed text-xl sm:text-2xl font-bold uppercase tracking-wide text-[#F5F5F5] mb-2">
        {title}
      </h3>
      <p className="text-sm text-[#A3A3A3] max-w-md mb-6 leading-relaxed">
        {description}
      </p>
      {actionLabel && onAction && (
        <Button variant="secondary" size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};
