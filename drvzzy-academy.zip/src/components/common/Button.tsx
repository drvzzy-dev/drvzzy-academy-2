import React from 'react';
import { Loader2 } from 'lucide-react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  fullWidth = false,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses =
    'relative inline-flex items-center justify-center font-condensed uppercase tracking-wider font-bold transition-all duration-150 focus:outline-none focus:ring-1 focus:ring-[#D7263D] disabled:opacity-40 disabled:cursor-not-allowed select-none border cursor-pointer';

  const sizeClasses = {
    sm: 'text-xs px-3 py-1.5 tracking-wider',
    md: 'text-sm px-4 py-2.5 tracking-widest',
    lg: 'text-base px-6 py-3.5 tracking-widest',
  };

  const variantClasses = {
    primary:
      'bg-[#D7263D] text-[#F5F5F5] border-[#D7263D] hover:bg-[#801D2B] hover:border-[#801D2B] active:translate-y-[1px]',
    secondary:
      'bg-[#191919] text-[#F5F5F5] border-[#303030] hover:bg-[#252525] hover:border-[#454545] active:translate-y-[1px]',
    outline:
      'bg-transparent text-[#F5F5F5] border-[#303030] hover:border-[#D7263D] hover:text-[#D7263D] active:translate-y-[1px]',
    ghost:
      'bg-transparent text-[#A3A3A3] border-transparent hover:text-[#F5F5F5] hover:bg-[#191919]',
    danger:
      'bg-[#801D2B] text-[#F5F5F5] border-[#D7263D] hover:bg-[#D7263D] active:translate-y-[1px]',
  };

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 mr-2 animate-spin text-current" />
      ) : (
        leftIcon && <span className="mr-2 inline-flex items-center">{leftIcon}</span>
      )}
      <span>{children}</span>
      {!isLoading && rightIcon && (
        <span className="ml-2 inline-flex items-center">{rightIcon}</span>
      )}
    </button>
  );
};
