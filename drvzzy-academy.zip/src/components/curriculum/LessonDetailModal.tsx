import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  CheckCircle2,
  AlertTriangle,
  BookOpen,
  Dumbbell,
  HelpCircle,
  FileText,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Check,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { LessonItem, TechniqueItem, KnowledgeCheckSubmission } from '../../types/academy';
import { Badge } from '../common/Badge';
import { Button } from '../common/Button';
import { gradeKnowledgeCheck } from '../../utils/curriculum';

export interface LessonDetailModalProps {
  lesson: LessonItem;
  isOpen: boolean;
  onClose: () => void;
  isUnlocked: boolean;
  isCompleted: boolean;
  prerequisiteTitles: string[];
  existingSubmission?: KnowledgeCheckSubmission;
  onCompleteLesson: (lessonId: string, reflection?: string) => void;
  onSaveKnowledgeCheck?: (lessonId: string, submission: KnowledgeCheckSubmission) => void;
  onOpenRelatedLesson?: (lessonId: string) => void;
  onOpenRelatedTechnique?: (techniqueId: string) => void;
  allTechniques?: TechniqueItem[];
  allLessons?: LessonItem[];
}

export const LessonDetailModal: React.FC<LessonDetailModalProps> = ({
  lesson,
  isOpen,
  onClose,
  isUnlocked,
  isCompleted,
  prerequisiteTitles,
  existingSubmission,
  onCompleteLesson,
  onSaveKnowledgeCheck,
  onOpenRelatedLesson,
  onOpenRelatedTechnique,
  allTechniques = [],
  allLessons = [],
}) => {
  const [activeTab, setActiveTab] = useState<'study' | 'drills' | 'quiz' | 'reflection'>('study');
  
  // Knowledge check state
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>(() => {
    if (existingSubmission?.selectedAnswers) {
      return existingSubmission.selectedAnswers;
    }
    return new Array(lesson.knowledgeCheck.length).fill(-1);
  });
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(() => Boolean(existingSubmission));
  const [quizResult, setQuizResult] = useState<{
    passed: boolean;
    score: number;
    total: number;
    questionResults: { questionId: string; isCorrect: boolean; explanation: string }[];
  } | null>(() => {
    if (existingSubmission) {
      return gradeKnowledgeCheck(lesson, existingSubmission.selectedAnswers);
    }
    return null;
  });

  // Reflection text
  const [reflectionText, setReflectionText] = useState<string>(
    existingSubmission?.reflectionText || ''
  );
  const [reflectionSaved, setReflectionSaved] = useState<boolean>(false);

  // Sync state when lesson changes
  useEffect(() => {
    if (existingSubmission) {
      setSelectedAnswers(existingSubmission.selectedAnswers);
      setQuizSubmitted(true);
      setQuizResult(gradeKnowledgeCheck(lesson, existingSubmission.selectedAnswers));
      setReflectionText(existingSubmission.reflectionText || '');
    } else {
      setSelectedAnswers(new Array(lesson.knowledgeCheck.length).fill(-1));
      setQuizSubmitted(false);
      setQuizResult(null);
      setReflectionText('');
    }
    setReflectionSaved(false);
    setActiveTab('study');
  }, [lesson.id, existingSubmission]);

  if (!isOpen) return null;

  const handleSelectAnswer = (qIdx: number, optIdx: number) => {
    if (quizSubmitted && quizResult?.passed) return; // Prevent changing after pass
    const updated = [...selectedAnswers];
    updated[qIdx] = optIdx;
    setSelectedAnswers(updated);
  };

  const handleSubmitQuiz = () => {
    const result = gradeKnowledgeCheck(lesson, selectedAnswers);
    setQuizResult(result);
    setQuizSubmitted(true);

    if (onSaveKnowledgeCheck) {
      onSaveKnowledgeCheck(lesson.id, {
        passed: result.passed,
        selectedAnswers,
        reflectionText,
        completedAt: new Date().toISOString(),
      });
    }
  };

  const handleResetQuiz = () => {
    setSelectedAnswers(new Array(lesson.knowledgeCheck.length).fill(-1));
    setQuizSubmitted(false);
    setQuizResult(null);
  };

  const handleSaveReflection = () => {
    setReflectionSaved(true);
    if (onSaveKnowledgeCheck) {
      onSaveKnowledgeCheck(lesson.id, {
        passed: quizResult?.passed || false,
        selectedAnswers,
        reflectionText,
        completedAt: new Date().toISOString(),
      });
    }
    setTimeout(() => setReflectionSaved(false), 2500);
  };

  const handleFinalMarkComplete = () => {
    if (!isUnlocked) return;
    onCompleteLesson(lesson.id, reflectionText);
  };

  const relatedTechObjects = allTechniques.filter((t) => lesson.relatedTechniqueIds.includes(t.id));

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-4xl bg-[#141414] border border-[#303030] shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Top Crimson Accent Strip */}
        <div className="h-1 bg-[#D7263D] w-full" />

        {/* Modal Header */}
        <div className="p-4 sm:p-6 border-b border-[#262626] flex items-start justify-between gap-4 bg-[#111111]">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1.5 font-mono-tech text-xs">
              <span className="text-[#D7263D] font-bold">
                PHASE {lesson.phaseNumber} // LEVEL {lesson.levelNumber < 10 ? `0${lesson.levelNumber}` : lesson.levelNumber}
              </span>
              <span className="text-[#555555]">•</span>
              <Badge variant="accent" size="sm">{lesson.difficulty}</Badge>
              <Badge variant="neutral" size="sm">{lesson.estimatedDurationMin} MIN PROTOCOL</Badge>
              <Badge variant="muted" size="sm">+{lesson.xpReward} XP</Badge>
            </div>

            <h2 className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5] tracking-wide leading-tight">
              {lesson.title}
            </h2>

            <div className="flex flex-wrap gap-1.5 mt-2">
              {lesson.pillars.map((pillar, idx) => (
                <span
                  key={idx}
                  className="font-mono-tech text-[10px] bg-[#1c1c1c] text-[#A3A3A3] px-2 py-0.5 border border-[#303030]"
                >
                  PILLAR: {pillar}
                </span>
              ))}
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-[#888888] hover:text-[#F5F5F5] font-mono-tech text-xs p-1.5 hover:bg-[#202020] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Callout Bar */}
        {!isUnlocked ? (
          <div className="bg-[#241315] border-y border-[#4a1c22] px-4 py-2.5 flex items-center justify-between text-xs text-[#F87171] font-mono-tech">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 flex-shrink-0" />
              <span>
                PREREQUISITE LOCKED: Complete{' '}
                <strong className="text-[#F5F5F5]">
                  {prerequisiteTitles.join(', ') || 'prior foundation lessons'}
                </strong>{' '}
                to unlock this syllabus.
              </span>
            </div>
            <span className="uppercase text-[10px] tracking-wider text-[#FCA5A5]">// RESTRICTED</span>
          </div>
        ) : isCompleted ? (
          <div className="bg-[#122417] border-y border-[#1d4626] px-4 py-2 flex items-center justify-between text-xs text-[#34D399] font-mono-tech">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>LESSON VERIFIED — XP CREDITED TO FIGHTER PROFILE</span>
            </div>
            <span className="uppercase text-[10px] tracking-wider text-[#A7F3D0]">// COMPLETED</span>
          </div>
        ) : null}

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#262626] bg-[#0f0f0f] px-4 sm:px-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('study')}
            className={`py-3 px-3 sm:px-4 font-mono-tech text-xs uppercase tracking-wider border-b-2 cursor-pointer flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === 'study'
                ? 'border-[#D7263D] text-[#F5F5F5] font-bold bg-[#141414]'
                : 'border-transparent text-[#777777] hover:text-[#F5F5F5]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            01. Theory & Biomechanics
          </button>

          <button
            onClick={() => setActiveTab('drills')}
            className={`py-3 px-3 sm:px-4 font-mono-tech text-xs uppercase tracking-wider border-b-2 cursor-pointer flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === 'drills'
                ? 'border-[#D7263D] text-[#F5F5F5] font-bold bg-[#141414]'
                : 'border-transparent text-[#777777] hover:text-[#F5F5F5]'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5" />
            02. Controlled Practice
          </button>

          <button
            onClick={() => setActiveTab('quiz')}
            className={`py-3 px-3 sm:px-4 font-mono-tech text-xs uppercase tracking-wider border-b-2 cursor-pointer flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === 'quiz'
                ? 'border-[#D7263D] text-[#F5F5F5] font-bold bg-[#141414]'
                : 'border-transparent text-[#777777] hover:text-[#F5F5F5]'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            03. Knowledge Check
            {quizResult?.passed && <Check className="w-3 h-3 text-[#10B981]" />}
          </button>

          <button
            onClick={() => setActiveTab('reflection')}
            className={`py-3 px-3 sm:px-4 font-mono-tech text-xs uppercase tracking-wider border-b-2 cursor-pointer flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === 'reflection'
                ? 'border-[#D7263D] text-[#F5F5F5] font-bold bg-[#141414]'
                : 'border-transparent text-[#777777] hover:text-[#F5F5F5]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            04. Training Notes
          </button>
        </div>

        {/* Main Tab Content Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: THEORY & BIOMECHANICS */}
          {activeTab === 'study' && (
            <div className="space-y-6">
              {/* Educational Explanation */}
              <div className="bg-[#181818] border border-[#2b2b2b] p-4 sm:p-5">
                <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider mb-2 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#D7263D]" />
                  CONCEPTUAL BLUEPRINT
                </div>
                <p className="text-sm text-[#DDDDDD] font-sans leading-relaxed">
                  {lesson.mainExplanation}
                </p>
              </div>

              {/* Learning Objectives */}
              <div>
                <h3 className="font-condensed text-lg font-bold uppercase tracking-wide text-[#F5F5F5] mb-2.5">
                  CORE LEARNING OBJECTIVES
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {lesson.learningObjectives.map((obj, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-[#131313] border border-[#262626] flex items-start gap-3"
                    >
                      <span className="font-mono-tech text-xs text-[#D7263D] font-bold mt-0.5">
                        0{idx + 1}
                      </span>
                      <p className="text-xs text-[#CCCCCC] leading-relaxed">{obj}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step-by-Step Biomechanical Breakdown */}
              <div>
                <h3 className="font-condensed text-lg font-bold uppercase tracking-wide text-[#F5F5F5] mb-2.5">
                  KINETIC EXECUTION BREAKDOWN
                </h3>
                <div className="space-y-2.5">
                  {lesson.conceptualBreakdown.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-[#161616] border-l-2 border-l-[#D7263D] border border-[#262626]"
                    >
                      <div className="font-condensed text-base font-bold uppercase text-[#F5F5F5] mb-1">
                        PHASE {idx + 1}: {item.step}
                      </div>
                      <p className="text-xs text-[#A3A3A3] leading-relaxed font-sans">
                        {item.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Common Mistakes & Safety Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Faults */}
                <div className="bg-[#181413] border border-[#3d241c] p-4">
                  <div className="font-mono-tech text-xs text-[#F59E0B] uppercase font-bold tracking-wider mb-2 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#F59E0B]" />
                    TECHNICAL FAULTS TO AVOID
                  </div>
                  <ul className="space-y-2">
                    {lesson.commonMistakes.map((fault, idx) => (
                      <li key={idx} className="text-xs text-[#E5D5C5] flex items-start gap-2">
                        <span className="text-[#F59E0B] font-bold mt-0.5">✕</span>
                        <span>{fault}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Safety Considerations */}
                <div className="bg-[#121915] border border-[#1b3d24] p-4">
                  <div className="font-mono-tech text-xs text-[#34D399] uppercase font-bold tracking-wider mb-2 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#34D399]" />
                    SAFETY & JOINT PRESERVATION
                  </div>
                  <ul className="space-y-2">
                    {lesson.safetyConsiderations.map((safety, idx) => (
                      <li key={idx} className="text-xs text-[#C5E5D0] flex items-start gap-2">
                        <span className="text-[#34D399] font-bold mt-0.5">✓</span>
                        <span>{safety}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Cross-Referenced Techniques */}
              {relatedTechObjects.length > 0 && (
                <div className="pt-2 border-t border-[#262626]">
                  <h4 className="font-mono-tech text-xs text-[#777777] uppercase mb-2">
                    RELATED TECHNIQUE DOSSIERS:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {relatedTechObjects.map((tech) => (
                      <div
                        key={tech.id}
                        onClick={() => onOpenRelatedTechnique && onOpenRelatedTechnique(tech.id)}
                        className="p-3 bg-[#111111] border border-[#2a2a2a] hover:border-[#D7263D] transition-all cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <span className="font-mono-tech text-[10px] text-[#D7263D] block">
                            {tech.code}
                          </span>
                          <span className="font-condensed text-sm font-bold uppercase text-[#F5F5F5]">
                            {tech.name}
                          </span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-[#777777]" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CONTROLLED PRACTICE DRILLS */}
          {activeTab === 'drills' && (
            <div className="space-y-6">
              <div className="bg-[#181818] border border-[#2b2b2b] p-5">
                <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Dumbbell className="w-4 h-4 text-[#D7263D]" />
                  CONTROLLED DRILL PROTOCOL
                </div>
                <h3 className="font-condensed text-xl font-bold uppercase text-[#F5F5F5] mb-2">
                  {lesson.title} — PRACTICAL CALIBRATION
                </h3>
                <p className="text-sm text-[#CCCCCC] font-sans leading-relaxed">
                  {lesson.suggestedPractice}
                </p>
              </div>

              {/* Completion Criteria Protocol */}
              <div className="bg-[#131313] border-l-4 border-l-[#10B981] border border-[#262626] p-4">
                <span className="font-mono-tech text-[10px] text-[#10B981] uppercase font-bold tracking-wider block mb-1">
                  OFFICIAL COMPLETION CRITERIA:
                </span>
                <p className="text-xs text-[#E5E5E5] font-sans leading-relaxed">
                  {lesson.completionCriteria}
                </p>
              </div>

              {/* Responsible Training Note */}
              <div className="p-4 bg-[#141414] border border-[#262626] text-xs text-[#777777] font-mono-tech flex items-start gap-2.5">
                <span className="text-[#D7263D] font-bold">!</span>
                <span>
                  DRVZZY ACADEMY enforces zero dangerous shortcuts. Never practice high-impact strikes on rigid unyielding objects. Always wrap hands before hitting heavy equipment.
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: INTERACTIVE KNOWLEDGE CHECK */}
          {activeTab === 'quiz' && (
            <div className="space-y-6">
              <div className="bg-[#161616] border border-[#262626] p-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono-tech text-xs text-[#D7263D] font-bold uppercase">
                    COMPREHENSION EVALUATION
                  </span>
                  <span className="font-mono-tech text-xs text-[#777777]">
                    {lesson.knowledgeCheck.length} QUESTIONS
                  </span>
                </div>
                <p className="text-xs text-[#A3A3A3]">
                  Answer the theoretical questions below to test your technical understanding. An accurate understanding of biomechanics is required before advanced progression.
                </p>
              </div>

              {/* Questions List */}
              <div className="space-y-5">
                {lesson.knowledgeCheck.map((q, qIdx) => {
                  const userAnswer = selectedAnswers[qIdx];
                  const qResult = quizResult?.questionResults[qIdx];

                  return (
                    <div
                      key={q.id}
                      className={`p-4 sm:p-5 border ${
                        quizSubmitted
                          ? qResult?.isCorrect
                            ? 'bg-[#122216] border-[#1d4626]'
                            : 'bg-[#221316] border-[#4c1c24]'
                          : 'bg-[#121212] border-[#262626]'
                      }`}
                    >
                      <div className="font-mono-tech text-xs text-[#777777] mb-1">
                        QUESTION 0{qIdx + 1} OF 0{lesson.knowledgeCheck.length}
                      </div>
                      <h4 className="font-condensed text-lg font-bold text-[#F5F5F5] mb-3">
                        {q.question}
                      </h4>

                      <div className="space-y-2">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = userAnswer === optIdx;
                          const isCorrect = q.correctIndex === optIdx;

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectAnswer(qIdx, optIdx)}
                              disabled={quizSubmitted && quizResult?.passed}
                              className={`w-full text-left p-3 text-xs font-sans transition-all border flex items-center justify-between cursor-pointer ${
                                isSelected
                                  ? quizSubmitted
                                    ? isCorrect
                                      ? 'bg-[#1c3a23] border-[#34D399] text-[#FFFFFF] font-bold'
                                      : 'bg-[#3b171c] border-[#EF4444] text-[#FFFFFF] font-bold'
                                    : 'bg-[#202020] border-[#D7263D] text-[#F5F5F5] font-semibold'
                                  : quizSubmitted && isCorrect
                                  ? 'bg-[#182b1d] border-[#10B981] text-[#A7F3D0]'
                                  : 'bg-[#171717] border-[#292929] text-[#CCCCCC] hover:border-[#404040]'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span
                                  className={`w-5 h-5 rounded-none border font-mono-tech text-[10px] flex items-center justify-center font-bold ${
                                    isSelected
                                      ? 'bg-[#D7263D] border-[#D7263D] text-[#FFFFFF]'
                                      : 'border-[#404040] text-[#777777]'
                                  }`}
                                >
                                  {String.fromCharCode(65 + optIdx)}
                                </span>
                                <span>{opt}</span>
                              </div>

                              {quizSubmitted && isCorrect && (
                                <span className="font-mono-tech text-[10px] text-[#34D399] font-bold uppercase">
                                  CORRECT
                                </span>
                              )}
                              {quizSubmitted && isSelected && !isCorrect && (
                                <span className="font-mono-tech text-[10px] text-[#F87171] font-bold uppercase">
                                  INCORRECT
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Explanation Feedback Box */}
                      {quizSubmitted && (
                        <div
                          className={`mt-3 p-3 text-xs leading-relaxed border ${
                            qResult?.isCorrect
                              ? 'bg-[#152618] border-[#224426] text-[#A7F3D0]'
                              : 'bg-[#29171b] border-[#4d1f27] text-[#FCA5A5]'
                          }`}
                        >
                          <span className="font-mono-tech text-[10px] font-bold uppercase block mb-0.5">
                            {qResult?.isCorrect ? '// EXPLANATION:' : '// CORRECT ANSWER ANALYSIS:'}
                          </span>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Submit / Reset Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <div>
                  {quizSubmitted && quizResult && (
                    <div className="font-mono-tech text-xs">
                      SCORE:{' '}
                      <span
                        className={
                          quizResult.passed ? 'text-[#34D399] font-bold' : 'text-[#EF4444] font-bold'
                        }
                      >
                        {quizResult.score} / {quizResult.total}{' '}
                        {quizResult.passed ? '(100% MASTERY VERIFIED)' : '(REQUIRES RETAKE)'}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {quizSubmitted && !quizResult?.passed && (
                    <Button variant="outline" size="sm" onClick={handleResetQuiz}>
                      RETRY KNOWLEDGE CHECK
                    </Button>
                  )}
                  {!quizSubmitted && (
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={handleSubmitQuiz}
                      disabled={selectedAnswers.some((a) => a === -1)}
                    >
                      SUBMIT ANSWERS FOR EVALUATION
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TRAINING REFLECTION NOTES */}
          {activeTab === 'reflection' && (
            <div className="space-y-4">
              <div className="bg-[#181818] border border-[#2b2b2b] p-4">
                <div className="font-mono-tech text-xs text-[#D7263D] uppercase tracking-wider mb-1 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#D7263D]" />
                  TECHNICAL REFLECTION PROMPT
                </div>
                <p className="text-sm text-[#F5F5F5] font-sans font-medium">
                  "{lesson.reflectionPrompt}"
                </p>
              </div>

              <div>
                <label className="block font-mono-tech text-xs uppercase text-[#A3A3A3] mb-1.5">
                  YOUR PERSONAL TRAINING JOURNAL ENTRY:
                </label>
                <textarea
                  rows={6}
                  value={reflectionText}
                  onChange={(e) => setReflectionText(e.target.value)}
                  placeholder="Record your observations, fatigue points, balance tendencies, or questions for further mirror review..."
                  className="w-full bg-[#121212] border border-[#303030] p-3 text-sm text-[#F5F5F5] focus:outline-hidden focus:border-[#D7263D] resize-none font-sans"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-tech text-[#777777]">
                  * Saved locally with your fighter profile.
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSaveReflection}
                  disabled={!reflectionText.trim()}
                >
                  {reflectionSaved ? '✓ JOURNAL ENTRY SAVED' : 'SAVE REFLECTION'}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Bar */}
        <div className="p-4 sm:p-5 border-t border-[#262626] bg-[#111111] flex flex-wrap items-center justify-between gap-3">
          <div className="font-mono-tech text-xs text-[#777777]">
            {isCompleted ? (
              <span className="text-[#34D399] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> COMPLETED // +{lesson.xpReward} XP EARNED
              </span>
            ) : !isUnlocked ? (
              <span className="text-[#EF4444] flex items-center gap-1.5">
                <Lock className="w-4 h-4" /> LOCKED BY PREREQUISITES
              </span>
            ) : (
              <span>SYLLABUS UNLOCKED // READY TO LOG BENCHMARK</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onClose}>
              CLOSE
            </Button>

            {isUnlocked && !isCompleted && (
              <Button
                variant="primary"
                size="md"
                onClick={handleFinalMarkComplete}
              >
                MARK COMPLETE (+{lesson.xpReward} XP)
              </Button>
            )}

            {isCompleted && (
              <Button variant="outline" size="sm" onClick={onClose}>
                CONTINUE CURRICULUM
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
