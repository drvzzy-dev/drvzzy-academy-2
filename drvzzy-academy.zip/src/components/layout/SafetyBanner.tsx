import React from 'react';
import { ShieldCheck, ChevronRight } from 'lucide-react';
import { SAFETY_PROTOCOLS } from '../../data/initialData';

export interface SafetyBannerProps {
  onOpenFullProtocols: () => void;
}

export const SafetyBanner: React.FC<SafetyBannerProps> = ({
  onOpenFullProtocols,
}) => {
  return (
    <div className="bg-[#141011] border-b border-[#3d181d] px-4 py-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
      <div className="flex items-center gap-2.5">
        <span className="p-1 bg-[#D7263D]/20 text-[#D7263D] border border-[#D7263D]/40">
          <ShieldCheck className="w-3.5 h-3.5" />
        </span>
        <div className="flex flex-wrap items-center gap-x-2">
          <span className="font-mono-tech text-[10px] text-[#D7263D] font-bold uppercase tracking-wider">
            RESPONSIBLE PUGILISM MANDATE:
          </span>
          <span className="text-[#CCCCCC] text-[11px]">
            180" Hand Wraps & Qualified Coach Supervision Required for All Contact.
          </span>
        </div>
      </div>

      <button
        onClick={onOpenFullProtocols}
        className="text-[11px] font-mono-tech text-[#D7263D] hover:text-[#F5F5F5] uppercase tracking-wider flex items-center gap-1 transition-colors underline sm:no-underline cursor-pointer flex-shrink-0"
      >
        <span>SAFETY PROTOCOLS ({SAFETY_PROTOCOLS.length})</span>
        <ChevronRight className="w-3 h-3" />
      </button>
    </div>
  );
};
