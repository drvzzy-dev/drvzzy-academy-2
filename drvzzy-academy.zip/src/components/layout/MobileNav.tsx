import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { NavigationPage } from '../../types/academy';
import { NAV_ITEMS } from './SidebarNav';

export interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  activePage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  isOpen,
  onClose,
  activePage,
  onNavigate,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 lg:hidden flex"
      role="dialog"
      aria-modal="true"
      aria-label="Mobile Navigation"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div className="relative w-4/5 max-w-sm bg-[#121212] border-r border-[#303030] h-full flex flex-col z-10 animate-in slide-in-from-left duration-200">
        <div className="p-4 border-b border-[#303030] flex items-center justify-between bg-[#0d0d0d]">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[#D7263D] text-[#F5F5F5] font-condensed font-black flex items-center justify-center text-xs">
              DZ
            </div>
            <span className="font-condensed font-black uppercase tracking-wider text-base text-[#F5F5F5]">
              DRVZZY ACADEMY
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#A3A3A3] hover:text-[#F5F5F5] border border-[#303030] bg-[#191919] cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-2 bg-[#161616] text-[10px] font-mono-tech uppercase text-[#D7263D] tracking-widest border-b border-[#262626]">
          // DIRECT NAVIGATION (10 MODULES)
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-3 text-left border transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#191919] text-[#F5F5F5] border-l-4 border-l-[#D7263D] border-[#303030] font-bold'
                    : 'bg-transparent text-[#A3A3A3] border-transparent hover:bg-[#161616]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={isActive ? 'text-[#D7263D]' : 'text-[#777777]'}>
                    {item.icon}
                  </span>
                  <span className="font-condensed text-base uppercase tracking-wider">
                    {item.label}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {item.badge && (
                    <span className="font-mono-tech text-[9px] px-1.5 py-0.5 border border-[#303030] text-[#888888]">
                      {item.badge}
                    </span>
                  )}
                  <span className="font-mono-tech text-[10px] text-[#555555]">
                    {item.code}
                  </span>
                </div>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#303030] bg-[#0d0d0d] text-center">
          <p className="font-mono-tech text-[10px] text-[#A3A3A3] uppercase tracking-widest">
            "STUDY THE CRAFT. EARN YOUR LEVEL."
          </p>
        </div>
      </div>
    </div>
  );
};
