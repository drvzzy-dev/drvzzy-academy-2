import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  Dumbbell,
  BookOpen,
  Sword,
  ScrollText,
  Film,
  Trophy,
  User,
  Settings,
} from 'lucide-react';
import { NavigationPage, FighterProfile, Rank } from '../../types/academy';

export interface NavItemConfig {
  id: NavigationPage;
  label: string;
  icon: React.ReactNode;
  badge?: string;
  code: string;
}

export const NAV_ITEMS: NavItemConfig[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    code: '01',
    icon: <LayoutDashboard className="w-4 h-4" />,
  },
  {
    id: 'academy',
    label: 'Academy / Curriculum',
    code: '02',
    icon: <GraduationCap className="w-4 h-4" />,
    badge: '24 LVLS',
  },
  {
    id: 'training',
    label: 'Training',
    code: '03',
    icon: <Dumbbell className="w-4 h-4" />,
    badge: '6 PLRS',
  },
  {
    id: 'techniques',
    label: 'Technique Library',
    code: '04',
    icon: <BookOpen className="w-4 h-4" />,
  },
  {
    id: 'tactical',
    label: 'Tactical Study',
    code: '05',
    icon: <Sword className="w-4 h-4" />,
  },
  {
    id: 'journal',
    label: 'Training Journal',
    code: '06',
    icon: <ScrollText className="w-4 h-4" />,
  },
  {
    id: 'video-review',
    label: 'Video Review Lab',
    code: '07',
    icon: <Film className="w-4 h-4" />,
  },
  {
    id: 'progression',
    label: 'Progression / Achievements',
    code: '08',
    icon: <Trophy className="w-4 h-4" />,
    badge: '8 RNKS',
  },
  {
    id: 'profile',
    label: 'Fighter Profile',
    code: '09',
    icon: <User className="w-4 h-4" />,
  },
  {
    id: 'settings',
    label: 'Settings',
    code: '10',
    icon: <Settings className="w-4 h-4" />,
  },
];

export interface SidebarNavProps {
  activePage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
  fighter: FighterProfile;
  currentRank: Rank;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activePage,
  onNavigate,
  fighter,
  currentRank,
}) => {
  return (
    <aside className="hidden lg:flex flex-col w-64 xl:w-72 bg-[#121212] border-r border-[#303030] flex-shrink-0 select-none min-h-[calc(100vh-61px)]">
      {/* Academy Identification Bar */}
      <div className="px-5 py-4 border-b border-[#303030] bg-[#0d0d0d]">
        <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3] mb-1">
          <span>CALLSIGN:</span>
          <span className="text-[#F5F5F5] font-bold">{fighter.callsign}</span>
        </div>
        <div className="flex items-center justify-between text-xs font-mono-tech text-[#A3A3A3]">
          <span>SERIAL ID:</span>
          <span className="text-[#D7263D]">{fighter.id}</span>
        </div>
      </div>

      {/* Main Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Main Navigation">
        <div className="px-2 pb-2 text-[10px] font-mono-tech uppercase text-[#666666] tracking-widest">
          // ACADEMY MODULES
        </div>
        {NAV_ITEMS.map((item) => {
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 text-left transition-all duration-150 border cursor-pointer group ${
                isActive
                  ? 'bg-[#191919] text-[#F5F5F5] border-l-4 border-l-[#D7263D] border-t-[#303030] border-r-[#303030] border-b-[#303030] shadow-inner font-semibold'
                  : 'bg-transparent text-[#A3A3A3] border-transparent hover:bg-[#161616] hover:text-[#F5F5F5]'
              }`}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`transition-colors ${
                    isActive ? 'text-[#D7263D]' : 'text-[#777777] group-hover:text-[#F5F5F5]'
                  }`}
                >
                  {item.icon}
                </span>
                <span className="font-condensed text-base uppercase tracking-wider">
                  {item.label}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <span
                    className={`font-mono-tech text-[9px] px-1.5 py-0.5 border ${
                      isActive
                        ? 'border-[#D7263D]/40 text-[#D7263D] bg-[#D7263D]/10'
                        : 'border-[#303030] text-[#777777]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                <span className="font-mono-tech text-[10px] text-[#555555]">
                  {item.code}
                </span>
              </div>
            </button>
          );
        })}
      </nav>

      {/* Bottom Dossier Footer */}
      <div className="p-4 border-t border-[#303030] bg-[#0d0d0d]">
        <div className="bg-[#161616] border border-[#303030] p-3 text-xs">
          <div className="flex items-center justify-between font-mono-tech mb-1">
            <span className="text-[#777777]">RANK TIER</span>
            <span className="text-[#D7263D] font-bold">{currentRank.insignia} // {currentRank.name}</span>
          </div>
          <div className="text-[11px] text-[#A3A3A3] font-sans truncate mb-2">
            {fighter.stance} • {fighter.weightClass.split('(')[0].trim()}
          </div>
          <div className="w-full bg-[#090909] h-1.5 border border-[#303030]">
            <div
              className="bg-[#D7263D] h-full"
              style={{ width: `${Math.min(100, (fighter.currentLevel / 24) * 100)}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[9px] font-mono-tech text-[#666666] mt-1">
            <span>LVL 1</span>
            <span>LVL 24 APEX</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
