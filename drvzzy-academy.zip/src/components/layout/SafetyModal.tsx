import React from 'react';
import { ShieldCheck, AlertTriangle, HeartPulse, CheckCircle2 } from 'lucide-react';
import { Modal } from '../common/Modal';
import { SAFETY_PROTOCOLS } from '../../data/initialData';
import { Button } from '../common/Button';

export interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({
  isOpen,
  onClose,
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="DRVZZY ACADEMY SAFETY CODEX"
      subtitle="RESPONSIBLE PUGILISM MANDATE"
      confirmLabel="ACKNOWLEDGE & COMPLY"
      onConfirm={onClose}
    >
      <div className="space-y-4">
        <div className="bg-[#191113] border-l-4 border-l-[#D7263D] border border-[#303030] p-3 text-xs text-[#E0E0E0] leading-relaxed">
          <strong className="text-[#D7263D] block font-mono-tech mb-0.5">
            // CRITICAL ADVISORY
          </strong>
          Boxing is an exacting combat discipline. DRVZZY ACADEMY strictly adheres to medical protocols designed to preserve hand health, joint integrity, and neurological safety.
        </div>

        <div className="space-y-3">
          {SAFETY_PROTOCOLS.map((protocol) => (
            <div
              key={protocol.id}
              className="p-3 bg-[#121212] border border-[#2b2b2b] text-xs space-y-1"
            >
              <div className="flex items-center justify-between font-mono-tech text-[10px]">
                <span className="text-[#D7263D] font-bold uppercase">{protocol.title}</span>
                <span className="bg-[#201012] text-[#D7263D] border border-[#4a181f] px-1.5 py-0.2">
                  {protocol.severity}
                </span>
              </div>
              <p className="text-[#F5F5F5] font-medium font-sans">
                {protocol.rule}
              </p>
              <p className="text-[11px] text-[#888888]">
                Rationale: {protocol.rationale}
              </p>
            </div>
          ))}
        </div>

        <div className="pt-2 text-[11px] font-mono-tech text-[#777777] border-t border-[#262626]">
          By continuing in DRVZZY ACADEMY, you agree that all heavy bag work is performed with approved 180" wraps and all sparring is conducted under qualified supervision.
        </div>
      </div>
    </Modal>
  );
};
