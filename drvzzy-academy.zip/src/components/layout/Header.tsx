import React from 'react';
import { Menu, X, Shield, Flame, Activity } from 'lucide-react';
import { FighterProfile, Rank } from '../../types/academy';
import { Badge } from '../common/Badge';

export interface HeaderProps {
  fighter: FighterProfile;
  currentRank: Rank;
  mobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
  onOpenSafetyModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  fighter,
  currentRank,
  mobileMenuOpen,
  onToggleMobileMenu,
  onOpenSafetyModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#090909]/95 backdrop-blur-md border-b border-[#303030] px-4 lg:px-8 py-3 select-none">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Brand & Tagline */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={onToggleMobileMenu}
            className="lg:hidden p-2 bg-[#191919] border border-[#303030] text-[#F5F5F5] hover:border-[#D7263D] transition-colors cursor-pointer"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-[#D7263D] flex items-center justify-center font-condensed font-black text-lg sm:text-xl text-[#F5F5F5] tracking-tighter border border-[#D7263D]">
              DZ
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-condensed font-black tracking-widest text-lg sm:text-xl text-[#F5F5F5] leading-none">
                  DRVZZY ACADEMY
                </span>
                <span className="hidden sm:inline-block font-mono-tech text-[10px] text-[#A3A3A3] border border-[#303030] px-1 py-0.2">
                  PUGILISM
                </span>
              </div>
              <p className="hidden md:block font-mono-tech text-[10px] uppercase text-[#A3A3A3] tracking-widest mt-0.5">
                STUDY THE CRAFT. EARN YOUR LEVEL.
              </p>
            </div>
          </div>
        </div>

        {/* Right: Technical Stats & Actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Safety protocol badge */}
          <button
            onClick={onOpenSafetyModal}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#191919] border border-[#303030] hover:border-[#D7263D] transition-colors cursor-pointer"
            title="Academy Safety & Medical Protocols"
          >
            <Shield className="w-3.5 h-3.5 text-[#D7263D]" />
            <span className="font-mono-tech text-[11px] uppercase tracking-wider text-[#F5F5F5] hidden sm:inline">
              SAFETY VERIFIED
            </span>
            <span className="w-1.5 h-1.5 bg-[#10B981]" />
          </button>

          {/* Streak indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-[#121212] border border-[#303030]">
            <Flame className="w-3.5 h-3.5 text-[#D7263D]" />
            <span className="font-mono-tech text-[11px] font-bold text-[#F5F5F5]">
              {fighter.streakDays}D STREAK
            </span>
          </div>

          {/* Level / Rank Widget */}
          <div className="flex items-center gap-2 px-3 py-1 bg-[#191919] border border-[#303030]">
            <Activity className="w-3.5 h-3.5 text-[#D7263D] hidden xs:block" />
            <div className="text-right">
              <div className="font-mono-tech text-[10px] text-[#A3A3A3] uppercase leading-none">
                LVL {fighter.currentLevel}
              </div>
              <div className="font-condensed font-bold text-xs uppercase tracking-wider text-[#F5F5F5] leading-tight">
                {currentRank.name}
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
