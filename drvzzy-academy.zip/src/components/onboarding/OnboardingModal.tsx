import React, { useState } from 'react';
import {
  Shield,
  ArrowRight,
  ArrowLeft,
  Check,
  AlertCircle,
  Sparkles,
  Calendar,
  Clock,
  Layers,
  Award,
  BookOpen,
  X,
} from 'lucide-react';
import {
  OnboardingProfile,
  BoxingExperience,
  LearningStyle,
  SessionDurationOption,
  PracticeEnvironment,
  CurriculumLevel,
  TrainingPillar,
} from '../../types/academy';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { ProgressBar } from '../common/ProgressBar';
import { Input, Textarea } from '../common/FormField';
import {
  generatePersonalizedRoadmap,
  ROADMAP_DISCLAIMER,
} from '../../utils/personalization';
import { CURRICULUM_LEVELS, TRAINING_PILLARS } from '../../data/initialData';

export interface OnboardingModalProps {
  isOpen: boolean;
  onClose?: () => void;
  existingProfile?: OnboardingProfile | null;
  onComplete: (profile: OnboardingProfile) => void;
  canDismiss?: boolean;
}

const DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const GOAL_OPTIONS = [
  { id: 'fundamentals', label: 'Learn Fundamentals', desc: 'Stance geometry, jab mechanics, and basic balance.' },
  { id: 'technique', label: 'Improve Technique', desc: 'Sharpen kinetic chain, power transfer, and precision.' },
  { id: 'movement', label: 'Footwork & Movement', desc: 'Pivots, step-drag, and ring mobility.' },
  { id: 'tactics', label: 'Study Ring Tactics', desc: 'Feints, angles, counter-punching, and fight IQ.' },
  { id: 'consistency', label: 'Build Consistency', desc: 'Develop a disciplined weekly training habit.' },
  { id: 'general_education', label: 'General Boxing Education', desc: 'Understand the sweet science from history to ringcraft.' },
];

const TOPIC_OPTIONS = [
  'Footwork & Angular Pivots',
  'Philly Shell & Shoulder Roll',
  'Kinetic Cross Power Mechanics',
  'Infighting & Forearm Framing',
  'The Stiff Piston Jab',
  'Counter-Timing & Pull Counters',
  'Rhythm Disruption & Feints',
  'Southpaw Tactics & Open Stance',
];

const EQUIPMENT_OPTIONS = [
  { id: 'hand_wraps', label: '180" Hand Wraps (Essential)' },
  { id: 'gloves_mitts', label: 'Boxing Gloves / Mitts' },
  { id: 'heavy_bag', label: 'Heavy Bag Access' },
  { id: 'jump_rope', label: 'Jump Rope' },
  { id: 'full_gym', label: 'Boxing Gym / Ring Access' },
  { id: 'none', label: 'None (Bodyweight & Mirror Only)' },
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  existingProfile,
  onComplete,
  canDismiss = true,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 6;

  // Form State
  const [displayName, setDisplayName] = useState<string>(
    existingProfile?.displayName || ''
  );
  const [experience, setExperience] = useState<BoxingExperience>(
    existingProfile?.experience || 'complete_beginner'
  );
  const [primaryGoals, setPrimaryGoals] = useState<string[]>(
    existingProfile?.primaryGoals || ['fundamentals', 'technique']
  );
  const [learningStyle, setLearningStyle] = useState<LearningStyle>(
    existingProfile?.learningStyle || 'structured_drills'
  );
  const [availableDays, setAvailableDays] = useState<string[]>(
    existingProfile?.availableDays || ['Mon', 'Wed', 'Fri']
  );
  const [sessionDuration, setSessionDuration] = useState<SessionDurationOption>(
    existingProfile?.sessionDuration || '30_45'
  );
  const [equipment, setEquipment] = useState<string[]>(
    existingProfile?.equipment || ['hand_wraps']
  );
  const [practiceEnvironment, setPracticeEnvironment] = useState<PracticeEnvironment>(
    existingProfile?.practiceEnvironment || 'home'
  );
  const [favoriteTopics, setFavoriteTopics] = useState<string[]>(
    existingProfile?.favoriteTopics || ['Footwork & Angular Pivots', 'The Stiff Piston Jab']
  );
  const [highContrast, setHighContrast] = useState<boolean>(
    existingProfile?.accessibilityPrefs?.highContrast || false
  );
  const [reducedMotion, setReducedMotion] = useState<boolean>(
    existingProfile?.accessibilityPrefs?.reducedMotion || false
  );
  const [audioBells, setAudioBells] = useState<boolean>(
    existingProfile?.accessibilityPrefs?.audioBells !== false
  );
  const [trainingNotes, setTrainingNotes] = useState<string>(
    existingProfile?.trainingNotes || ''
  );

  // Validation errors
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Helper toggle functions
  const toggleGoal = (id: string) => {
    if (primaryGoals.includes(id)) {
      if (primaryGoals.length > 1) {
        setPrimaryGoals(primaryGoals.filter((g) => g !== id));
      }
    } else {
      setPrimaryGoals([...primaryGoals, id]);
    }
  };

  const toggleDay = (day: string) => {
    if (availableDays.includes(day)) {
      if (availableDays.length > 1) {
        setAvailableDays(availableDays.filter((d) => d !== day));
      }
    } else {
      setAvailableDays([...availableDays, day]);
    }
  };

  const toggleEquipment = (id: string) => {
    if (id === 'none') {
      setEquipment(['none']);
      return;
    }
    const filtered = equipment.filter((e) => e !== 'none');
    if (filtered.includes(id)) {
      setEquipment(filtered.filter((e) => e !== id));
    } else {
      setEquipment([...filtered, id]);
    }
  };

  const toggleTopic = (topic: string) => {
    if (favoriteTopics.includes(topic)) {
      setFavoriteTopics(favoriteTopics.filter((t) => t !== topic));
    } else {
      setFavoriteTopics([...favoriteTopics, topic]);
    }
  };

  const validateCurrentStep = (): boolean => {
    setErrorMessage(null);
    if (currentStep === 1) {
      if (!displayName.trim()) {
        setErrorMessage('Please enter your preferred callsign or display name.');
        return false;
      }
      if (displayName.trim().length < 2) {
        setErrorMessage('Display name must be at least 2 characters.');
        return false;
      }
    } else if (currentStep === 2) {
      if (primaryGoals.length === 0) {
        setErrorMessage('Please select at least one primary training goal.');
        return false;
      }
    } else if (currentStep === 3) {
      if (availableDays.length === 0) {
        setErrorMessage('Please select at least one available training day.');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateCurrentStep()) {
      setCurrentStep((prev) => Math.min(totalSteps, prev + 1));
    }
  };

  const handleBack = () => {
    setErrorMessage(null);
    setCurrentStep((prev) => Math.max(1, prev - 1));
  };

  const handleSkip = () => {
    setErrorMessage(null);
    setCurrentStep((prev) => Math.min(totalSteps, prev + 1));
  };

  const handleFinish = () => {
    const profile: OnboardingProfile = {
      displayName: displayName.trim() || 'Fighter',
      experience,
      primaryGoals,
      learningStyle,
      availableDays,
      sessionDuration,
      equipment,
      practiceEnvironment,
      favoriteTopics,
      accessibilityPrefs: {
        highContrast,
        reducedMotion,
        audioBells,
      },
      trainingNotes: trainingNotes.trim(),
      completedAt: new Date().toISOString(),
    };

    onComplete(profile);
  };

  // Build temporary profile for step 6 preview
  const currentPreviewProfile: OnboardingProfile = {
    displayName: displayName.trim() || 'Fighter',
    experience,
    primaryGoals,
    learningStyle,
    availableDays,
    sessionDuration,
    equipment,
    practiceEnvironment,
    favoriteTopics,
    accessibilityPrefs: { highContrast, reducedMotion, audioBells },
    trainingNotes,
    completedAt: null,
  };

  const generatedRoadmap = generatePersonalizedRoadmap(
    currentPreviewProfile,
    CURRICULUM_LEVELS,
    TRAINING_PILLARS
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="onboarding-step-title"
    >
      <div
        className="w-full max-w-2xl bg-[#141414] border border-[#303030] shadow-2xl relative my-auto animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top brutalist red accent edge */}
        <div className="h-1 bg-[#D7263D] w-full" />

        {/* Header Bar */}
        <div className="px-5 py-4 border-b border-[#2b2b2b] bg-[#0f0f0f] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 bg-[#D7263D] flex items-center justify-center text-xs font-condensed font-black text-white">
              DZ
            </div>
            <div>
              <div className="font-mono-tech text-[10px] text-[#D7263D] uppercase tracking-wider font-bold">
                DRVZZY ACADEMY // ADMISSIONS INTERVIEW
              </div>
              <div className="font-condensed text-base uppercase text-[#F5F5F5] font-bold tracking-wide">
                STEP {currentStep} OF {totalSteps}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-mono-tech text-xs text-[#A3A3A3]">
              {Math.round((currentStep / totalSteps) * 100)}%
            </span>
            {canDismiss && onClose && (
              <button
                onClick={onClose}
                className="p-1.5 text-[#A3A3A3] hover:text-[#F5F5F5] border border-[#303030] bg-[#191919] ml-2 cursor-pointer"
                aria-label="Close interview"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Progress Bar Line */}
        <div className="w-full h-1 bg-[#1f1f1f]">
          <div
            className="h-full bg-[#D7263D] transition-all duration-300"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          />
        </div>

        {/* Error notification banner if validation fails */}
        {errorMessage && (
          <div className="px-6 py-2.5 bg-[#251012] border-b border-[#4d161d] text-[#F87171] text-xs font-mono-tech flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* STEP CONTENT BODY */}
        <div className="p-5 sm:p-7 max-h-[70vh] overflow-y-auto space-y-5">
          {/* STEP 1: IDENTITY & BOXING EXPERIENCE */}
          {currentStep === 1 && (
            <div className="space-y-5">
              <div>
                <h2
                  id="onboarding-step-title"
                  className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                >
                  FIGHTER IDENTITY & EXPERIENCE
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 font-sans">
                  How should the Academy address you, and what is your current background with boxing?
                </p>
              </div>

              <div className="space-y-4">
                <Input
                  label="PREFERRED DISPLAY NAME / CALLSIGN"
                  value={displayName}
                  onChange={(e) => {
                    setDisplayName(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="e.g. Vance, Lennox, Ironclad"
                  required
                  helperText="Used in your fighter dossier, academy certificate, and daily dashboard."
                />

                <div className="space-y-2">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    CURRENT BOXING EXPERIENCE <span className="text-[#D7263D]">*</span>
                  </label>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {[
                      {
                        value: 'complete_beginner',
                        label: 'Complete Beginner',
                        sub: 'Zero or minimal boxing training. Ready to learn strict stance & mechanics.',
                      },
                      {
                        value: 'some_experience',
                        label: 'Some Experience',
                        sub: 'Have done fitness boxing or bag work; looking for technical structure.',
                      },
                      {
                        value: 'experienced_learner',
                        label: 'Experienced Learner',
                        sub: 'Experienced amateur / practitioner wanting deep tactical study.',
                      },
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setExperience(opt.value as BoxingExperience)}
                        className={`p-3.5 text-left border transition-all cursor-pointer ${
                          experience === opt.value
                            ? 'bg-[#1e1517] border-l-4 border-l-[#D7263D] border-[#404040]'
                            : 'bg-[#121212] border-[#2b2b2b] hover:border-[#404040]'
                        }`}
                      >
                        <div className="font-condensed text-base font-bold uppercase text-[#F5F5F5]">
                          {opt.label}
                        </div>
                        <p className="text-[11px] text-[#A3A3A3] font-sans mt-1 leading-snug">
                          {opt.sub}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: PRIMARY GOALS & LEARNING STYLE */}
          {currentStep === 2 && (
            <div className="space-y-5">
              <div>
                <h2
                  id="onboarding-step-title"
                  className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                >
                  PRIMARY GOALS & LEARNING STYLE
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 font-sans">
                  Select the core outcomes you want to achieve through the Academy curriculum.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    PRIMARY OBJECTIVES (SELECT AT LEAST ONE) <span className="text-[#D7263D]">*</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {GOAL_OPTIONS.map((goal) => {
                      const isSelected = primaryGoals.includes(goal.id);
                      return (
                        <button
                          key={goal.id}
                          type="button"
                          onClick={() => toggleGoal(goal.id)}
                          className={`p-3 text-left border transition-all cursor-pointer flex items-start gap-2.5 ${
                            isSelected
                              ? 'bg-[#1e1517] border-[#D7263D]'
                              : 'bg-[#121212] border-[#2b2b2b] hover:border-[#404040]'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                              isSelected ? 'bg-[#D7263D] border-[#D7263D] text-white' : 'border-[#444444]'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3" />}
                          </div>
                          <div>
                            <div className="font-condensed text-sm font-bold uppercase text-[#F5F5F5]">
                              {goal.label}
                            </div>
                            <p className="text-[11px] text-[#888888] font-sans mt-0.5 leading-snug">
                              {goal.desc}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-[#262626]">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    PREFERRED LEARNING STYLE
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'structured_drills', label: 'Structured Drills' },
                      { id: 'reading', label: 'Biomechanical Text' },
                      { id: 'video_study', label: 'Video Film Study' },
                      { id: 'mixture', label: 'Balanced Mixture' },
                    ].map((style) => (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => setLearningStyle(style.id as LearningStyle)}
                        className={`p-2.5 text-center border font-mono-tech text-xs uppercase cursor-pointer ${
                          learningStyle === style.id
                            ? 'bg-[#D7263D] text-white border-[#D7263D] font-bold'
                            : 'bg-[#121212] border-[#2b2b2b] text-[#A3A3A3] hover:text-white'
                        }`}
                      >
                        {style.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: SCHEDULE & SESSION DURATION */}
          {currentStep === 3 && (
            <div className="space-y-5">
              <div>
                <h2
                  id="onboarding-step-title"
                  className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                >
                  TRAINING AVAILABILITY & CADENCE
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 font-sans">
                  The Academy will construct a realistic schedule that avoids overtraining or unmanageable commitments.
                </p>
              </div>

              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    AVAILABLE TRAINING DAYS ({availableDays.length} DAYS CHOSEN) <span className="text-[#D7263D]">*</span>
                  </label>
                  <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
                    {DAYS_OF_WEEK.map((day) => {
                      const isSelected = availableDays.includes(day);
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => toggleDay(day)}
                          className={`p-3 text-center border font-mono-tech text-xs uppercase transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#D7263D] border-[#D7263D] text-white font-bold'
                              : 'bg-[#121212] border-[#2b2b2b] text-[#777777] hover:border-[#444444]'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-[#262626]">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    TYPICAL SESSION DURATION
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { id: '15_30', label: '15 - 30 MIN', sub: 'High-focus sprints' },
                      { id: '30_45', label: '30 - 45 MIN', sub: 'Optimal cadence' },
                      { id: '45_60', label: '45 - 60 MIN', sub: 'Full standard camp' },
                      { id: '60_plus', label: '60+ MIN', sub: 'Championship camp' },
                    ].map((dur) => (
                      <button
                        key={dur.id}
                        type="button"
                        onClick={() => setSessionDuration(dur.id as SessionDurationOption)}
                        className={`p-3 text-left border transition-all cursor-pointer ${
                          sessionDuration === dur.id
                            ? 'bg-[#1e1517] border-l-4 border-l-[#D7263D] border-[#383838]'
                            : 'bg-[#121212] border-[#2b2b2b] hover:border-[#383838]'
                        }`}
                      >
                        <div className="font-mono-tech text-xs font-bold text-[#F5F5F5]">
                          {dur.label}
                        </div>
                        <div className="text-[10px] text-[#888888] font-sans mt-0.5">
                          {dur.sub}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: ENVIRONMENT & EQUIPMENT */}
          {currentStep === 4 && (
            <div className="space-y-5">
              <div>
                <h2
                  id="onboarding-step-title"
                  className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                >
                  PRACTICE ENVIRONMENT & GEAR
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 font-sans">
                  Curriculum recommendations adapt to whether you have a bag, gloves, or only floor space and a mirror.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    PRIMARY PRACTICE ENVIRONMENT
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {[
                      { id: 'home', label: 'Home / Living Room', sub: 'Shadowboxing, footwork grid, mirror line.' },
                      { id: 'supervised_gym', label: 'Boxing Gym / Club', sub: 'Access to ring, coaches, heavy bags, and pads.' },
                      { id: 'other', label: 'Commercial Gym / Outdoor', sub: 'Standard gym equipment or park roadwork.' },
                    ].map((env) => (
                      <button
                        key={env.id}
                        type="button"
                        onClick={() => setPracticeEnvironment(env.id as PracticeEnvironment)}
                        className={`p-3.5 text-left border transition-all cursor-pointer ${
                          practiceEnvironment === env.id
                            ? 'bg-[#1e1517] border-l-4 border-l-[#D7263D] border-[#383838]'
                            : 'bg-[#121212] border-[#2b2b2b] hover:border-[#383838]'
                        }`}
                      >
                        <div className="font-condensed text-base font-bold uppercase text-[#F5F5F5]">
                          {env.label}
                        </div>
                        <div className="text-[11px] text-[#888888] font-sans mt-1 leading-snug">
                          {env.sub}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-[#262626]">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    AVAILABLE EQUIPMENT (SELECT ALL THAT APPLY)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {EQUIPMENT_OPTIONS.map((eq) => {
                      const isSelected = equipment.includes(eq.id);
                      return (
                        <button
                          key={eq.id}
                          type="button"
                          onClick={() => toggleEquipment(eq.id)}
                          className={`p-2.5 text-left border flex items-center gap-2.5 cursor-pointer ${
                            isSelected
                              ? 'bg-[#191919] border-[#D7263D] text-[#F5F5F5]'
                              : 'bg-[#121212] border-[#262626] text-[#A3A3A3] hover:border-[#383838]'
                          }`}
                        >
                          <div
                            className={`w-3.5 h-3.5 border flex items-center justify-center ${
                              isSelected ? 'bg-[#D7263D] border-[#D7263D] text-white' : 'border-[#444444]'
                            }`}
                          >
                            {isSelected && <Check className="w-2.5 h-2.5" />}
                          </div>
                          <span className="font-sans text-xs">{eq.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: SPECIAL TOPICS, ACCESSIBILITY & SAFETY NOTES */}
          {currentStep === 5 && (
            <div className="space-y-5">
              <div>
                <div className="flex items-center justify-between">
                  <h2
                    id="onboarding-step-title"
                    className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                  >
                    SPECIAL TOPICS & SAFETY NOTES
                  </h2>
                  <Badge variant="muted">OPTIONAL STEP</Badge>
                </div>
                <p className="text-xs sm:text-sm text-[#A3A3A3] mt-1 font-sans">
                  Fine-tune tactical preferences and document any physical notes for safe participation.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    FAVORITE BOXING TOPICS & TECHNIQUES
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {TOPIC_OPTIONS.map((topic) => {
                      const isSelected = favoriteTopics.includes(topic);
                      return (
                        <button
                          key={topic}
                          type="button"
                          onClick={() => toggleTopic(topic)}
                          className={`px-3 py-1.5 border font-mono-tech text-xs uppercase cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-[#D7263D] border-[#D7263D] text-white font-bold'
                              : 'bg-[#121212] border-[#2b2b2b] text-[#A3A3A3] hover:text-white'
                          }`}
                        >
                          {isSelected ? '✓ ' : '+ '}
                          {topic}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-[#262626]">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    OPTIONAL TRAINING & SAFETY NOTES
                  </label>
                  <Textarea
                    rows={2}
                    value={trainingNotes}
                    onChange={(e) => setTrainingNotes(e.target.value)}
                    placeholder="e.g. Previous right wrist strain (strictly wear 180' wraps); prefer low-impact shadowboxing warmup..."
                    helperText="Private notes kept on your local dossier for safety reference."
                  />
                </div>

                <div className="space-y-2 pt-2 border-t border-[#262626]">
                  <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#A3A3A3]">
                    ACCESSIBILITY PREFERENCES
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono-tech text-xs">
                    <button
                      type="button"
                      onClick={() => setHighContrast(!highContrast)}
                      className={`p-2 border text-left cursor-pointer ${
                        highContrast ? 'bg-[#191919] border-[#D7263D] text-white' : 'bg-[#121212] border-[#262626] text-[#777777]'
                      }`}
                    >
                      {highContrast ? '[✓]' : '[ ]'} High Contrast UI
                    </button>
                    <button
                      type="button"
                      onClick={() => setReducedMotion(!reducedMotion)}
                      className={`p-2 border text-left cursor-pointer ${
                        reducedMotion ? 'bg-[#191919] border-[#D7263D] text-white' : 'bg-[#121212] border-[#262626] text-[#777777]'
                      }`}
                    >
                      {reducedMotion ? '[✓]' : '[ ]'} Reduced Motion
                    </button>
                    <button
                      type="button"
                      onClick={() => setAudioBells(!audioBells)}
                      className={`p-2 border text-left cursor-pointer ${
                        audioBells ? 'bg-[#191919] border-[#D7263D] text-white' : 'bg-[#121212] border-[#262626] text-[#777777]'
                      }`}
                    >
                      {audioBells ? '[✓]' : '[ ]'} Audio Round Bells
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: ROADMAP SYNTHESIS & REVIEW */}
          {currentStep === 6 && (
            <div className="space-y-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-[#D7263D]" />
                  <span className="font-mono-tech text-xs text-[#D7263D] uppercase font-bold">
                    PERSONALIZED ROADMAP SYNTHESIZED
                  </span>
                </div>
                <h2
                  id="onboarding-step-title"
                  className="font-condensed text-2xl sm:text-3xl font-black uppercase text-[#F5F5F5]"
                >
                  ACADEMY TRAINING BLUEPRINT FOR {displayName.toUpperCase()}
                </h2>
                <p className="text-xs sm:text-sm text-[#A3A3A3] font-sans">
                  Based on your goals and availability, here is your prescribed starting sequence in the curriculum.
                </p>
              </div>

              {/* Blueprint Summary Cards */}
              <div className="space-y-3 font-mono-tech text-xs">
                <div className="p-3.5 bg-[#101010] border-l-4 border-l-[#D7263D] border border-[#2b2b2b] flex items-center justify-between">
                  <div>
                    <span className="text-[#777777] block text-[10px]">PRESCRIBED STARTING POINT</span>
                    <span className="text-[#F5F5F5] font-bold text-sm">
                      LEVEL 1: STANCE, BASE & NEUTRAL ALIGNMENT
                    </span>
                  </div>
                  <Badge variant="accent">PHASE I</Badge>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-[#121212] border border-[#262626]">
                    <span className="text-[#777777] block text-[10px]">SCHEDULED CADENCE</span>
                    <span className="text-[#F5F5F5] font-bold">
                      {generatedRoadmap.cadenceDescription}
                    </span>
                  </div>
                  <div className="p-3 bg-[#121212] border border-[#262626]">
                    <span className="text-[#777777] block text-[10px]">SESSION TIME BUDGET</span>
                    <span className="text-[#F5F5F5] font-bold">
                      {generatedRoadmap.targetSessionMinutes} MIN PER WORKOUT
                    </span>
                  </div>
                </div>

                {/* Priority Pillars */}
                <div className="p-3 bg-[#121212] border border-[#262626] space-y-1.5">
                  <span className="text-[#777777] block text-[10px]">PRIORITIZED TRAINING PILLARS</span>
                  <div className="flex flex-wrap gap-2">
                    {generatedRoadmap.primaryPillars.map((p) => (
                      <span
                        key={p.id}
                        className="bg-[#1a1a1a] border border-[#333333] px-2 py-0.5 text-[#F5F5F5]"
                      >
                        {p.code} // {p.name}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Mandatory Disclaimer as requested */}
                <div className="p-3 bg-[#181113] border border-[#4a181f] text-[#CCCCCC] text-[11px] leading-relaxed font-sans">
                  <strong className="text-[#D7263D] font-mono-tech block mb-0.5">
                    // EDUCATIONAL ASSESSMENT NOTICE:
                  </strong>
                  {ROADMAP_DISCLAIMER}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Controls / Footer */}
        <div className="px-5 py-4 border-t border-[#2b2b2b] bg-[#0f0f0f] flex items-center justify-between">
          <div>
            {currentStep > 1 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                BACK
              </Button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {currentStep === 5 && (
              <Button variant="ghost" size="sm" onClick={handleSkip}>
                SKIP TO SUMMARY
              </Button>
            )}

            {currentStep < totalSteps ? (
              <Button
                variant="primary"
                size="sm"
                onClick={handleNext}
                rightIcon={<ArrowRight className="w-4 h-4" />}
              >
                CONTINUE
              </Button>
            ) : (
              <Button
                variant="primary"
                size="md"
                onClick={handleFinish}
                leftIcon={<Check className="w-4 h-4" />}
              >
                COMMIT & ENTER ACADEMY
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
