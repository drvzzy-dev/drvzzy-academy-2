import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getXpThresholdForLevel,
  calculateLevelProgress,
  getRankForLevel,
  calculateCompletionPercentage,
  formatTechNumber,
} from './progression';
import { Rank } from '../types/academy';

const MOCK_RANKS: Rank[] = [
  { id: 1, code: 'RNK-01', name: 'Novice', title: 'Initiate of the Stance', minLevel: 1, maxLevel: 3, insignia: 'I', description: 'Foundation', tacticalFocus: 'Guard' },
  { id: 2, code: 'RNK-02', name: 'Apprentice', title: 'Gym Regular', minLevel: 4, maxLevel: 6, insignia: 'II', description: 'Mechanics', tacticalFocus: 'Jab' },
  { id: 3, code: 'RNK-03', name: 'Contender', title: 'Ring Striker', minLevel: 7, maxLevel: 9, insignia: 'III', description: 'Combinations', tacticalFocus: 'Flow' },
  { id: 8, code: 'RNK-08', name: 'Apex Pugilist', title: 'Grandmaster of the Sweet Science', minLevel: 22, maxLevel: 24, insignia: 'VIII', description: 'Mastery', tacticalFocus: 'Unconscious Competence' },
];

test('XP threshold for Level 1 is 0', () => {
  assert.equal(getXpThresholdForLevel(1), 0);
  assert.equal(getXpThresholdForLevel(0), 0);
});

test('XP threshold scales steadily for subsequent levels', () => {
  const lvl2 = getXpThresholdForLevel(2);
  const lvl3 = getXpThresholdForLevel(3);
  assert.equal(lvl2, 1000);
  assert.equal(lvl3, 2250);
  assert.ok(lvl3 > lvl2);
});

test('calculateLevelProgress calculates progress percent and remaining XP correctly', () => {
  // Level 1: floor is 0, ceiling is 1000. At 350 XP:
  const progress = calculateLevelProgress(350, 1);
  assert.equal(progress.currentLevelXp, 350);
  assert.equal(progress.nextLevelXp, 1000);
  assert.equal(progress.progressPercent, 35);
  assert.equal(progress.xpRemaining, 650);
  assert.equal(progress.isMaxLevel, false);
});

test('calculateLevelProgress clamps percentages gracefully', () => {
  const progressOver = calculateLevelProgress(1500, 1);
  assert.equal(progressOver.progressPercent, 100);
  assert.equal(progressOver.xpRemaining, 0);
});

test('getRankForLevel resolves matching rank by min and max level', () => {
  const r1 = getRankForLevel(1, MOCK_RANKS);
  assert.equal(r1.name, 'Novice');

  const r2 = getRankForLevel(5, MOCK_RANKS);
  assert.equal(r2.name, 'Apprentice');

  const rApex = getRankForLevel(24, MOCK_RANKS);
  assert.equal(rApex.name, 'Apex Pugilist');
});

test('calculateCompletionPercentage handles zero total safely', () => {
  assert.equal(calculateCompletionPercentage(0, 0), 0);
  assert.equal(calculateCompletionPercentage(5, 10), 50);
  assert.equal(calculateCompletionPercentage(10, 10), 100);
});

test('formatTechNumber formats large XP numbers with commas', () => {
  assert.equal(formatTechNumber(12500), '12,500');
  assert.equal(formatTechNumber(0), '0');
});
