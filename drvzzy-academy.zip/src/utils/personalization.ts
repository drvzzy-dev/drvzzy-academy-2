import {
  OnboardingProfile,
  RecommendedRoadmap,
  CurriculumLevel,
  TrainingPillar,
  JournalSession,
} from '../types/academy';

export const ROADMAP_DISCLAIMER =
  'This automated roadmap is generated from Drvzzy Academy curriculum benchmarks based on your reported goals, equipment, and training days. It is an educational guide, not a certified boxing coach’s or physician’s personalized diagnostic assessment. Always train within your physical limits and adhere to safety protocols.';

/**
 * Derives target minutes from duration enum.
 */
export function getDurationMinutes(duration: OnboardingProfile['sessionDuration']): number {
  switch (duration) {
    case '15_30':
      return 25;
    case '30_45':
      return 40;
    case '45_60':
      return 50;
    case '60_plus':
      return 60;
    default:
      return 45;
  }
}

/**
 * Generates a tailored educational roadmap based on onboarding responses.
 */
export function generatePersonalizedRoadmap(
  profile: OnboardingProfile,
  allLevels: CurriculumLevel[],
  allPillars: TrainingPillar[]
): RecommendedRoadmap {
  const weeklyTargetSessions = Math.max(1, profile.availableDays.length || 3);
  const targetSessionMinutes = getDurationMinutes(profile.sessionDuration);

  const daysLabel = profile.availableDays.length > 0
    ? profile.availableDays.join(', ')
    : 'Flexible Schedule';

  const cadenceDescription = `${weeklyTargetSessions} session${
    weeklyTargetSessions > 1 ? 's' : ''
  }/week (${targetSessionMinutes} min each) on ${daysLabel}`;

  // Prioritize pillars based on goals
  const goalSet = new Set(profile.primaryGoals);
  const prioritizedPillars: TrainingPillar[] = [...allPillars].sort((a, b) => {
    let scoreA = 0;
    let scoreB = 0;

    if (goalSet.has('fundamentals') || goalSet.has('movement')) {
      if (a.id === 'pillar-1') scoreA += 3;
      if (b.id === 'pillar-1') scoreB += 3;
    }
    if (goalSet.has('technique')) {
      if (a.id === 'pillar-3' || a.id === 'pillar-2') scoreA += 3;
      if (b.id === 'pillar-3' || b.id === 'pillar-2') scoreB += 3;
    }
    if (goalSet.has('tactics')) {
      if (a.id === 'pillar-5' || a.id === 'pillar-4') scoreA += 3;
      if (b.id === 'pillar-5' || b.id === 'pillar-4') scoreB += 3;
    }
    if (goalSet.has('consistency')) {
      if (a.id === 'pillar-6') scoreA += 2;
      if (b.id === 'pillar-6') scoreB += 2;
    }

    return scoreB - scoreA;
  });

  // Recommend starting levels in sequence without skipping prerequisite fundamentals
  const startingLevels = allLevels.slice(0, 3);

  // Selected study topics
  const topics = profile.favoriteTopics && profile.favoriteTopics.length > 0
    ? profile.favoriteTopics
    : ['Stance & Weight Transfer', 'The Stiff Piston Jab', 'Centerline Defense'];

  return {
    startingLevel: 1, // Boxing prerequisites always start at Level 1 Stance
    weeklyTargetSessions,
    targetSessionMinutes,
    cadenceDescription,
    recommendedLevels: startingLevels,
    primaryPillars: prioritizedPillars.slice(0, 3),
    recommendedTopics: topics,
    disclaimer: ROADMAP_DISCLAIMER,
  };
}

/**
 * Returns the next available incomplete lesson.
 */
export function getNextIncompleteLesson(
  completedLevelIds: number[],
  allLevels: CurriculumLevel[]
): CurriculumLevel {
  const completedSet = new Set(completedLevelIds);
  const next = allLevels.find((lvl) => !completedSet.has(lvl.levelNumber));
  return next || allLevels[0];
}

/**
 * Calculates current week activity metrics from genuine completed logs.
 */
export function calculateWeeklyActivityMetrics(
  sessions: JournalSession[],
  completedLevelIds: number[],
  weeklyGoalSessions: number
) {
  // Only genuine logged sessions
  const sessionsCount = sessions.length;
  const lessonsCompletedCount = completedLevelIds.length;
  const totalRounds = sessions.reduce((acc, s) => acc + s.rounds, 0);

  const goal = Math.max(1, weeklyGoalSessions);
  const progressPercent = Math.min(100, Math.round((sessionsCount / goal) * 100));

  return {
    sessionsCount,
    lessonsCompletedCount,
    totalRounds,
    weeklyGoalSessions: goal,
    progressPercent,
    isGoalMet: sessionsCount >= goal,
  };
}
