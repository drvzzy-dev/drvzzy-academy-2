import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generatePersonalizedRoadmap,
  getNextIncompleteLesson,
  calculateWeeklyActivityMetrics,
  getDurationMinutes,
  ROADMAP_DISCLAIMER,
} from './personalization';
import { OnboardingProfile, CurriculumLevel, TrainingPillar, JournalSession } from '../types/academy';

const MOCK_LEVELS: CurriculumLevel[] = [
  { levelNumber: 1, phaseNumber: 1, title: 'Stance', subtitle: 'Base', xpRequired: 1000, status: 'current', estimatedHours: 10, drillsCount: 5, keySkills: ['Stance'], benchmarkTest: 'Test 1' },
  { levelNumber: 2, phaseNumber: 1, title: 'Footwork', subtitle: 'Step-drag', xpRequired: 2000, status: 'locked', estimatedHours: 12, drillsCount: 6, keySkills: ['Steps'], benchmarkTest: 'Test 2' },
  { levelNumber: 3, phaseNumber: 1, title: 'Jab', subtitle: 'Snap', xpRequired: 3000, status: 'locked', estimatedHours: 15, drillsCount: 8, keySkills: ['Jab'], benchmarkTest: 'Test 3' },
];

const MOCK_PILLARS: TrainingPillar[] = [
  { id: 'pillar-1', code: 'PLR-01', name: 'Footwork & Stance', shortDesc: 'Base', description: 'Base', drillsOverview: ['Step'], importanceMetric: 'High' },
  { id: 'pillar-2', code: 'PLR-02', name: 'Defense & Slips', shortDesc: 'Defense', description: 'Defense', drillsOverview: ['Slip'], importanceMetric: 'High' },
  { id: 'pillar-3', code: 'PLR-03', name: 'Punch Mechanics', shortDesc: 'Power', description: 'Power', drillsOverview: ['Snap'], importanceMetric: 'High' },
  { id: 'pillar-4', code: 'PLR-04', name: 'Combinations & Flow', shortDesc: 'Combos', description: 'Combos', drillsOverview: ['1-2'], importanceMetric: 'Med' },
  { id: 'pillar-5', code: 'PLR-05', name: 'Fight IQ', shortDesc: 'IQ', description: 'IQ', drillsOverview: ['Study'], importanceMetric: 'Med' },
  { id: 'pillar-6', code: 'PLR-06', name: 'Conditioning', shortDesc: 'Cardio', description: 'Cardio', drillsOverview: ['Jump rope'], importanceMetric: 'Med' },
];

const MOCK_PROFILE: OnboardingProfile = {
  displayName: 'Dave',
  experience: 'some_experience',
  primaryGoals: ['movement', 'technique'],
  learningStyle: 'structured_drills',
  availableDays: ['Mon', 'Wed', 'Fri'],
  sessionDuration: '30_45',
  equipment: ['hand_wraps', 'heavy_bag'],
  practiceEnvironment: 'home',
  favoriteTopics: ['Footwork & Angles'],
  accessibilityPrefs: { highContrast: false, reducedMotion: false, audioBells: true },
  trainingNotes: 'Previous wrist sprain, strictly wrap hands',
  completedAt: '2026-10-22',
};

test('getDurationMinutes converts options to numbers', () => {
  assert.equal(getDurationMinutes('15_30'), 25);
  assert.equal(getDurationMinutes('30_45'), 40);
  assert.equal(getDurationMinutes('45_60'), 50);
  assert.equal(getDurationMinutes('60_plus'), 60);
});

test('generatePersonalizedRoadmap always starts at Level 1 regardless of experience', () => {
  const roadmap = generatePersonalizedRoadmap(MOCK_PROFILE, MOCK_LEVELS, MOCK_PILLARS);
  assert.equal(roadmap.startingLevel, 1);
  assert.equal(roadmap.weeklyTargetSessions, 3);
  assert.equal(roadmap.targetSessionMinutes, 40);
  assert.ok(roadmap.cadenceDescription.includes('3 sessions/week'));
});

test('generatePersonalizedRoadmap includes responsible coaching disclaimer', () => {
  const roadmap = generatePersonalizedRoadmap(MOCK_PROFILE, MOCK_LEVELS, MOCK_PILLARS);
  assert.equal(roadmap.disclaimer, ROADMAP_DISCLAIMER);
  assert.ok(roadmap.disclaimer.includes('educational guide'));
});

test('getNextIncompleteLesson returns the lowest uncompleted level', () => {
  assert.equal(getNextIncompleteLesson([], MOCK_LEVELS).levelNumber, 1);
  assert.equal(getNextIncompleteLesson([1], MOCK_LEVELS).levelNumber, 2);
  assert.equal(getNextIncompleteLesson([1, 2], MOCK_LEVELS).levelNumber, 3);
});

test('calculateWeeklyActivityMetrics computes real counts and progress', () => {
  const sessions: JournalSession[] = [
    { id: 's1', date: 'OCT 20', sessionType: 'Heavy Bag', rounds: 6, roundMinutes: 3, intensity: 'Moderate Cadence', focusPillar: 'Punch Mechanics', notes: 'Good', drillsCompleted: [], xpEarned: 150 },
    { id: 's2', date: 'OCT 22', sessionType: 'Shadowboxing', rounds: 4, roundMinutes: 3, intensity: 'Technical Recovery', focusPillar: 'Footwork & Stance', notes: 'Crisp', drillsCompleted: [], xpEarned: 100 },
  ];

  const metrics = calculateWeeklyActivityMetrics(sessions, [1], 4);
  assert.equal(metrics.sessionsCount, 2);
  assert.equal(metrics.lessonsCompletedCount, 1);
  assert.equal(metrics.totalRounds, 10);
  assert.equal(metrics.weeklyGoalSessions, 4);
  assert.equal(metrics.progressPercent, 50);
  assert.equal(metrics.isGoalMet, false);
});
