import { Rank } from '../types/academy';

/**
 * Returns the cumulative XP required to achieve a given level (1 to 24).
 * Base curve: Level 1 = 0 XP, Level 2 = 1,000 XP, scaling with disciplined progression.
 */
export function getXpThresholdForLevel(level: number): number {
  if (level <= 1) return 0;
  // Scaled progression: Level 2 = 1000, Level 3 = 2200, Level 4 = 3600, etc.
  let cumulative = 0;
  for (let lvl = 2; lvl <= level; lvl++) {
    cumulative += 1000 + (lvl - 2) * 250;
  }
  return cumulative;
}

/**
 * Calculates current level progress metrics given total XP.
 */
export function calculateLevelProgress(currentXp: number, currentLevel: number) {
  const boundedLevel = Math.max(1, Math.min(24, currentLevel));
  const floorXp = getXpThresholdForLevel(boundedLevel);
  const ceilingXp = getXpThresholdForLevel(Math.min(24, boundedLevel + 1));
  
  const span = ceilingXp - floorXp;
  if (span <= 0) {
    return {
      currentLevelXp: currentXp,
      nextLevelXp: ceilingXp,
      progressPercent: 100,
      xpRemaining: 0,
      isMaxLevel: true,
    };
  }

  const earnedInLevel = Math.max(0, currentXp - floorXp);
  const progressPercent = Math.min(100, Math.max(0, Math.round((earnedInLevel / span) * 100)));
  const xpRemaining = Math.max(0, ceilingXp - currentXp);

  return {
    currentLevelXp: currentXp,
    nextLevelXp: ceilingXp,
    progressPercent,
    xpRemaining,
    isMaxLevel: boundedLevel >= 24,
  };
}

/**
 * Resolves the matching Rank definition for any given Level (1 to 24).
 */
export function getRankForLevel(level: number, ranks: Rank[]): Rank {
  const match = ranks.find(r => level >= r.minLevel && level <= r.maxLevel);
  if (match) return match;
  // Default to lowest or highest rank if out of bounds
  if (level < 1 && ranks.length > 0) return ranks[0];
  return ranks[ranks.length - 1];
}

/**
 * Cleanly format numbers with comma separators for XP / Round counts.
 */
export function formatTechNumber(val: number): string {
  return new Intl.NumberFormat('en-US').format(Math.max(0, Math.round(val)));
}

/**
 * Calculate completion percentage safely clamped between 0 and 100.
 */
export function calculateCompletionPercentage(completed: number, total: number): number {
  if (total <= 0) return 0;
  const ratio = (completed / total) * 100;
  return Math.min(100, Math.max(0, Math.round(ratio)));
}
