import { AppState, FighterProfile, OnboardingProfile } from '../types/academy';
import { INITIAL_FIGHTER } from '../data/initialData';

const STORAGE_KEY = 'drvzzy_academy_v2_state';

export const INITIAL_APP_STATE: AppState = {
  onboarding: null,
  fighter: INITIAL_FIGHTER,
  completedLevelIds: [],
  completedLessonIds: [],
  inProgressLessonIds: ['les-01-01'],
  knowledgeCheckResults: {},
  bookmarkedTechniqueIds: ['tech-orthodox-stance', 'tech-piston-jab'],
  bookmarkedLessonIds: [],
  journalSessions: [],
  activityHistory: [],
  weeklyGoalSessions: 3,
};

/**
 * Loads the application state from localStorage safely.
 * Returns valid state or initial state if storage is absent, invalid, or corrupted.
 */
export function loadAppState(): AppState {
  if (typeof window === 'undefined' || !window.localStorage) {
    return INITIAL_APP_STATE;
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return INITIAL_APP_STATE;
    }

    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') {
      return INITIAL_APP_STATE;
    }

    // Merge with safe fallbacks
    const fighter: FighterProfile = {
      ...INITIAL_FIGHTER,
      ...(parsed.fighter || {}),
    };

    const onboarding: OnboardingProfile | null = parsed.onboarding || null;
    const completedLevelIds: number[] = Array.isArray(parsed.completedLevelIds)
      ? parsed.completedLevelIds
      : [];
    const completedLessonIds: string[] = Array.isArray(parsed.completedLessonIds)
      ? parsed.completedLessonIds
      : [];
    const inProgressLessonIds: string[] = Array.isArray(parsed.inProgressLessonIds)
      ? parsed.inProgressLessonIds
      : ['les-01-01'];
    const knowledgeCheckResults =
      parsed.knowledgeCheckResults && typeof parsed.knowledgeCheckResults === 'object'
        ? parsed.knowledgeCheckResults
        : {};
    const bookmarkedTechniqueIds: string[] = Array.isArray(parsed.bookmarkedTechniqueIds)
      ? parsed.bookmarkedTechniqueIds
      : ['tech-orthodox-stance', 'tech-piston-jab'];
    const bookmarkedLessonIds: string[] = Array.isArray(parsed.bookmarkedLessonIds)
      ? parsed.bookmarkedLessonIds
      : [];
    const journalSessions = Array.isArray(parsed.journalSessions)
      ? parsed.journalSessions
      : [];
    const activityHistory = Array.isArray(parsed.activityHistory)
      ? parsed.activityHistory
      : [];
    const weeklyGoalSessions = typeof parsed.weeklyGoalSessions === 'number'
      ? parsed.weeklyGoalSessions
      : 3;

    return {
      onboarding,
      fighter,
      completedLevelIds,
      completedLessonIds,
      inProgressLessonIds,
      knowledgeCheckResults,
      bookmarkedTechniqueIds,
      bookmarkedLessonIds,
      journalSessions,
      activityHistory,
      weeklyGoalSessions,
    };
  } catch (err) {
    console.warn('[DRVZZY STORAGE] Failed to parse local state, returning defaults:', err);
    return INITIAL_APP_STATE;
  }
}

/**
 * Persists the complete application state safely.
 */
export function saveAppState(state: AppState): boolean {
  if (typeof window === 'undefined' || !window.localStorage) {
    return false;
  }

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch (err) {
    console.error('[DRVZZY STORAGE] Failed to write state to localStorage:', err);
    return false;
  }
}

/**
 * Resets local storage back to clean factory state.
 */
export function clearAppState(): void {
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.warn('[DRVZZY STORAGE] Failed to clear localStorage:', e);
    }
  }
}
