import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isLessonUnlocked,
  getLessonStatus,
  calculateCurriculumProgress,
  calculatePhaseProgress,
  calculatePillarProgress,
  getNextRecommendedLesson,
  gradeKnowledgeCheck,
  filterLessons,
  filterTechniques,
} from './curriculum';
import { LESSON_CATALOG, TECHNIQUE_CATALOG } from '../data/curriculumData';

test('isLessonUnlocked correctly handles root lessons and prerequisites', () => {
  // First lesson has no prerequisites and is always unlocked
  const firstLesson = LESSON_CATALOG[0];
  assert.equal(isLessonUnlocked(firstLesson.id, [], LESSON_CATALOG), true);

  // Second lesson requires les-01-01
  const secondLesson = LESSON_CATALOG.find((l) => l.id === 'les-01-02')!;
  assert.equal(isLessonUnlocked(secondLesson.id, [], LESSON_CATALOG), false);
  assert.equal(isLessonUnlocked(secondLesson.id, ['les-01-01'], LESSON_CATALOG), true);

  // Advanced lesson (Level 5) requires Phase I completion
  const lvl5Lesson = LESSON_CATALOG.find((l) => l.id === 'les-05-01')!;
  assert.equal(isLessonUnlocked(lvl5Lesson.id, [], LESSON_CATALOG), false);
  assert.equal(isLessonUnlocked(lvl5Lesson.id, ['les-04-01'], LESSON_CATALOG), true);
});

test('getLessonStatus accurately reports completed, in_progress, available, and locked', () => {
  const les1 = 'les-01-01';
  const les2 = 'les-01-02';

  // Initially: les1 available, les2 locked
  assert.equal(getLessonStatus(les1, [], [], LESSON_CATALOG), 'available');
  assert.equal(getLessonStatus(les2, [], [], LESSON_CATALOG), 'locked');

  // In progress
  assert.equal(getLessonStatus(les1, [], [les1], LESSON_CATALOG), 'in_progress');

  // Completed les1 unlocks les2
  assert.equal(getLessonStatus(les1, [les1], [], LESSON_CATALOG), 'completed');
  assert.equal(getLessonStatus(les2, [les1], [], LESSON_CATALOG), 'available');
});

test('calculateCurriculumProgress computes accurate percentages and XP totals', () => {
  const initial = calculateCurriculumProgress([], LESSON_CATALOG);
  assert.equal(initial.completedCount, 0);
  assert.equal(initial.percent, 0);
  assert.equal(initial.earnedXp, 0);
  assert.ok(initial.totalLessons > 0);
  assert.ok(initial.totalXpAvailable > 0);

  // With first lesson completed
  const firstLesson = LESSON_CATALOG[0];
  const withOne = calculateCurriculumProgress([firstLesson.id], LESSON_CATALOG);
  assert.equal(withOne.completedCount, 1);
  assert.equal(withOne.earnedXp, firstLesson.xpReward);
  assert.ok(withOne.percent > 0);
});

test('calculatePhaseProgress tracks phase-specific metrics', () => {
  const phase1Initial = calculatePhaseProgress(1, [], LESSON_CATALOG);
  assert.ok(phase1Initial.totalInPhase > 0);
  assert.equal(phase1Initial.completedInPhase, 0);
  assert.equal(phase1Initial.percent, 0);

  // Complete one Phase 1 lesson
  const phase1Progress = calculatePhaseProgress(1, ['les-01-01'], LESSON_CATALOG);
  assert.equal(phase1Progress.completedInPhase, 1);
  assert.ok(phase1Progress.percent > 0);
});

test('calculatePillarProgress maps standardized training pillars accurately', () => {
  const pillarName = 'Conditioning and Movement';
  const initial = calculatePillarProgress(pillarName, [], LESSON_CATALOG);
  assert.ok(initial.totalLessons > 0);
  assert.equal(initial.completedLessons, 0);
  assert.equal(initial.percent, 0);

  // Lesson 1-1 contains Conditioning and Movement
  const afterOne = calculatePillarProgress(pillarName, ['les-01-01'], LESSON_CATALOG);
  assert.equal(afterOne.completedLessons, 1);
  assert.ok(afterOne.percent > 0);
});

test('getNextRecommendedLesson returns lowest incomplete unlocked lesson', () => {
  const next0 = getNextRecommendedLesson([], LESSON_CATALOG);
  assert.ok(next0);
  assert.equal(next0?.id, 'les-01-01');

  const next1 = getNextRecommendedLesson(['les-01-01'], LESSON_CATALOG);
  assert.ok(next1);
  assert.equal(next1?.id, 'les-01-02');
});

test('gradeKnowledgeCheck grades submissions accurately with explanations', () => {
  const lesson = LESSON_CATALOG[0];
  // Perfect score
  const perfectAnswers = lesson.knowledgeCheck.map((k) => k.correctIndex);
  const resultPass = gradeKnowledgeCheck(lesson, perfectAnswers);
  assert.equal(resultPass.passed, true);
  assert.equal(resultPass.score, lesson.knowledgeCheck.length);

  // Incorrect answer
  const wrongAnswers = lesson.knowledgeCheck.map(() => 99);
  const resultFail = gradeKnowledgeCheck(lesson, wrongAnswers);
  assert.equal(resultFail.passed, false);
  assert.equal(resultFail.score, 0);
});

test('filterLessons and filterTechniques support queries, categories, and bookmarking', () => {
  // Lesson filter by phase
  const phase2Lessons = filterLessons(LESSON_CATALOG, [], [], { phase: 2 });
  assert.ok(phase2Lessons.length > 0);
  phase2Lessons.forEach((l) => assert.equal(l.phaseNumber, 2));

  // Technique search
  const jabTechs = filterTechniques(TECHNIQUE_CATALOG, [], { query: 'jab' });
  assert.ok(jabTechs.length >= 1);

  // Technique bookmarked only
  const bookmarked = filterTechniques(TECHNIQUE_CATALOG, ['tech-orthodox-stance'], { onlyBookmarked: true });
  assert.equal(bookmarked.length, 1);
  assert.equal(bookmarked[0].id, 'tech-orthodox-stance');
});
