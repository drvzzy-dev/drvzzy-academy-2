import { LessonItem, TechniqueItem, TrainingPillar } from '../types/academy';

export type LessonStatus = 'completed' | 'in_progress' | 'available' | 'locked';

/**
 * Checks whether a given lesson has all its prerequisites satisfied.
 * The first lesson in Level 1 is always unlocked.
 */
export function isLessonUnlocked(
  lessonId: string,
  completedLessonIds: string[],
  lessons: LessonItem[]
): boolean {
  const lesson = lessons.find((l) => l.id === lessonId);
  if (!lesson) return false;

  // Level 1 Lesson 1 is always unlocked
  if (lesson.prerequisiteLessonIds.length === 0) {
    return true;
  }

  const completedSet = new Set(completedLessonIds);
  return lesson.prerequisiteLessonIds.every((reqId) => completedSet.has(reqId));
}

/**
 * Determines the explicit status badge for a lesson item.
 */
export function getLessonStatus(
  lessonId: string,
  completedLessonIds: string[],
  inProgressLessonIds: string[],
  lessons: LessonItem[]
): LessonStatus {
  if (completedLessonIds.includes(lessonId)) {
    return 'completed';
  }

  const unlocked = isLessonUnlocked(lessonId, completedLessonIds, lessons);
  if (!unlocked) {
    return 'locked';
  }

  if (inProgressLessonIds.includes(lessonId)) {
    return 'in_progress';
  }

  return 'available';
}

/**
 * Computes overall completion percentage of the curriculum based on completed lessons.
 */
export function calculateCurriculumProgress(
  completedLessonIds: string[],
  lessons: LessonItem[]
): {
  totalLessons: number;
  completedCount: number;
  percent: number;
  totalXpAvailable: number;
  earnedXp: number;
} {
  const totalLessons = lessons.length;
  if (totalLessons === 0) {
    return { totalLessons: 0, completedCount: 0, percent: 0, totalXpAvailable: 0, earnedXp: 0 };
  }

  const completedSet = new Set(completedLessonIds);
  let completedCount = 0;
  let earnedXp = 0;
  let totalXpAvailable = 0;

  lessons.forEach((l) => {
    totalXpAvailable += l.xpReward;
    if (completedSet.has(l.id)) {
      completedCount++;
      earnedXp += l.xpReward;
    }
  });

  const percent = Math.min(100, Math.round((completedCount / totalLessons) * 100));

  return {
    totalLessons,
    completedCount,
    percent,
    totalXpAvailable,
    earnedXp,
  };
}

/**
 * Computes completion status for a specific phase (1 through 5).
 */
export function calculatePhaseProgress(
  phaseNumber: number,
  completedLessonIds: string[],
  lessons: LessonItem[]
): {
  totalInPhase: number;
  completedInPhase: number;
  percent: number;
} {
  const phaseLessons = lessons.filter((l) => l.phaseNumber === phaseNumber);
  const totalInPhase = phaseLessons.length;
  if (totalInPhase === 0) {
    return { totalInPhase: 0, completedInPhase: 0, percent: 0 };
  }

  const completedSet = new Set(completedLessonIds);
  const completedInPhase = phaseLessons.filter((l) => completedSet.has(l.id)).length;
  const percent = Math.min(100, Math.round((completedInPhase / totalInPhase) * 100));

  return {
    totalInPhase,
    completedInPhase,
    percent,
  };
}

/**
 * Calculates progress and coverage for each training pillar.
 */
export function calculatePillarProgress(
  pillarName: string,
  completedLessonIds: string[],
  lessons: LessonItem[]
): {
  pillarName: string;
  totalLessons: number;
  completedLessons: number;
  percent: number;
} {
  const pillarLessons = lessons.filter((l) => l.pillars.includes(pillarName));
  const total = pillarLessons.length;
  if (total === 0) {
    return { pillarName, totalLessons: 0, completedLessons: 0, percent: 0 };
  }

  const completedSet = new Set(completedLessonIds);
  const completed = pillarLessons.filter((l) => completedSet.has(l.id)).length;
  const percent = Math.min(100, Math.round((completed / total) * 100));

  return {
    pillarName,
    totalLessons: total,
    completedLessons: completed,
    percent,
  };
}

/**
 * Finds the next unlocked, incomplete lesson recommended for the user.
 */
export function getNextRecommendedLesson(
  completedLessonIds: string[],
  lessons: LessonItem[]
): LessonItem | null {
  const completedSet = new Set(completedLessonIds);

  for (const lesson of lessons) {
    if (!completedSet.has(lesson.id)) {
      if (isLessonUnlocked(lesson.id, completedLessonIds, lessons)) {
        return lesson;
      }
    }
  }

  return null;
}

/**
 * Filters lessons based on search query, phase, pillar, difficulty, and status.
 */
export function filterLessons(
  lessons: LessonItem[],
  completedLessonIds: string[],
  inProgressLessonIds: string[],
  options: {
    query?: string;
    phase?: number | 'all';
    pillar?: string | 'all';
    difficulty?: string | 'all';
    status?: 'all' | 'available' | 'completed' | 'locked' | 'in_progress';
  }
): LessonItem[] {
  const { query = '', phase = 'all', pillar = 'all', difficulty = 'all', status = 'all' } = options;
  const normalizedQuery = query.toLowerCase().trim();

  return lessons.filter((lesson) => {
    // Phase filter
    if (phase !== 'all' && lesson.phaseNumber !== phase) {
      return false;
    }

    // Pillar filter
    if (pillar !== 'all' && !lesson.pillars.includes(pillar)) {
      return false;
    }

    // Difficulty filter
    if (difficulty !== 'all' && lesson.difficulty !== difficulty) {
      return false;
    }

    // Status filter
    if (status !== 'all') {
      const lessonStatus = getLessonStatus(lesson.id, completedLessonIds, inProgressLessonIds, lessons);
      if (status === 'available') {
        if (lessonStatus !== 'available' && lessonStatus !== 'in_progress') return false;
      } else if (lessonStatus !== status) {
        return false;
      }
    }

    // Search query
    if (normalizedQuery) {
      const matchesTitle = lesson.title.toLowerCase().includes(normalizedQuery);
      const matchesDesc = lesson.description.toLowerCase().includes(normalizedQuery);
      const matchesPillars = lesson.pillars.some((p) => p.toLowerCase().includes(normalizedQuery));
      const matchesObjectives = lesson.learningObjectives.some((o) =>
        o.toLowerCase().includes(normalizedQuery)
      );
      if (!matchesTitle && !matchesDesc && !matchesPillars && !matchesObjectives) {
        return false;
      }
    }

    return true;
  });
}

/**
 * Filters techniques based on search query, category, difficulty, pillar, and bookmark state.
 */
export function filterTechniques(
  techniques: TechniqueItem[],
  bookmarkedIds: string[],
  options: {
    query?: string;
    category?: string | 'All';
    difficulty?: string | 'All';
    pillar?: string | 'All';
    onlyBookmarked?: boolean;
  }
): TechniqueItem[] {
  const { query = '', category = 'All', difficulty = 'All', pillar = 'All', onlyBookmarked = false } = options;
  const normalizedQuery = query.toLowerCase().trim();
  const bookmarkedSet = new Set(bookmarkedIds);

  return techniques.filter((tech) => {
    if (onlyBookmarked && !bookmarkedSet.has(tech.id)) {
      return false;
    }

    if (category !== 'All' && tech.category !== category) {
      return false;
    }

    if (difficulty !== 'All' && tech.difficulty !== difficulty) {
      return false;
    }

    if (pillar !== 'All' && tech.pillar !== pillar) {
      return false;
    }

    if (normalizedQuery) {
      const matchesName = tech.name.toLowerCase().includes(normalizedQuery);
      const matchesCode = tech.code.toLowerCase().includes(normalizedQuery);
      const matchesDesc = tech.description.toLowerCase().includes(normalizedQuery);
      const matchesPillar = tech.pillar.toLowerCase().includes(normalizedQuery);
      const matchesBio = tech.biomechanics.some((b) => b.toLowerCase().includes(normalizedQuery));
      if (!matchesName && !matchesCode && !matchesDesc && !matchesPillar && !matchesBio) {
        return false;
      }
    }

    return true;
  });
}

/**
 * Evaluates knowledge check user submissions.
 * Returns true if all answered questions match correctIndex.
 */
export function gradeKnowledgeCheck(
  lesson: LessonItem,
  userAnswers: number[]
): {
  passed: boolean;
  score: number;
  total: number;
  questionResults: { questionId: string; isCorrect: boolean; explanation: string }[];
} {
  const total = lesson.knowledgeCheck.length;
  let score = 0;
  const questionResults = lesson.knowledgeCheck.map((kc, idx) => {
    const isCorrect = userAnswers[idx] === kc.correctIndex;
    if (isCorrect) score++;
    return {
      questionId: kc.id,
      isCorrect,
      explanation: kc.explanation,
    };
  });

  return {
    passed: score === total,
    score,
    total,
    questionResults,
  };
}
