import {
  CurriculumPhase,
  CurriculumLevel,
  TrainingPillar,
  LessonItem,
  TechniqueItem,
} from '../types/academy';

export const CURRICULUM_PHASES: CurriculumPhase[] = [
  {
    phaseNumber: 1,
    romanId: 'PHASE I',
    title: 'Novice Foundations',
    subtitle: 'Grounding the Kinetic Chain & Gym Safety',
    description:
      'Before throwing power, the pugilist must master balance, guard integrity, and safety protocols. Balance precedes speed; balance precedes defense.',
    levelRange: [1, 4],
    coreThemes: [
      'Boxing terminology and gym etiquette',
      'Stance, balance, and high guard',
      'Linear footwork fundamentals',
      'Warm-up, equipment care, and safety habits',
    ],
  },
  {
    phaseNumber: 2,
    romanId: 'PHASE II',
    title: 'Fundamentals',
    subtitle: 'Striking Mechanics & The Defensive Envelope',
    description:
      'Developing non-telegraphic power generated from the floor through the hips, paired with head movement off the centerline and controlled shadowboxing.',
    levelRange: [5, 9],
    coreThemes: [
      'Jab & rear cross biomechanics',
      'Lead and rear hooks & uppercut fundamentals',
      'Returning to guard & two-punch combinations',
      'Slips, parries, and basic range management',
    ],
  },
  {
    phaseNumber: 3,
    romanId: 'PHASE III',
    title: 'Intermediate Concepts',
    subtitle: 'Combination Sequencing, Angles & Defensive Trapping',
    description:
      'Moving beyond isolated punches into multi-strike combinations, lateral pivots, feints, and ring position awareness.',
    levelRange: [10, 14],
    coreThemes: [
      'Combination structure and punch sequencing',
      'Defense after attacking & catch-and-pitch counters',
      '45-degree & L-step pivots',
      'Technical error recognition & film study fundamentals',
    ],
  },
  {
    phaseNumber: 4,
    romanId: 'PHASE IV',
    title: 'Advanced Technical Study',
    subtitle: 'Counter-Timing, Ring Cutting & Style Adaptation',
    description:
      'Deconstructing fight dynamics: rhythm changes, ring-cutting geometry, multi-layer defensive positioning, and professional bout analysis.',
    levelRange: [15, 19],
    coreThemes: [
      'Offensive and defensive transitions',
      'Counterpunching concepts (pull counter & slip-and-counter)',
      'Ring-cutting theory & rope containment',
      'Analyzing professional boxing footage and style contrasts',
    ],
  },
  {
    phaseNumber: 5,
    romanId: 'PHASE V',
    title: 'Tactical Integration',
    subtitle: 'Mastercraft, Autonomous Precision & Ring Command',
    description:
      'Synthesizing offense, defense, and ring IQ into an autonomous whole. Constructing personal study plans, solving complex tactical puzzles, and sustainable mastery.',
    levelRange: [20, 24],
    coreThemes: [
      'Personal technical study plan creation',
      'Tactical problem-solving against distinct archetypes',
      'Reading patterns in recorded bouts',
      'Long-term sustainable athletic development roadmap',
    ],
  },
];

export const STANDARDIZED_PILLARS: TrainingPillar[] = [
  {
    id: 'pillar-conditioning-movement',
    code: 'PLR-01',
    name: 'Conditioning and Movement',
    shortDesc: 'Cardiovascular Endurance, Agility & Footwork Base',
    description:
      'The legs generate the punch and carry the fighter out of danger. Conditioning ensures technical form remains intact when fatigue accumulates in deep rounds.',
    drillsOverview: [
      'Step-Drag Decoupling Matrix',
      '45-Degree Pivot & L-Step Mobility',
      'Agility Ladder Stance Maintenance',
      'Roadwork Aerobic Base & Interval Sprints',
    ],
    importanceMetric: 'Dictates 80% of defensive escape angles and offensive entry timing.',
    relatedConcepts: ['Stance Width', 'Weight Distribution', 'Pendulum Step', 'Linear Locomotion'],
  },
  {
    id: 'pillar-offense-mechanics',
    code: 'PLR-02',
    name: 'Offense and Punch Mechanics',
    shortDesc: 'Kinetic Chain, Striking Form & Combination Sequencing',
    description:
      'True punching power originates from the floor through ankle extension, hip rotation, thoracic rotation, and clenched knuckles at the exact moment of impact.',
    drillsOverview: [
      'Piston Jab Recoil Snap',
      'Rear Cross Hip Drive Alignment',
      'Lead Hook Axis Rotations',
      'Body Shovel Hook Level Change',
    ],
    importanceMetric: 'Ensures maximum kinetic transfer with minimum telegraphing.',
    relatedConcepts: ['Pronation', 'Kinetic Chain', 'Telegraph Elimination', 'Combination Flow'],
  },
  {
    id: 'pillar-defense-awareness',
    code: 'PLR-03',
    name: 'Defense and Awareness',
    shortDesc: 'Head Movement, Parries, Blocking & Spatial Guard',
    description:
      'Hit and do not be hit. Mastering slips, weaves, covers, and parries while keeping eyes locked on the opponent’s chest to anticipate oncoming trajectory.',
    drillsOverview: [
      'Slip-Line Pendulum Drill',
      'Rear Hand Catch-Parry Line',
      'High Guard Structural Wall',
      'Bob & Weave U-Path Reset',
    ],
    importanceMetric: 'Prevents damage and directly establishes counter-punching opportunities.',
    relatedConcepts: ['Centerline Evasion', 'Pyramid Guard', 'Parry Deflection', 'Pocket Vision'],
  },
  {
    id: 'pillar-technical-safety',
    code: 'PLR-04',
    name: 'Technical Practice and Equipment Safety',
    shortDesc: 'Hand Wrapping, Bag Protocols & Safe Training Discipline',
    description:
      'Preserving anatomical longevity through strict hand wrapping, proper glove selection, bag hygiene, and disciplined, controlled drilling habits without dangerous stunts.',
    drillsOverview: [
      '180-inch Hand Wrap Protocol',
      'Wrist Alignment Heavy Bag Verification',
      'Mirror Form Strict Calibration',
      'Equipment Inspection & Glove Care',
    ],
    importanceMetric: 'Protects the delicate metacarpal bones and wrists from chronic trauma.',
    relatedConcepts: ['180-inch Gauze/Wrap', 'Wrist Stiffness', 'Safe Bag Density', 'No Dangerous Stunts'],
  },
  {
    id: 'pillar-tactics-iq',
    code: 'PLR-05',
    name: 'Tactics and Boxing IQ',
    shortDesc: 'Ring Geometry, Feints, Trap Setting & Opponent Archetypes',
    description:
      'Boxing is a physical chess match played at high speed. Manipulating distance, reading habits, cutting off exits, and dictating where the fight takes place.',
    drillsOverview: [
      'Visual Feint & Half-Step Trigger',
      'Ring Cutting Perimeter Trapping',
      'Bait & Counter Sequence Timing',
      'Film Deconstruction & Pattern Mapping',
    ],
    importanceMetric: 'Differentiates raw athletes from championship tacticians.',
    relatedConcepts: ['Feinting', 'Ring Cutting', 'Archetype Neutralization', 'Baiting'],
  },
  {
    id: 'pillar-recovery-reflection',
    code: 'PLR-06',
    name: 'Recovery and Reflection',
    shortDesc: 'Active Rest, Mobility, Journaling & Sustainable Progress',
    description:
      'Adaptation occurs during recovery, not exhaustion. Tracking daily metrics, post-drill journaling, thoracic mobility, sleep hygiene, and long-term athletic health.',
    drillsOverview: [
      'Post-Session Technical Journaling',
      'Thoracic Spine & Shoulder Mobility',
      'Deliberate Breathwork & Down-regulation',
      'Weekly Volume Auditing',
    ],
    importanceMetric: 'Guarantees continuous injury-free athletic longevity and mental clarity.',
    relatedConcepts: ['Training Journal', 'Mobility Maintenance', 'Deliberate Rest', 'Self-Assessment'],
  },
];

export const CURRICULUM_LEVELS: CurriculumLevel[] = [
  // Phase I: Novice Foundations (Levels 1-4)
  {
    levelNumber: 1,
    phaseNumber: 1,
    title: 'Stance, Balance & Guard Alignment',
    subtitle: 'The 55/45 weight distribution and chin tuck protocol',
    xpRequired: 500,
    status: 'current',
    estimatedHours: 8,
    drillsCount: 4,
    keySkills: ['Athletic Stance Geometry', 'Weight Distribution', 'Eye Level Locking', 'High Guard Wall'],
    benchmarkTest: '3 Rounds continuous stance maintenance on mirror line without heel collapse or chin exposure.',
    lessonIds: ['les-01-01', 'les-01-02'],
  },
  {
    levelNumber: 2,
    phaseNumber: 1,
    title: 'Linear Footwork: Step-Drag Locomotion',
    subtitle: 'Preserving base through forward, rear, and lateral movement',
    xpRequired: 1200,
    status: 'locked',
    estimatedHours: 10,
    drillsCount: 5,
    keySkills: ['Lead Foot Push', 'Rear Foot Anchor', 'No Cross-Over Rule', 'Micro-Shuffles'],
    benchmarkTest: '5-Minute perimeter cone drill maintaining exact stance width and ready guard posture.',
    lessonIds: ['les-02-01'],
  },
  {
    levelNumber: 3,
    phaseNumber: 1,
    title: 'Equipment Safety & The 180-Inch Hand Wrap',
    subtitle: 'Metacarpal stabilization, wrist alignment, and gym etiquette',
    xpRequired: 2000,
    status: 'locked',
    estimatedHours: 6,
    drillsCount: 3,
    keySkills: ['Mexican-Style Hand Wrap', 'Glove Ounce Selection', 'Impact Joint Alignment', 'Gym Respect Code'],
    benchmarkTest: 'Complete two hand wraps under 3 minutes with verified knuckle pad and zero wrist flexion.',
    lessonIds: ['les-03-01'],
  },
  {
    levelNumber: 4,
    phaseNumber: 1,
    title: 'Warm-Up Architecture & Stance Reset',
    subtitle: 'Dynamic joint lubrication and responsible practice habits',
    xpRequired: 2900,
    status: 'locked',
    estimatedHours: 8,
    drillsCount: 4,
    keySkills: ['Rotator Cuff Prep', 'Hip Opener Flow', 'Recovery Shadowboxing', 'Phase I Benchmark'],
    benchmarkTest: 'Phase I Mastery Evaluation: 3 rounds combining stance, linear steps, and guard reset without errors.',
    lessonIds: ['les-04-01'],
  },

  // Phase II: Fundamentals (Levels 5-9)
  {
    levelNumber: 5,
    phaseNumber: 2,
    title: 'The Piston Jab: Non-Telegraphic Snap',
    subtitle: 'Cocking from the shoulder, pronation at impact, and immediate recoil',
    xpRequired: 4000,
    status: 'locked',
    estimatedHours: 12,
    drillsCount: 6,
    keySkills: ['Thumb-Down Rotation', 'Rear Guard Lockdown', 'Step-Jab Coordination', 'Visual Retraction'],
    benchmarkTest: '50 Reps high-velocity jab test without elbow flare or head forward tilt on camera.',
    lessonIds: ['les-05-01'],
  },
  {
    levelNumber: 6,
    phaseNumber: 2,
    title: 'The Rear Straight (Cross): Kinetic Chain Explosion',
    subtitle: 'Ball-of-foot pivot, pelvic tilt, and thoracic snap',
    xpRequired: 5300,
    status: 'locked',
    estimatedHours: 14,
    drillsCount: 6,
    keySkills: ['Rear Heel Elevation', 'Hip Torquing', 'Chin Protection Behind Shoulder', 'Straight Recoil'],
    benchmarkTest: 'Heavy bag power transfer metric: 60 strikes with verified 45-degree rear heel rotation.',
    lessonIds: ['les-06-01'],
  },
  {
    levelNumber: 7,
    phaseNumber: 2,
    title: 'Lead & Rear Hooks: Rotational Center Axis',
    subtitle: 'Lead pivot, elbow parallel to floor, and horizontal torque',
    xpRequired: 6800,
    status: 'locked',
    estimatedHours: 14,
    drillsCount: 6,
    keySkills: ['Squash the Bug Pivot', 'Elbow Level with Wrist', 'Weight Transfer', 'Guard Preservation'],
    benchmarkTest: 'Paddle accuracy drill: 40 lead hooks with 95% clean snap and rear hand glued to chin.',
    lessonIds: ['les-07-01'],
  },
  {
    levelNumber: 8,
    phaseNumber: 2,
    title: 'The Rising Uppercut & Close Range Mechanics',
    subtitle: 'Leg drive rather than arm pulling: the compact vertical strike',
    xpRequired: 8500,
    status: 'locked',
    estimatedHours: 12,
    drillsCount: 5,
    keySkills: ['Knee Dip & Upward Drive', 'Compact Lever Arm', 'Defensive Hand Clamped', 'Short Impact Arc'],
    benchmarkTest: 'Infighting combination protocol: 30 alternating compact uppercuts with zero dropped guard.',
    lessonIds: ['les-08-01'],
  },
  {
    levelNumber: 9,
    phaseNumber: 2,
    title: 'The 1-2 & Basic Defense: Slip and Parry',
    subtitle: 'Returning to guard and evading along the centerline',
    xpRequired: 10400,
    status: 'locked',
    estimatedHours: 16,
    drillsCount: 7,
    keySkills: ['1-2 Combination Rhythm', 'Inside & Outside Slip', 'Rear Hand Parry', 'Phase II Benchmark'],
    benchmarkTest: 'Phase II Synthesis Evaluation: 3 rounds shadowboxing demonstrating 1-2, slip, and clean guard reset.',
    lessonIds: ['les-09-01'],
  },

  // Phase III: Intermediate Concepts (Levels 10-14)
  {
    levelNumber: 10,
    phaseNumber: 3,
    title: 'Combination Structure & Punch Sequencing',
    subtitle: 'High-low conversions, alternating sides, and kinetic rhythm',
    xpRequired: 12600,
    status: 'locked',
    estimatedHours: 15,
    drillsCount: 6,
    keySkills: ['Head-to-Body Conversion', 'Weight Shift Recycling', 'Three-Punch Sequences', 'Smooth Recoil'],
    benchmarkTest: 'Execute 1-2-3-2 and 1-3-2 combinations at 85% speed with perfect weight distribution.',
    lessonIds: ['les-10-01'],
  },
  {
    levelNumber: 11,
    phaseNumber: 3,
    title: 'Defense After Attacking & Catch-and-Pitch',
    subtitle: 'Never admire your work: immediate exit slips, weaves, and return strikes',
    xpRequired: 15000,
    status: 'locked',
    estimatedHours: 16,
    drillsCount: 7,
    keySkills: ['Punch-Slip-Exit Protocol', 'Catch-and-Shoot Cross', 'Weave Under Hook', 'Head Slotting'],
    benchmarkTest: '4-Round defensive shadowboxing test with mandatory exit slip after every combination.',
    lessonIds: ['les-11-01'],
  },
  {
    levelNumber: 12,
    phaseNumber: 3,
    title: 'Angles & Lateral Pivots: The 45° & L-Step',
    subtitle: 'Stepping off the railroad tracks to open blind spot trajectories',
    xpRequired: 17700,
    status: 'locked',
    estimatedHours: 16,
    drillsCount: 6,
    keySkills: ['Lead Foot Anchor Pivot', 'Rear Foot Swing', 'L-Step Cutback', 'T-Position Domination'],
    benchmarkTest: 'Heavy bag circling protocol: 5 rounds maintaining 45-degree angle dominance.',
    lessonIds: ['les-12-01'],
  },
  {
    levelNumber: 13,
    phaseNumber: 3,
    title: 'The Art of the Feint & Distance Management',
    subtitle: 'Drawing defensive reactions without committing kinetic energy',
    xpRequired: 20700,
    status: 'locked',
    estimatedHours: 18,
    drillsCount: 6,
    keySkills: ['Shoulder Twitch Feint', 'Half-Step Jab Probe', 'Visual Misdirection', 'Distance Gauge'],
    benchmarkTest: 'Mirror feint calibration: 30 feints triggering simulated opponent reaction and instant entry.',
    lessonIds: ['les-13-01'],
  },
  {
    levelNumber: 14,
    phaseNumber: 3,
    title: 'Technical Error Recognition & Film Study Fundamentals',
    subtitle: 'Auditing footage, diagnosing flared elbows, and tactical debriefing',
    xpRequired: 24000,
    status: 'locked',
    estimatedHours: 16,
    drillsCount: 5,
    keySkills: ['Video Frame Auditing', 'Weight Leak Detection', 'Habit Cataloging', 'Phase III Benchmark'],
    benchmarkTest: 'Phase III Synthesis: Complete a 5-point technical breakdown of a recorded technical round.',
    lessonIds: ['les-14-01'],
  },

  // Phase IV: Advanced Technical Study (Levels 15-19)
  {
    levelNumber: 15,
    phaseNumber: 4,
    title: 'Offensive and Defensive Transitions',
    subtitle: 'Fluid transitions between high guard, active shelling, and counter openings',
    xpRequired: 27700,
    status: 'locked',
    estimatedHours: 18,
    drillsCount: 7,
    keySkills: ['Guard Shell Absorption', 'Shoulder Bump Frame', 'Elbow Wedge Interception', 'Pocket Transition'],
    benchmarkTest: '3-Round inside-outside transition drill without defensive lapse.',
    lessonIds: ['les-15-01'],
  },
  {
    levelNumber: 16,
    phaseNumber: 4,
    title: 'Apex Counterpunching: The Pull Counter & The Slip-Jolt',
    subtitle: 'Timing the opponent within the dead space of their punch trajectory',
    xpRequired: 31800,
    status: 'locked',
    estimatedHours: 20,
    drillsCount: 8,
    keySkills: ['Millimeter Pull-Back', 'Instant Weight Reload', 'Simultaneous Slip-Cross', 'Unflinching Vision'],
    benchmarkTest: 'Reaction drill: 40 pull-counter sequences with zero backward lean compromise.',
    lessonIds: ['les-16-01'],
  },
  {
    levelNumber: 17,
    phaseNumber: 4,
    title: 'Ring-Cutting Theory & Geometric Containment',
    subtitle: 'Herding elusive fighters by closing off the 45-degree perimeter escape',
    xpRequired: 36300,
    status: 'locked',
    estimatedHours: 20,
    drillsCount: 7,
    keySkills: ['Lateral Step Containment', 'Cutting the Diagonal', 'Rope Trapping Stance', 'Patience Discipline'],
    benchmarkTest: 'Ring perimeter containment drill maintaining pocket center against lateral retreaters.',
    lessonIds: ['les-17-01'],
  },
  {
    levelNumber: 18,
    phaseNumber: 4,
    title: 'Body Snatching: Tactical Liver & Spleen Warfare',
    subtitle: 'Lowering the guard and draining systemic conditioning with the 45° shovel hook',
    xpRequired: 41200,
    status: 'locked',
    estimatedHours: 20,
    drillsCount: 7,
    keySkills: ['45° Shovel Hook', 'Level Changing', 'Right Hand to Solar Plexus', 'Conditioning Impact'],
    benchmarkTest: 'Heavy body-bag cadence test: 80 power body strikes with strict form and zero head drop.',
    lessonIds: ['les-18-01'],
  },
  {
    levelNumber: 19,
    phaseNumber: 4,
    title: 'Analyzing Professional Boxing Footage & Style Archetypes',
    subtitle: 'Deconstructing out-boxers, swarmers, and sluggers under forensic lens',
    xpRequired: 46600,
    status: 'locked',
    estimatedHours: 22,
    drillsCount: 6,
    keySkills: ['Archetype Decoding', 'Counter-Strategy Formulation', 'Footwork Vector Analysis', 'Phase IV Milestone'],
    benchmarkTest: 'Phase IV Synthesis: Comprehensive tactical breakdown of 2 professional world-title bouts.',
    lessonIds: ['les-19-01'],
  },

  // Phase V: Tactical Integration (Levels 20-24)
  {
    levelNumber: 20,
    phaseNumber: 5,
    title: 'Creating a Personal Technical Study Plan',
    subtitle: 'Structuring weekly volume, targeting personal weaknesses, and periodization',
    xpRequired: 52500,
    status: 'locked',
    estimatedHours: 24,
    drillsCount: 6,
    keySkills: ['Personal Volume Auditing', 'Weak-Point Isolation', 'Periodized Cadence', 'Deliberate Rest'],
    benchmarkTest: 'Submit a complete 8-week structured academy curriculum blueprint for your fighter archetype.',
    lessonIds: ['les-20-01'],
  },
  {
    levelNumber: 21,
    phaseNumber: 5,
    title: 'Integrating Offense, Defense & Movement',
    subtitle: 'The seamless synthesis: striking during movement and slipping during punching',
    xpRequired: 59000,
    status: 'locked',
    estimatedHours: 26,
    drillsCount: 8,
    keySkills: ['Simultaneous Move-Strike', 'Pocket Flow State', 'Non-Stop Centerline Evasion', 'Ring Generalship'],
    benchmarkTest: '6 Rounds uninterrupted technical shadowboxing integrating all six training pillars.',
    lessonIds: ['les-21-01'],
  },
  {
    levelNumber: 22,
    phaseNumber: 5,
    title: 'Tactical Problem-Solving Under Pressure',
    subtitle: 'Neutralizing southpaws, awkward switch-hitters, and relentless forward pressers',
    xpRequired: 66100,
    status: 'locked',
    estimatedHours: 28,
    drillsCount: 8,
    keySkills: ['Lead Foot Battle vs Southpaw', 'Clinch Control Safety', 'Inside Elbow Frames', 'Mental Composure'],
    benchmarkTest: 'Tactical scenario test: Resolve 5 distinct high-pressure ring tactical puzzles with 100% accuracy.',
    lessonIds: ['les-22-01'],
  },
  {
    levelNumber: 23,
    phaseNumber: 5,
    title: 'Sustainable Training & Long-Term Athletic Longevity',
    subtitle: 'Managing joint fatigue, neurological recovery, and training longevity across decades',
    xpRequired: 74000,
    status: 'locked',
    estimatedHours: 28,
    drillsCount: 6,
    keySkills: ['Autoregulation', 'CNS Fatigue Diagnostics', 'Nutritional Hydration Basics', 'Long-term Health'],
    benchmarkTest: 'Pass comprehensive training safety and recovery audit protocol.',
    lessonIds: ['les-23-01'],
  },
  {
    levelNumber: 24,
    phaseNumber: 5,
    title: 'The Apex Pugilist: Knowledge Assessment & Grandmaster Blueprint',
    subtitle: 'The ultimate synthesis of the Sweet Science: knowledge, discipline, and lifelong mastery',
    xpRequired: 82500,
    status: 'locked',
    estimatedHours: 32,
    drillsCount: 10,
    keySkills: ['Sweet Science Mastery', 'Tactical Foresight', 'Teaching & Mentorship Protocol', 'Apex Synthesis'],
    benchmarkTest: 'DRVZZY ACADEMY Final Grandmaster Thesis: 24-Level Comprehensive Knowledge Assessment & Defense.',
    lessonIds: ['les-24-01'],
  },
];

export const LESSON_CATALOG: LessonItem[] = [
  // --- LEVEL 1 LESSONS ---
  {
    id: 'les-01-01',
    levelNumber: 1,
    phaseNumber: 1,
    title: 'Stance Geometry & Neutral Alignment',
    description:
      'Master the orthodox and southpaw foundation: foot placement on the diagonal mirror line, 55/45 weight distribution, and tucking the chin behind the lead shoulder.',
    pillars: ['Conditioning and Movement', 'Technical Practice and Equipment Safety'],
    difficulty: 'Novice',
    estimatedDurationMin: 25,
    prerequisiteLessonIds: [],
    learningObjectives: [
      'Position feet shoulder-width apart along a 45-degree diagonal reference line.',
      'Maintain 55% weight on rear foot and 45% on lead foot with soft, responsive knees.',
      'Tuck chin securely into the clavicle pocket with eyes looking up under eyebrows.',
      'Align hands in high guard without occluding peripheral vision.',
    ],
    mainExplanation:
      'In boxing, your stance is the launchpad for all offense and the shock absorber for all defense. If your base collapses, your punches lack kinetic transfer and you become vulnerable to balance disruption. By distributing weight approximately 55% onto the ball of the rear foot and 45% on the lead foot, you remain primed to spring forward, pivot laterally, or slide rearward without telegraphic weight shifts.',
    conceptualBreakdown: [
      {
        step: 'The Diagonal Line Protocol',
        explanation:
          'Place a tape line on the floor. For Orthodox, place the lead toe on the left side of the line and the rear heel on the right side. Feet must never cross or sit on a single balance-beam line.',
      },
      {
        step: 'Knee Flexion & Center of Gravity',
        explanation:
          'Bend knees roughly 15 to 20 degrees. Never lock the knees. A locked joint transmits shock directly into the hips and head instead of dispersing it through the muscular chain.',
      },
      {
        step: 'Chin Tucking & The Clavicle Pocket',
        explanation:
          'Lower the jaw directly toward the chest without bending the neck forward. Gaze forward under the brow line. Raising the chin exposes the mandibular nerve to catastrophic concussive leverage.',
      },
      {
        step: 'Elbows In & Forearm Wall',
        explanation:
          'Elbows must gently graze the ribs, shielding the liver and spleen. Gloves rest at cheekbone height with palms facing inward, not forward.',
      },
    ],
    commonMistakes: [
      'Standing flat-footed on the rear heel, causing balance loss when pushed.',
      'Placing feet on a straight line (tightrope stance), eliminating lateral balance.',
      'Lifting the chin while looking at the opponent, leaving the jaw wide open.',
      'Flaring elbows out like chicken wings, opening the floating ribs to body strikes.',
    ],
    safetyConsiderations: [
      'Always practice on a level, non-slip surface to prevent ankle rolling.',
      'Wear supportive boxing shoes or cross-trainers; avoid socks on smooth wooden floors.',
      'Never lock the knee joints during stance drills to avoid ligament hyperextension.',
    ],
    suggestedPractice:
      'Set a 3-round timer (2 min work, 1 min rest). Stand in front of a mirror with a line between your feet. Maintain stance while gently bouncing on the balls of your feet, checking chin tuck every 15 seconds.',
    knowledgeCheck: [
      {
        id: 'kc-01-01',
        question: 'What is the primary danger of placing both feet along a single straight line (tightrope stance)?',
        options: [
          'It makes your punches too fast to control.',
          'It destroys your lateral balance and leaves you prone to tipping over.',
          'It places too much strain on the wrist joints.',
          'It makes your chin tuck impossible.',
        ],
        correctIndex: 1,
        explanation:
          'Standing along a single line removes your lateral base of support. Any lateral movement or incoming angled strike will easily tip you off balance.',
      },
      {
        id: 'kc-01-02',
        question: 'How should your weight be distributed between your feet in a standard neutral boxing stance?',
        options: [
          '90% on the lead leg for maximum power.',
          '100% on the rear heel so the front foot can kick.',
          'Approximately 55% on the rear foot and 45% on the lead foot.',
          '50% on both flat heels.',
        ],
        correctIndex: 2,
        explanation:
          'A slight 55/45 rear-leg bias keeps your lead foot light enough to step, probe, or check, while keeping the rear leg ready to launch or absorb momentum.',
      },
    ],
    reflectionPrompt:
      'Reflect on your natural posture. Did you notice your rear heel wanting to drop flat or your elbows flaring outward as your shoulders grew fatigued?',
    completionCriteria:
      'Successfully pass the 2-question knowledge check and log at least 3 rounds of verified stance holding.',
    xpReward: 150,
    relatedLessonIds: ['les-01-02', 'les-02-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-high-guard'],
  },
  {
    id: 'les-01-02',
    levelNumber: 1,
    phaseNumber: 1,
    title: 'The High Guard Defensive Wall',
    description:
      'Construct a tight, shock-absorbing defensive shield using the forearms and gloves without blinding yourself to incoming shots.',
    pillars: ['Defense and Awareness', 'Technical Practice and Equipment Safety'],
    difficulty: 'Novice',
    estimatedDurationMin: 20,
    prerequisiteLessonIds: ['les-01-01'],
    learningObjectives: [
      'Lock gloves against the cheekbones with palms inward.',
      'Maintain an optical slot between the gloves to preserve sightlines.',
      'Absorb incoming impact through knee flex rather than arm collapsing.',
    ],
    mainExplanation:
      'The high guard is your primary shield when trapped in the pocket. It is not an impermeable bunker; rather, it deflects and blunts incoming shots so you can counter or escape. The gloves rest firmly against the temple and cheekbones—if you hold them three inches off your face, an opponent’s punch will smash your own gloves into your nose.',
    conceptualBreakdown: [
      {
        step: 'Glove Contact Point',
        explanation:
          'Press the thumbs against the temple/cheekbone area. The elbows clamp tight against the torso to close the thoracic corridor.',
      },
      {
        step: 'Looking Through the Window',
        explanation:
          'Never close your eyes or duck your head completely down. Keep eyes fixed on the opponent’s clavicle through the narrow slit between your wrists.',
      },
      {
        step: 'Catching with Legs',
        explanation:
          'When an impact arrives against the guard, bend the knees slightly to absorb kinetic energy down into the floor.',
      },
    ],
    commonMistakes: [
      'Holding gloves away from the face, letting punches drive your hands into your teeth.',
      'Squeezing gloves together so tightly that you cannot see incoming hooks.',
      'Crouching down and looking at the floor.',
    ],
    safetyConsiderations: [
      'Do not absorb high-impact heavy punches without wraps and sparring headgear in partner drills.',
      'In solo training, focus on maintaining structural stiffness without tensing neck traps.',
    ],
    suggestedPractice:
      '2 Rounds shadowboxing in front of a mirror: throw a jab, immediately snap into high guard, hold for 3 seconds while verifying sightlines, then reset.',
    knowledgeCheck: [
      {
        id: 'kc-01-03',
        question: 'Why must your gloves rest directly against your face/temples in a high guard rather than hovering a few inches in front?',
        options: [
          'Because hovering gloves will be punched backward into your own face by incoming strikes.',
          'Because hovering gloves weigh significantly more.',
          'To make your hooks travel faster.',
          'Because boxing rules penalize hovering gloves.',
        ],
        correctIndex: 0,
        explanation:
          'If your gloves are floating in front of your face without structural support from your skull and forehead, incoming power punches will snap them violently into your nose and eyes.',
      },
    ],
    reflectionPrompt:
      'Did you feel any tension in your trapezius muscles when holding the high guard? How can you relax your upper shoulders while keeping forearms rigid?',
    completionCriteria: 'Pass the comprehension question and confirm visual slot alignment.',
    xpReward: 150,
    relatedLessonIds: ['les-01-01', 'les-04-01'],
    relatedTechniqueIds: ['tech-high-guard'],
  },

  // --- LEVEL 2 LESSONS ---
  {
    id: 'les-02-01',
    levelNumber: 2,
    phaseNumber: 1,
    title: 'Linear Locomotion: The Step-Drag Protocol',
    description:
      'Learn how to close distance and retreat without ever crossing your feet, jumping, or compromising your 55/45 base.',
    pillars: ['Conditioning and Movement'],
    difficulty: 'Novice',
    estimatedDurationMin: 30,
    prerequisiteLessonIds: ['les-01-01'],
    learningObjectives: [
      'Execute forward movement: push off rear ball of foot, step with lead, drag rear foot.',
      'Execute backward retreat: push off lead ball of foot, step with rear, drag lead foot.',
      'Enforce the "Zero Cross-Over" rule under all conditions.',
    ],
    mainExplanation:
      'In boxing, movement is initiated by pushing off the foot furthest from the intended direction. To move forward, you push off the rear foot and step with the lead; the rear foot instantly drags forward to restore the original stance width. To move backward, push off the lead foot and step with the rear. Crossing your feet even for a millisecond leaves you completely defenseless against a knockdown.',
    conceptualBreakdown: [
      {
        step: 'Moving Forward (Step-Drag)',
        explanation:
          'Push the floor away with the ball of the rear foot. Take a measured 6-8 inch step forward with the lead foot. Immediately drag the rear foot the exact same 6-8 inches.',
      },
      {
        step: 'Moving Backward (Push-Retreat)',
        explanation:
          'Push off the ball of the lead foot. Step back 6-8 inches with the rear foot. Drag the lead foot back to reset distance.',
      },
      {
        step: 'Maintaining Stance Width',
        explanation:
          'Imagine a rigid steel rod connecting your ankles. Your feet should never get closer than shoulder-width, nor widen into a split.',
      },
    ],
    commonMistakes: [
      'Crossing one foot over the other during retreat, completely eliminating balance.',
      'Hopping or bounding into the air, which disconnects you from ground traction.',
      'Dragging the toes on the floor instead of a controlled slide on the ball of the foot.',
    ],
    safetyConsiderations: [
      'Keep ankles aligned; do not drag foot along the side of the shoe sole.',
      'Stop immediately if you feel acute Achilles tendon or arch pain.',
    ],
    suggestedPractice:
      'Tape a 10-foot line on the floor. Complete 5 sets of forward step-drags and backward retreats down the line, maintaining equal stance width throughout.',
    knowledgeCheck: [
      {
        id: 'kc-02-01',
        question: 'When moving forward in a boxing stance, which foot initiates the kinetic push against the canvas?',
        options: [
          'The lead foot pulls you forward.',
          'The rear foot pushes into the floor to drive you forward.',
          'Both feet hop simultaneously.',
          'You lean your chest forward to fall into the step.',
        ],
        correctIndex: 1,
        explanation:
          'You push off the foot furthest from the direction of travel. To go forward, the rear foot generates the ground reaction force.',
      },
    ],
    reflectionPrompt: 'Notice whether your feet get closer together when you get tired or step quickly. What cue helps you keep stance width constant?',
    completionCriteria: 'Score 100% on the locomotion knowledge check and log 10 minutes of step-drag drills.',
    xpReward: 200,
    relatedLessonIds: ['les-01-01', 'les-05-01'],
    relatedTechniqueIds: ['tech-step-drag', 'tech-lateral-shuffle'],
  },

  // --- LEVEL 3 LESSONS ---
  {
    id: 'les-03-01',
    levelNumber: 3,
    phaseNumber: 1,
    title: 'Anatomy of the 180-Inch Hand Wrap & Gym Safety',
    description:
      'Protect the 27 small bones of the human hand. Learn professional wrapping, knuckle padding, wrist lockup, and respectful gym etiquette.',
    pillars: ['Technical Practice and Equipment Safety', 'Recovery and Reflection'],
    difficulty: 'Novice',
    estimatedDurationMin: 25,
    prerequisiteLessonIds: ['les-01-01'],
    learningObjectives: [
      'Wrap knuckles, thumb, and wrist with graduated tension using 180-inch semi-elastic wraps.',
      'Ensure the wrist joint cannot bend backward upon heavy bag impact.',
      'Understand gym hygiene, gear cleaning, and sparring safety ethics.',
    ],
    mainExplanation:
      'The human hand evolved for dexterity, not for slamming into solid objects at high velocity. The metacarpals and carpals will fracture without exterior structural reinforcement. A proper wrap transforms 27 individual bones and soft tissue into a unified, rigid striking brick. Never hit a heavy bag with bare hands or unpadded wraps.',
    conceptualBreakdown: [
      {
        step: 'Anchor & Wrist Base',
        explanation:
          'Loop thumb, wind wrap 3 times firmly around the wrist just below the joint line to create a stable anchor.',
      },
      {
        step: 'Knuckle Cushioning Pad',
        explanation:
          'Spread fingers wide. Lay 4 to 5 accordion folds across the knuckles to form a thick protective pad. Secure with 2 wraps.',
      },
      {
        step: 'Finger Lock & X-Pattern',
        explanation:
          'Run wrap between each finger, anchoring back to the wrist each time to prevent the metacarpals from splaying outward.',
      },
      {
        step: 'Thumb Lock & Final Closure',
        explanation:
          'Wrap thumb twice in an over-under figure-eight. Finish remaining wrap around the wrist joint and secure velcro.',
      },
    ],
    commonMistakes: [
      'Wrapping fingers with a closed fist, resulting in a wrap so tight it cuts off circulation.',
      'Wrapping too loose, allowing the wrap to shift and bunch up inside the glove.',
      'Neglecting the wrist joint, leaving it prone to hyperflexion on an off-center hook.',
    ],
    safetyConsiderations: [
      'NEVER punch trees, concrete, brick walls, or unyielding hard surfaces.',
      'If fingers turn pale or tingle, unwrap immediately and re-wrap with reduced tension.',
      'Wash wraps after every training session to prevent bacterial buildup and skin infections.',
    ],
    suggestedPractice:
      'Wrap both hands twice from start to finish. Make a tight fist: the wrap should feel firm and solid across knuckles and wrist, with zero thumb numbness.',
    knowledgeCheck: [
      {
        id: 'kc-03-01',
        question: 'What is the primary anatomical purpose of hand wraps in boxing?',
        options: [
          'To make your punches hurt more.',
          'To secure the 27 delicate bones of the hand and stabilize the wrist joint.',
          'To add weight to your gloves for training resistance.',
          'To look intimidating to opponents.',
        ],
        correctIndex: 1,
        explanation:
          'Hand wraps compress and align the metacarpals and carpals while immobilizing the wrist, preventing fractures and sprains.',
      },
    ],
    reflectionPrompt: 'Did you notice any numbness or restricted circulation? How can you calibrate wrap tension so it feels snug without choking blood flow?',
    completionCriteria: 'Pass the wrap check and confirm understanding of equipment safety rules.',
    xpReward: 200,
    relatedLessonIds: ['les-01-01', 'les-04-01'],
    relatedTechniqueIds: ['tech-hand-wrap-protocol'],
  },

  // --- LEVEL 4 LESSONS ---
  {
    id: 'les-04-01',
    levelNumber: 4,
    phaseNumber: 1,
    title: 'Phase I Synthesis: Warm-Up, Base & Shadowboxing',
    description:
      'Synthesize stance, step-drag locomotion, high guard reset, and dynamic mobility in a disciplined solo shadowboxing workout.',
    pillars: ['Conditioning and Movement', 'Recovery and Reflection'],
    difficulty: 'Novice',
    estimatedDurationMin: 30,
    prerequisiteLessonIds: ['les-01-02', 'les-02-01', 'les-03-01'],
    learningObjectives: [
      'Perform a 5-minute dynamic joint warm-up targeting neck, thoracic spine, hips, and ankles.',
      'Execute 3 rounds of structured shadowboxing focusing exclusively on stance maintenance and clean linear steps.',
      'Complete Phase I Novice Foundations benchmark test.',
    ],
    mainExplanation:
      'Shadowboxing is the purest technical mirror in boxing. Without a target to hit or a partner pushing you, your focus must remain 100% on your internal mechanics. In this synthesis lesson, you will run through your full warm-up, step-drag locomotion, and guard resets, cementing your Phase I habits.',
    conceptualBreakdown: [
      {
        step: 'Dynamic Mobility Warm-Up',
        explanation: 'Arm circles, torso rotations, hip openers, and ankle rolls for 5 continuous minutes.',
      },
      {
        step: 'Round 1: Stance & Mirror Calibration',
        explanation: 'Holding stance, micro-weight shifts between 55% and 45%, high guard sightlines.',
      },
      {
        step: 'Round 2: Linear Vector Locomotion',
        explanation: 'Forward and backward step-drags along tape line, ensuring zero foot crossing.',
      },
      {
        step: 'Round 3: Defense Reset & Cool Down',
        explanation: 'Step, freeze in high guard, check chin tuck, deep diaphragmatic nasal breathing.',
      },
    ],
    commonMistakes: [
      'Skipping the warm-up and going straight into ballistic movements.',
      'Rushing footwork and letting feet drag or cross.',
    ],
    safetyConsiderations: [
      'Always cool down with slow arm swings and deep breathing to restore resting heart rate.',
      'Do not train to exhaustion during technical foundation drills.',
    ],
    suggestedPractice: 'Complete all 3 rounds in front of a mirror or camera recording for self-review.',
    knowledgeCheck: [
      {
        id: 'kc-04-01',
        question: 'During technical shadowboxing, what should be your primary visual focus?',
        options: [
          'Looking down at your shoes to ensure they are clean.',
          'Looking directly ahead at an imaginary opponent’s chest while checking stance and guard in the mirror.',
          'Looking up at the ceiling to maintain balance.',
          'Staring at the timer clock.',
        ],
        correctIndex: 1,
        explanation:
          'Fixing your gaze at chest level preserves your peripheral vision and chin tuck while simulating real ring awareness.',
      },
    ],
    reflectionPrompt: 'Write down two technical flaws you spotted in the mirror during this 3-round synthesis.',
    completionCriteria: 'Complete Phase I benchmark and submit reflection notes.',
    xpReward: 300,
    relatedLessonIds: ['les-01-01', 'les-02-01', 'les-05-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-step-drag', 'tech-high-guard'],
  },

  // --- LEVEL 5 LESSONS ---
  {
    id: 'les-05-01',
    levelNumber: 5,
    phaseNumber: 2,
    title: 'The Piston Jab: Pronation & Immediate Recoil',
    description:
      'The foundational weapon in boxing. Deconstruct non-telegraphic shoulder snap, corkscrew thumb-down pronation, and the lightning recoil back to cheekbone.',
    pillars: ['Offense and Punch Mechanics', 'Conditioning and Movement'],
    difficulty: 'Fundamental',
    estimatedDurationMin: 30,
    prerequisiteLessonIds: ['les-04-01'],
    learningObjectives: [
      'Launch jab straight from the shoulder without flaring elbow or pulling hand back first.',
      'Rotate wrist 90 degrees so knuckles land flat with thumb slightly turned down.',
      'Elevate lead shoulder to guard chin at the moment of full extension.',
      'Snap hand back on the exact same trajectory line to reset guard.',
    ],
    mainExplanation:
      'The jab is the foundation of boxing offense. It establishes distance, blinds opponents, disrupts rhythm, sets up power punches, and keeps aggression at bay. A telegraphic jab—where you pull the hand back or flare the elbow outward before punching—gives opponents 200 milliseconds of free warning. The jab must fire straight out like a billiard cue and snap back immediately.',
    conceptualBreakdown: [
      {
        step: 'Shoulder Ignition & Path',
        explanation:
          'From your high guard, launch the lead fist forward in a straight laser line. Do not dip the hand or cock the shoulder backward.',
      },
      {
        step: 'Corkscrew Pronation at Impact',
        explanation:
          'As the arm approaches full extension, rotate the forearm so the knuckles turn horizontal. The lead shoulder rises automatically to shield the left side of your jaw.',
      },
      {
        step: 'Rear Hand Guard Lock',
        explanation:
          'While throwing the jab, the rear hand must remain glued to the right cheekbone. Never drop the opposite hand.',
      },
      {
        step: 'Elastic Recoil Protocol',
        explanation:
          'Imagine touching a hot stove. The instant the punch lands, whip the fist back along the exact same optical path.',
      },
    ],
    commonMistakes: [
      'Chicken-winging: flaring the elbow to the side before throwing, telegraphing the shot.',
      'Dropping the rear hand down to the chest while jabbing, leaving yourself wide open to a right cross.',
      'Hyperextending the elbow joint by violently locking it at full reach.',
      'Leaving the jab hanging in the air (admiring the shot) rather than snapping it back.',
    ],
    safetyConsiderations: [
      'Never hyperextend the elbow joint when shadowboxing into thin air. Keep a microscopic bend at peak reach.',
      'Always ensure wraps are worn if hitting mitts or light bag.',
    ],
    suggestedPractice:
      'Stand with your lead shoulder 2 inches from a wall. Throw 50 straight jabs. If your elbow hits the wall, your elbow is flaring outward.',
    knowledgeCheck: [
      {
        id: 'kc-05-01',
        question: 'What protective function does the lead shoulder perform when the jab is at maximum extension?',
        options: [
          'It shields the lead side of your chin from incoming counter right hands.',
          'It adds 20 pounds of dead weight to the punch.',
          'It blocks your own vision so you do not blink.',
          'It forces your rear hand to drop.',
        ],
        correctIndex: 0,
        explanation:
          'Elevating the lead shoulder tucks your chin into a natural skeletal helmet, protecting you against counter right crosses.',
      },
      {
        id: 'kc-05-02',
        question: 'What is meant by "telegraphing" a punch?',
        options: [
          'Using morse code with your footsteps.',
          'Giving away your intention before the punch launches through unnecessary preliminary movement like elbow flaring or pulling back.',
          'Throwing more than three punches in a row.',
          'Calling out punch numbers to your coach.',
        ],
        correctIndex: 1,
        explanation:
          'Telegraphing refers to any pre-motion tell—such as hitching the glove or flaring the elbow—that alerts the opponent a strike is coming.',
      },
    ],
    reflectionPrompt: 'Did you notice your rear hand dropping when you focused on snapping the jab? How can you keep the rear hand anchored?',
    completionCriteria: 'Pass both knowledge check questions and verify zero elbow flare.',
    xpReward: 250,
    relatedLessonIds: ['les-01-01', 'les-06-01', 'les-09-01'],
    relatedTechniqueIds: ['tech-piston-jab', 'tech-high-guard'],
  },

  // --- LEVEL 6 LESSONS ---
  {
    id: 'les-06-01',
    levelNumber: 6,
    phaseNumber: 2,
    title: 'The Rear Straight (Cross): Hip Torquing & Kinetic Chain',
    description:
      'Unlock devastating, non-telegraphic power through the rear foot pivot, pelvic rotation, thoracic torque, and locked wrist impact.',
    pillars: ['Offense and Punch Mechanics', 'Conditioning and Movement'],
    difficulty: 'Fundamental',
    estimatedDurationMin: 35,
    prerequisiteLessonIds: ['les-05-01'],
    learningObjectives: [
      'Pivot on the ball of the rear foot, elevating the rear heel 45 degrees.',
      'Rotate hips and torso as one unified cylinder.',
      'Deliver the right cross down the centerline with chin tucked behind the right shoulder.',
      'Keep lead hand glued to the left temple to protect against counter left hooks.',
    ],
    mainExplanation:
      'The rear cross is your primary power punch. True power does not come from your triceps or pectoral muscles; it is generated by the rear foot driving into the canvas, driving the rear hip forward, rotating the torso, and snapping through the fist. If your rear heel stays flat on the floor, your hip cannot rotate, reducing your punch power by over 60%.',
    conceptualBreakdown: [
      {
        step: 'Ground Ignition (Squash the Bug)',
        explanation:
          'Pivot forcefully on the ball of the rear foot. The rear heel points outward at roughly 45 degrees.',
      },
      {
        step: 'Pelvic and Thoracic Snap',
        explanation:
          'The rear hip whips forward until your belt buckle faces your target. The shoulders rotate through.',
      },
      {
        step: 'Straight Firing Line',
        explanation:
          'The right hand travels straight from the cheekbone down the center channel. Rear shoulder covers right jaw.',
      },
      {
        step: 'Lead Hand Guard Vigilance',
        explanation:
          'The left glove must remain glued to your left cheek. A dropped lead hand during a cross invites a knockout left hook.',
      },
    ],
    commonMistakes: [
      'Leaving the rear heel glued flat to the canvas, preventing hip rotation.',
      'Leaning the torso over the front knee, compromising balance and walking into uppercuts.',
      'Dropping the lead hand while firing the cross.',
      'Looping the cross like a wide baseball throw instead of firing a laser straight.',
    ],
    safetyConsiderations: [
      'Never allow the front knee to collapse inward or buckle over the front toes.',
      'Wrap hands thoroughly before hitting heavy bags with the cross to avoid wrist sprains.',
    ],
    suggestedPractice:
      '4 Rounds on the heavy bag: 2 rounds slow-motion checking heel pivot and hip rotation; 2 rounds snapping crosses with high lead guard.',
    knowledgeCheck: [
      {
        id: 'kc-06-01',
        question: 'Where does the primary kinetic energy of the rear straight cross originate?',
        options: [
          'From the triceps muscle pressing forward.',
          'From ground reaction force generated by the rear foot pivoting and driving the hip forward.',
          'From lunging your head and chest forward over your front knee.',
          'From flexing your fingers inside the glove.',
        ],
        correctIndex: 1,
        explanation:
          'Power originates from the floor through ankle drive and hip torque, transferring upward through the core to the fist.',
      },
    ],
    reflectionPrompt: 'Do you feel your weight stay centered between your feet during the cross, or are you falling forward onto your lead leg?',
    completionCriteria: 'Score 100% on the cross mechanics quiz and confirm balanced recoil.',
    xpReward: 250,
    relatedLessonIds: ['les-05-01', 'les-09-01'],
    relatedTechniqueIds: ['tech-rear-cross', 'tech-piston-jab'],
  },

  // --- LEVEL 7 LESSONS ---
  {
    id: 'les-07-01',
    levelNumber: 7,
    phaseNumber: 2,
    title: 'Lead & Rear Hooks: Rotational Axis Mastery',
    description:
      'Master the horizontal lever. Torque around your spine without winding up or dropping hands.',
    pillars: ['Offense and Punch Mechanics'],
    difficulty: 'Fundamental',
    estimatedDurationMin: 30,
    prerequisiteLessonIds: ['les-06-01'],
    learningObjectives: [
      'Pivot lead foot and hips simultaneously to swing the lead hook around the guard.',
      'Keep elbow, wrist, and shoulder locked in the same horizontal plane (90-degree bend).',
      'Choose horizontal vs. vertical thumb orientation depending on range.',
    ],
    mainExplanation:
      'The hook is a rotational strike that attacks an opponent’s flank or jaw around their guard. Rather than swinging the arm using the shoulder joint alone, your entire torso rotates around the spinal axis like a revolving door. The arm stays locked in an L-shape at roughly 90 degrees.',
    conceptualBreakdown: [
      {
        step: 'Weight Shift & Pivot',
        explanation: 'Shift weight slightly to the lead side, then pivot on the lead ball of foot, turning hips.',
      },
      {
        step: 'Horizontal Lever Lock',
        explanation: 'Elbow rises level with fist. Do not let the elbow sag below the wrist.',
      },
      {
        step: 'Stopping at the Centerline',
        explanation: 'Do not over-rotate past the center line. Punch through the target by 2 inches and stop.',
      },
    ],
    commonMistakes: [
      'Winding up by pulling the glove backward before throwing, telegraphing the hook.',
      'Dropping the elbow below the fist, turning the hook into an arm swing with zero torque.',
      'Dropping the rear hand while throwing the lead hook.',
    ],
    safetyConsiderations: [
      'Maintain rigid wrist alignment to prevent hyperflexion upon bag impact.',
      'Never throw full-power hooks on a rock-hard heavy bag without proper 16oz gloves and wraps.',
    ],
    suggestedPractice: '50 Reps lead hook shadowboxing holding a foam pad or towel under your arm to verify 90-degree lock.',
    knowledgeCheck: [
      {
        id: 'kc-07-01',
        question: 'What is the biomechanical danger of letting your elbow sag below your wrist during a hook?',
        options: [
          'It dissipates kinetic torque and risks severe sprain to the wrist joint on impact.',
          'It makes the punch land too hard.',
          'It makes your rear hand rise too high.',
          'It causes your shoes to slip.',
        ],
        correctIndex: 0,
        explanation:
          'When the elbow sags, the strike becomes an off-axis blow that places destructive shearing forces on the wrist ligaments.',
      },
    ],
    reflectionPrompt: 'Does your rear hand stay tight to your cheekbone while your torso turns for the lead hook?',
    completionCriteria: 'Pass the quiz and log 50 shadowboxing reps.',
    xpReward: 250,
    relatedLessonIds: ['les-05-01', 'les-06-01'],
    relatedTechniqueIds: ['tech-lead-hook'],
  },

  // --- LEVEL 8 LESSONS ---
  {
    id: 'les-08-01',
    levelNumber: 8,
    phaseNumber: 2,
    title: 'The Rising Uppercut & Close Range Mechanics',
    description:
      'The vertical elevator punch. Drive power from bent knees upward through the opponent’s guard.',
    pillars: ['Offense and Punch Mechanics'],
    difficulty: 'Fundamental',
    estimatedDurationMin: 25,
    prerequisiteLessonIds: ['les-07-01'],
    learningObjectives: [
      'Dip knees slightly and drive upward through the legs rather than pulling with the arm.',
      'Keep punching palm facing toward your own chest at 90 degrees.',
      'Never drop the hand below belt level before firing.',
    ],
    mainExplanation:
      'The uppercut splits the guard of an opponent who ducks or leans forward. A common novice mistake is pulling the hand down to the waist to build momentum. In reality, the uppercut is generated by a slight knee dip followed by explosive upward leg extension.',
    conceptualBreakdown: [
      {
        step: 'Micro Knee Dip',
        explanation: 'Dip hips and knees 2-3 inches to load the quadriceps and glutes.',
      },
      {
        step: 'Vertical Drive',
        explanation: 'Drive upward through the floor, turning the palm toward your face with a tight 90-degree elbow bend.',
      },
      {
        step: 'Short Compact Arc',
        explanation: 'Travel no more than 12-18 inches vertically. Do not swing toward the ceiling.',
      },
    ],
    commonMistakes: [
      'Dropping hand down to waist level before launching, leaving your face completely unguarded.',
      'Swinging arm wide like a bowling ball instead of driving upward in a compact line.',
    ],
    safetyConsiderations: [
      'Never hyperextend your lower back when driving upward.',
      'Keep non-punching hand locked to your jaw.',
    ],
    suggestedPractice: '30 Reps rear uppercut, 30 reps lead uppercut on wall pad or in mirror with strict guard.',
    knowledgeCheck: [
      {
        id: 'kc-08-01',
        question: 'Why is dropping your hand down to your waist before an uppercut considered a critical error?',
        options: [
          'It leaves your entire chin completely exposed to hooks and straight counters.',
          'It makes the punch too fast.',
          'It violates amateur boxing rules.',
          'It makes your shoulder too big.',
        ],
        correctIndex: 0,
        explanation:
          'Dropping your hand removes your defensive shield, leaving your jaw completely unguarded during the entire wind-up.',
      },
    ],
    reflectionPrompt: 'Did you feel the power come from your legs driving upward, or were you trying to pull the punch with your bicep?',
    completionCriteria: 'Pass the quiz and demonstrate compact vertical stroke.',
    xpReward: 250,
    relatedLessonIds: ['les-07-01', 'les-09-01'],
    relatedTechniqueIds: ['tech-rear-uppercut'],
  },

  // --- LEVEL 9 LESSONS ---
  {
    id: 'les-09-01',
    levelNumber: 9,
    phaseNumber: 2,
    title: 'The 1-2 & Defensive Integration: Slip & Parry',
    description:
      'Synthesize fundamental striking and defense: throw the 1-2 combination and immediately slip off the centerline.',
    pillars: ['Offense and Punch Mechanics', 'Defense and Awareness'],
    difficulty: 'Fundamental',
    estimatedDurationMin: 35,
    prerequisiteLessonIds: ['les-05-01', 'les-06-01', 'les-07-01', 'les-08-01'],
    learningObjectives: [
      'Deliver fluid 1-2 combination without hesitation between strikes.',
      'Immediately slip lead or rear after the cross finishes.',
      'Parry incoming straight punch with rear palm deflection.',
    ],
    mainExplanation:
      'Never admire your work. The moment your cross lands, you are in the opponent’s counter window. Fluidly slipping off the centerline or parrying their return jab guarantees safety.',
    conceptualBreakdown: [
      {
        step: 'The 1-2 Cadence',
        explanation: 'Jab fires and recalls; cross launches as jab recoils halfway. Two distinct cracks, not pushed.',
      },
      {
        step: 'The Exit Slip',
        explanation: 'Bend at knees and hips to move head 3-4 inches off the centerline, letting counter punch fly past.',
      },
      {
        step: 'The Rear Parry',
        explanation: 'Flick rear palm 2 inches forward to tap opponent’s incoming jab across their body.',
      },
    ],
    commonMistakes: [
      'Standing upright and frozen after throwing the 1-2.',
      'Reaching forward with both hands to parry, exposing chin.',
    ],
    safetyConsiderations: [
      'In partner drilling, maintain zero-contact or controlled touch to shoulders only.',
      'Wear mouthguard whenever drilling with partners.',
    ],
    suggestedPractice: '5 Rounds shadowboxing: Jab, Cross, Slip outside, Reset guard.',
    knowledgeCheck: [
      {
        id: 'kc-09-01',
        question: 'What is the most vulnerable moment for a fighter during a combination?',
        options: [
          'Before the combination begins.',
          'Immediately after finishing the final punch, if they stand still on the centerline admiring their work.',
          'While in a neutral high guard.',
          'When stepping backward.',
        ],
        correctIndex: 1,
        explanation:
          'After throwing a combination, opponents will reflexively counter. Standing still on the centerline makes you an easy stationary target.',
      },
    ],
    reflectionPrompt: 'Can you slip smoothly without bending forward at the waist?',
    completionCriteria: 'Pass Phase II synthesis check.',
    xpReward: 350,
    relatedLessonIds: ['les-05-01', 'les-06-01', 'les-10-01'],
    relatedTechniqueIds: ['tech-one-two', 'tech-slip-outside', 'tech-rear-parry'],
  },

  // --- LEVEL 10 LESSONS ---
  {
    id: 'les-10-01',
    levelNumber: 10,
    phaseNumber: 3,
    title: 'Combination Structure & Punch Sequencing',
    description:
      'Construct high-low combinations (1-2-3b, 1-3-2) that alternate targets and exploit defensive reactions.',
    pillars: ['Offense and Punch Mechanics', 'Tactics and Boxing IQ'],
    difficulty: 'Intermediate',
    estimatedDurationMin: 35,
    prerequisiteLessonIds: ['les-09-01'],
    learningObjectives: [
      'Sequence punches that naturally transfer weight from side to side.',
      'Convert between head and body levels without losing guard balance.',
      'Vary tempo between probing setup shots and committed power strikes.',
    ],
    mainExplanation:
      'Effective combinations are not random flurries. They exploit the natural weight transfer of the human kinetic chain: left punch loads right hip; right punch loads left hip. Changing elevation from head to body forces the opponent’s guard to separate, creating clean openings.',
    conceptualBreakdown: [
      {
        step: 'Kinetic Weight Recycling',
        explanation: 'Use the recoil of the jab to cock the cross; use the recoil of the cross to load the lead hook.',
      },
      {
        step: 'Head-to-Body Level Shift',
        explanation: 'Drop hips on the 1-2 to drive a shovel hook into the floating ribs.',
      },
      {
        step: 'Rhythm Modulation',
        explanation: 'Light, fast touch jab followed by a thunderous cross.',
      },
    ],
    commonMistakes: [
      'Throwing three punches of the exact same speed and power, making cadence predictable.',
      'Bending at the waist to hit the body instead of dropping the hips and knees.',
    ],
    safetyConsiderations: ['Ensure wrists remain rigid when transitioning angles on the heavy bag.'],
    suggestedPractice: '4 Rounds heavy bag practicing 1-2-3 to the head and 1-2-3b to the body.',
    knowledgeCheck: [
      {
        id: 'kc-10-01',
        question: 'Why should you drop your hips/knees rather than bending your waist when throwing body punches?',
        options: [
          'Bending at the waist tilts your head forward into counter uppercuts and compromises your base.',
          'Bending the waist is illegal in boxing.',
          'Dropping hips makes you punch slower.',
          'It is purely aesthetic.',
        ],
        correctIndex: 0,
        explanation:
          'Bending at the waist tilts your unprotected skull forward into opponent uppercuts and destroys your balance.',
      },
    ],
    reflectionPrompt: 'Did you notice a clean weight transfer when alternating left and right strikes?',
    completionCriteria: 'Pass quiz and demonstrate high-low combination flow.',
    xpReward: 300,
    relatedLessonIds: ['les-09-01', 'les-11-01'],
    relatedTechniqueIds: ['tech-combination-matrix', 'tech-body-jab'],
  },

  // --- LEVEL 11 LESSONS ---
  {
    id: 'les-11-01',
    levelNumber: 11,
    phaseNumber: 3,
    title: 'Defense After Attacking & Catch-and-Pitch Counters',
    description:
      'Master the defensive reaction loop: block or catch an incoming punch and fire your counter before the opponent resets.',
    pillars: ['Defense and Awareness', 'Tactics and Boxing IQ'],
    difficulty: 'Intermediate',
    estimatedDurationMin: 35,
    prerequisiteLessonIds: ['les-10-01'],
    learningObjectives: [
      'Execute the catch-and-shoot rear cross off an opponent’s jab.',
      'Roll under incoming hooks and rise with a counter shovel hook.',
      'Establish a subconscious defensive exit protocol.',
    ],
    mainExplanation:
      'The catch-and-pitch is the quintessential counter-puncher weapon. By catching an opponent’s jab on your rear palm like a catcher’s mitt, their punch is neutralized while their lead shoulder is extended, leaving their chin open for your instantaneous return cross.',
    conceptualBreakdown: [
      {
        step: 'The Catch',
        explanation: 'Open rear glove slightly at cheek level. Absorb opponent’s jab with minimal forward motion.',
      },
      {
        step: 'The Pitch',
        explanation: 'Immediately explode through the ball of the rear foot, launching return cross over their jab arm.',
      },
      {
        step: 'Exit Roll',
        explanation: 'Weave in a U-shape under any follow-up hook.',
      },
    ],
    commonMistakes: [
      'Reaching both hands out to catch a punch, leaving face exposed.',
      'Waiting a full second after catching before firing, losing the counter window.',
    ],
    safetyConsiderations: ['Do not slap hard at incoming gloves; catch softly at the cheek.'],
    suggestedPractice: 'Partner or mirror drills: 50 catch-and-pitch reps focusing on zero delay.',
    knowledgeCheck: [
      {
        id: 'kc-11-01',
        question: 'When performing a catch-and-shoot against a jab, how far forward should your rear hand move to catch?',
        options: [
          'Full arm extension into their face.',
          'No more than 1 to 2 inches in front of your cheek.',
          'Down to your hip.',
          'Behind your neck.',
        ],
        correctIndex: 1,
        explanation:
          'Reaching forward exposes you to feints and hooks. The glove stays right by the cheek to catch like a firm mitt.',
      },
    ],
    reflectionPrompt: 'How fast was your trigger after feeling impact on your palm?',
    completionCriteria: 'Pass quiz and demonstrate immediate counter trigger.',
    xpReward: 300,
    relatedLessonIds: ['les-10-01', 'les-12-01'],
    relatedTechniqueIds: ['tech-catch-and-pitch', 'tech-slip-outside'],
  },

  // --- LEVEL 12 LESSONS ---
  {
    id: 'les-12-01',
    levelNumber: 12,
    phaseNumber: 3,
    title: 'Lateral Pivots & Angles: The 45° & The L-Step',
    description:
      'Step off the linear railroad tracks. Create dominant angles where you can strike while the opponent must turn to face you.',
    pillars: ['Conditioning and Movement', 'Tactics and Boxing IQ'],
    difficulty: 'Intermediate',
    estimatedDurationMin: 35,
    prerequisiteLessonIds: ['les-11-01'],
    learningObjectives: [
      'Plant lead foot and pivot rear foot 45 degrees to flank opponent.',
      'Execute the L-step to create distance from a charging forward opponent.',
      'Fire combinations from the dominant T-position angle.',
    ],
    mainExplanation:
      'Fights are won in the angles. When two fighters stand directly facing each other, they possess equal offensive access. By pivoting 45 degrees around the opponent’s lead foot, you enter their blind spot. You can hit them with both hands while they must pause, re-center their base, and turn to face you.',
    conceptualBreakdown: [
      {
        step: 'The Lead Foot Pivot',
        explanation: 'Throw a jab or slip lead. Plant the ball of lead foot, swing rear foot 45 degrees laterally.',
      },
      {
        step: 'The L-Step Cutback',
        explanation: 'Step rear foot back, then shift lead foot laterally to exit perpendicular to the charging line.',
      },
      {
        step: 'The T-Position Strike',
        explanation: 'Unleash cross or hook while opponent is still facing your previous position.',
      },
    ],
    commonMistakes: [
      'Pivoting on the heel instead of the ball of the foot, causing balance loss.',
      'Dropping hands during the pivot.',
    ],
    safetyConsiderations: ['Ensure floor has adequate traction so pivoting foot does not slide dangerously.'],
    suggestedPractice: 'Cone drill: 4 cones in diamond; pivot at each corner holding guard and throwing 2 strikes.',
    knowledgeCheck: [
      {
        id: 'kc-12-01',
        question: 'What is the primary tactical advantage of achieving a 45-degree angle (T-position) relative to an opponent?',
        options: [
          'You can hit them while they cannot hit you without turning their feet to re-align.',
          'It makes the round end faster.',
          'It allows you to rest your arms.',
          'It forces the referee to intervene.',
        ],
        correctIndex: 0,
        explanation:
          'From the angle, your weapons are lined up with their centerline while their weapons are facing empty space.',
      },
    ],
    reflectionPrompt: 'Are you staying balanced on the ball of your lead foot throughout the entire pivot?',
    completionCriteria: 'Pass quiz and demonstrate clean 45-degree pivot on camera or mirror.',
    xpReward: 350,
    relatedLessonIds: ['les-11-01', 'les-13-01'],
    relatedTechniqueIds: ['tech-45-pivot', 'tech-l-step'],
  },

  // --- LEVEL 13 LESSONS ---
  {
    id: 'les-13-01',
    levelNumber: 13,
    phaseNumber: 3,
    title: 'The Art of the Feint & Distance Management',
    description:
      'Use half-steps, shoulder twitches, and glove flickers to bait defensive reactions without expending energy.',
    pillars: ['Tactics and Boxing IQ', 'Offense and Punch Mechanics'],
    difficulty: 'Intermediate',
    estimatedDurationMin: 30,
    prerequisiteLessonIds: ['les-12-01'],
    learningObjectives: [
      'Execute subtle shoulder and eye feints to draw parries and high guards.',
      'Control the critical distance zone (half-inch inside vs half-inch outside range).',
      'Capitalize immediately when an opponent bites on a feint.',
    ],
    mainExplanation:
      'A feint is a question asked with the body that demands an immediate answer from the opponent. If you twitch your lead shoulder and the opponent flinches their rear parry hand outward, you have discovered an opening. The next time you feint, you launch the hook around their compromised guard.',
    conceptualBreakdown: [
      {
        step: 'The Micro-Twitch',
        explanation: 'Flick lead shoulder and step forward 2 inches without committing the fist.',
      },
      {
        step: 'Reading the Reaction',
        explanation: 'Did they blink, raise their guard, step back, or attempt a counter?',
      },
      {
        step: 'The Exploitation Strike',
        explanation: 'If they guard high, dig to the body. If they drop hands, fire down the pipe.',
      },
    ],
    commonMistakes: [
      'Exaggerating feints so widely that you throw yourself off balance.',
      'Feinting without intent to attack when an opening appears.',
    ],
    safetyConsiderations: ['Maintain strict stance balance during feints; never lunge head forward.'],
    suggestedPractice: '3 Rounds shadowboxing: feint before every combination; observe your imaginary opponent’s reaction.',
    knowledgeCheck: [
      {
        id: 'kc-13-01',
        question: 'What is the primary objective of a feint in boxing?',
        options: [
          'To show off athletic agility.',
          'To force the opponent to react defensively and reveal openings without you taking physical risk.',
          'To stall the timer when tired.',
          'To confuse the ringside judges.',
        ],
        correctIndex: 1,
        explanation:
          'Feints trigger premature defensive reactions from the opponent, creating predictable openings for your real attack.',
      },
    ],
    reflectionPrompt: 'Notice whether your feints feel crisp or clumsy. How can you make them look identical to real punches?',
    completionCriteria: 'Pass quiz and demonstrate 3 distinct feint variations.',
    xpReward: 350,
    relatedLessonIds: ['les-12-01', 'les-14-01'],
    relatedTechniqueIds: ['tech-lead-feint', 'tech-distance-management'],
  },

  // --- LEVEL 14 LESSONS ---
  {
    id: 'les-14-01',
    levelNumber: 14,
    phaseNumber: 3,
    title: 'Technical Error Recognition & Film Study Fundamentals',
    description:
      'Learn how to review training footage, audit flared elbows and balance leaks, and deconstruct opponent habits.',
    pillars: ['Tactics and Boxing IQ', 'Recovery and Reflection'],
    difficulty: 'Intermediate',
    estimatedDurationMin: 40,
    prerequisiteLessonIds: ['les-13-01'],
    learningObjectives: [
      'Perform a 5-point biomechanical audit on recorded shadowboxing.',
      'Identify subtle balance leaks, rear heel drop, and chin elevation.',
      'Catalog recurring opponent patterns during video study.',
    ],
    mainExplanation:
      'Championship pugilists are dedicated students of the craft. Feeling your movement from the inside is often deceptive; the camera never lies. By recording your rounds and reviewing them against strict biomechanical checklists, you eliminate subconscious technical leaks before they become ingrained habits.',
    conceptualBreakdown: [
      {
        step: 'Footwork Base Audit',
        explanation: 'Freeze frame on every landing: are feet shoulder-width? Is the rear heel off the floor?',
      },
      {
        step: 'Guard Retraction Line',
        explanation: 'Does the punching hand return directly to the chin, or does it dip down toward the chest?',
      },
      {
        step: 'Head Position on Impact',
        explanation: 'Is the chin tucked? Is the head off the centerline during power shots?',
      },
    ],
    commonMistakes: [
      'Only watching highlight knockouts instead of studying subtle footwork and setup mechanics.',
      'Refusing to record yourself out of embarrassment.',
    ],
    safetyConsiderations: ['Use film analysis to identify dangerous mechanical strains before injury occurs.'],
    suggestedPractice: 'Record a 2-minute round of shadowboxing. Watch it twice and write down 3 specific corrections.',
    knowledgeCheck: [
      {
        id: 'kc-14-01',
        question: 'When auditing your jab on recorded video, what should the return path of the hand look like?',
        options: [
          'It should dip down to waist level to rest the shoulder.',
          'It should trace the exact same straight line back to the cheekbone without dipping.',
          'It should swing wide in an arc.',
          'It should drop to the thigh.',
        ],
        correctIndex: 1,
        explanation:
          'Dipping the hand on recoil leaves you wide open to counter crosses. The return must be as direct as the launch.',
      },
    ],
    reflectionPrompt: 'What was the biggest difference between how your movement felt and how it looked on video?',
    completionCriteria: 'Submit self-audit reflection and pass film study check.',
    xpReward: 400,
    relatedLessonIds: ['les-13-01', 'les-15-01'],
    relatedTechniqueIds: ['tech-film-audit-matrix'],
  },

  // --- LEVEL 15 LESSONS ---
  {
    id: 'les-15-01',
    levelNumber: 15,
    phaseNumber: 4,
    title: 'Advanced Defensive Transitions & Shell Positioning',
    description:
      'Flow between high guard, forearm framing, elbow blocks, and the shoulder roll in high-intensity exchanges.',
    pillars: ['Defense and Awareness', 'Technical Practice and Equipment Safety'],
    difficulty: 'Advanced',
    estimatedDurationMin: 40,
    prerequisiteLessonIds: ['les-14-01'],
    learningObjectives: [
      'Seamlessly transition between tight pyramid guard and forearm frames.',
      'Catch body shots with elbow clamps without dropping hands from face.',
      'Preserve panoramic pocket awareness while under pressure.',
    ],
    mainExplanation:
      'At advanced levels, one defensive layer is never enough. Opponents throw deceptive three- and four-punch combinations designed to peel away simple guards. You must possess dynamic, multi-layered defensive transitions: absorbing a straight on the gloves, sliding into a forearm wedge, and rolling under the follow-up hook.',
    conceptualBreakdown: [
      {
        step: 'The Forearm Wedge',
        explanation: 'Extend lead forearm across opponent’s chest to control posture and disrupt their punch arc.',
      },
      {
        step: 'The Elbow Clamp',
        explanation: 'Lower the elbow 2 inches to block body hooks with the tricep while hands stay glued to jaw.',
      },
      {
        step: 'Defensive Disengagement',
        explanation: 'Frame, take a micro half-step back, and immediately counter.',
      },
    ],
    commonMistakes: [
      'Dropping the hand down to parry a body punch, leaving the head wide open.',
      'Closing eyes when receiving fire against the guard.',
    ],
    safetyConsiderations: ['Do not allow heavy punches to bend wrists backward while framing.'],
    suggestedPractice: '4 Rounds defense-only shadowboxing against imaginary flurries, cycling between high guard and frames.',
    knowledgeCheck: [
      {
        id: 'kc-15-01',
        question: 'How should you defend against an incoming left hook to the body (liver shot)?',
        options: [
          'Drop your right glove down to block it with your hand.',
          'Clamp your right elbow firmly against your ribs while keeping the glove anchored to your jaw.',
          'Jump backward in the air.',
          'Lean forward and take it on the chest.',
        ],
        correctIndex: 1,
        explanation:
          'Dropping the glove exposes your head to a feint-hook upstairs. Clamping the elbow shields the liver while protecting the jaw.',
      },
    ],
    reflectionPrompt: 'Can you keep your eyes wide open and focused on the opponent’s chest while punches glance off your forearms?',
    completionCriteria: 'Pass quiz and demonstrate 3-layer defensive transition.',
    xpReward: 400,
    relatedLessonIds: ['les-14-01', 'les-16-01'],
    relatedTechniqueIds: ['tech-forearm-frame', 'tech-high-guard'],
  },

  // --- LEVEL 16 LESSONS ---
  {
    id: 'les-16-01',
    levelNumber: 16,
    phaseNumber: 4,
    title: 'The Pull Counter & The Slip-Jolt',
    description:
      'The surgical art of counterpunching: millimeter head retraction to make opponent miss by an inch, followed by an immediate cross.',
    pillars: ['Tactics and Boxing IQ', 'Offense and Punch Mechanics'],
    difficulty: 'Advanced',
    estimatedDurationMin: 40,
    prerequisiteLessonIds: ['les-15-01'],
    learningObjectives: [
      'Retract head 2 inches backward using rear knee compression without losing balance.',
      'Load 80% weight onto rear leg and spring forward with a blistering counter cross.',
      'Time the counter within the dead space of the opponent’s punch extension.',
    ],
    mainExplanation:
      'The pull counter is celebrated as one of the most aesthetically brilliant and devastating weapons in the sweet science. You bait the opponent’s jab, lean your head back just enough for the glove to brush past your nose, and explode forward with a right cross over their extended arm.',
    conceptualBreakdown: [
      {
        step: 'The Bait',
        explanation: 'Hold head slightly forward on the centerline to invite the opponent’s jab.',
      },
      {
        step: 'The Millimeter Pull',
        explanation: 'Flex rear knee to shift torso back 2-3 inches. The punch misses your chin by a fraction of an inch.',
      },
      {
        step: 'The Spring-Loaded Cross',
        explanation: 'Uncoil the rear quad and launch your right hand over their outstretched arm.',
      },
    ],
    commonMistakes: [
      'Leaning too far back on a straight rear leg, losing all counter power and balance.',
      'Pulling back with chin up in the air.',
    ],
    safetyConsiderations: ['Never perform pull counters without bent rear knee; hyperextension risks serious fall.'],
    suggestedPractice: '50 Reps pull counter on slip bag or mirror with zero backward over-extension.',
    knowledgeCheck: [
      {
        id: 'kc-16-01',
        question: 'What is the critical mechanical requirement of the rear leg during a pull counter?',
        options: [
          'The rear knee must stay soft and bent to load explosive spring power, never locked straight.',
          'The rear foot must jump off the floor.',
          'The rear heel must touch the front foot.',
          'The rear knee should lock backward.',
        ],
        correctIndex: 0,
        explanation:
          'A bent rear knee acts as a loaded spring. Locking the leg causes you to fall over backward and destroys counter torque.',
      },
    ],
    reflectionPrompt: 'Are you pulling back just enough to clear the punch, or are you retreating half a foot too far?',
    completionCriteria: 'Pass quiz and demonstrate balanced pull counter with instant recoil.',
    xpReward: 450,
    relatedLessonIds: ['les-15-01', 'les-17-01'],
    relatedTechniqueIds: ['tech-pull-counter', 'tech-rear-cross'],
  },

  // --- LEVEL 17 LESSONS ---
  {
    id: 'les-17-01',
    levelNumber: 17,
    phaseNumber: 4,
    title: 'Ring-Cutting Theory & Perimeter Containment',
    description:
      'Stop chasing runners. Master geometric lateral containment to herd opponents toward the ropes and corners.',
    pillars: ['Conditioning and Movement', 'Tactics and Boxing IQ'],
    difficulty: 'Advanced',
    estimatedDurationMin: 40,
    prerequisiteLessonIds: ['les-16-01'],
    learningObjectives: [
      'Step along the diagonal chord of the ring rather than following the opponent in a circle.',
      'Cut off exit routes with lateral shuffle steps and active lead hand probes.',
      'Trap opponent against the ropes and enforce infighting pressure.',
    ],
    mainExplanation:
      'Novices chase elusive out-boxers in a circle, burning cardiovascular reserves while getting picked apart. Advanced tacticians cut the ring off geometrically. By taking short lateral steps along the diameter, you travel 10 feet while the opponent must run 20 feet around the perimeter, eventually herding them into the corner.',
    conceptualBreakdown: [
      {
        step: 'Diagonal Stepping',
        explanation: 'Step along the inner chords to intercept where the runner is going, not where they are.',
      },
      {
        step: 'Extending the Fence',
        explanation: 'Use lead jab and rear hand parries to block their lateral escapes.',
      },
      {
        step: 'Corner Lockdown',
        explanation: 'Once opponent reaches the corner pads, widen base and unleash body attack.',
      },
    ],
    commonMistakes: [
      'Following directly behind the runner, letting them dictate ring geography.',
      'Rushing forward blindly and getting clipped by check hooks.',
    ],
    safetyConsiderations: ['Maintain tight guard while closing distance; runners will throw desperate counter flurries.'],
    suggestedPractice: 'Perimeter ring cutting drill: navigate a 16-foot grid, closing off lateral exits.',
    knowledgeCheck: [
      {
        id: 'kc-17-01',
        question: 'What is the fundamental rule of ring-cutting against an elusive mover?',
        options: [
          'Run as fast as you can directly behind their shoes.',
          'Cut the ring along the diagonals to intercept their path, forcing them toward the ropes.',
          'Wait in your own corner until they get bored.',
          'Throw only lead hooks.',
        ],
        correctIndex: 1,
        explanation:
          'Taking the shorter inner path intercepts their circular retreat and corners them without wasting energy.',
      },
    ],
    reflectionPrompt: 'How disciplined are you when an opponent retreats? Do you sprint or do you cut the angles?',
    completionCriteria: 'Pass quiz and demonstrate geometric ring containment.',
    xpReward: 450,
    relatedLessonIds: ['les-16-01', 'les-18-01'],
    relatedTechniqueIds: ['tech-ring-cutting', 'tech-lateral-shuffle'],
  },

  // --- LEVEL 18 LESSONS ---
  {
    id: 'les-18-01',
    levelNumber: 18,
    phaseNumber: 4,
    title: 'Body Snatching: Tactical Liver & Spleen Warfare',
    description:
      'Lower opponent guards and drain systemic conditioning using 45-degree shovel hooks and solar plexus straights.',
    pillars: ['Offense and Punch Mechanics', 'Tactics and Boxing IQ'],
    difficulty: 'Advanced',
    estimatedDurationMin: 40,
    prerequisiteLessonIds: ['les-17-01'],
    learningObjectives: [
      'Land the 45-degree shovel hook beneath the floating ribs directly to the liver.',
      'Level change with hip flexion, not spinal bending.',
      'Disguise body assault behind high jab feints.',
    ],
    mainExplanation:
      'Headshots stun, but body punches take the will to fight. A clean strike to the hepatic capsule (the liver) triggers an involuntary autonomic nervous system reaction, dropping blood pressure and paralyzing the legs. Throwing to the body requires precise level changes and an angled shovel trajectory.',
    conceptualBreakdown: [
      {
        step: 'The High Feint Setup',
        explanation: 'Throw a high jab to force opponent’s gloves up over their eyes.',
      },
      {
        step: 'The Hip Level Change',
        explanation: 'Drop hips 4 inches, tilting torso slightly to the left.',
      },
      {
        step: 'The 45° Shovel Drive',
        explanation: 'Punch upward at a 45-degree angle beneath the ribs with palm facing upward-inward.',
      },
    ],
    commonMistakes: [
      'Punching flat against the side of the hip instead of angled upward beneath the rib cage.',
      'Dropping the right hand while digging the left hook to the body.',
    ],
    safetyConsiderations: [
      'In partner sparring, body shots must be strictly controlled; liver impacts can cause organ trauma.',
      'Wear certified body protector when taking live reps.',
    ],
    suggestedPractice: '4 Rounds heavy bag focusing strictly on jab upstairs, shovel hook downstairs.',
    knowledgeCheck: [
      {
        id: 'kc-18-01',
        question: 'Where is the human liver anatomically located and what punch targets it most effectively?',
        options: [
          'On the right side of the opponent’s torso (your left); targeted by the lead shovel hook.',
          'Directly in the center of the throat; targeted by the straight jab.',
          'On the left side of the opponent’s torso; targeted by the right cross.',
          'Behind the shoulder blade; targeted by the overhand.',
        ],
        correctIndex: 0,
        explanation:
          'The liver sits under the right lower ribs (your left as orthodox). Your lead hook or shovel hook strikes directly into it.',
      },
    ],
    reflectionPrompt: 'Did you feel the difference in leverage when striking upward at 45 degrees versus horizontal?',
    completionCriteria: 'Pass quiz and log heavy body-bag round.',
    xpReward: 450,
    relatedLessonIds: ['les-17-01', 'les-19-01'],
    relatedTechniqueIds: ['tech-shovel-hook', 'tech-body-jab'],
  },

  // --- LEVEL 19 LESSONS ---
  {
    id: 'les-19-01',
    levelNumber: 19,
    phaseNumber: 4,
    title: 'Professional Bout Deconstruction & Style Archetypes',
    description:
      'Forensic analysis of the 5 archetypes: Out-Boxer, Swarmer, Slugger, Boxer-Puncher, and Counter-Puncher.',
    pillars: ['Tactics and Boxing IQ', 'Recovery and Reflection'],
    difficulty: 'Advanced',
    estimatedDurationMin: 45,
    prerequisiteLessonIds: ['les-18-01'],
    learningObjectives: [
      'Identify tactical vulnerabilities of each major boxing archetype.',
      'Deconstruct historic championship footage to map strategic adjustments.',
      'Formulate tactical fight plans for style clash scenarios.',
    ],
    mainExplanation:
      'Styles make fights. A swarmer overwhelms an out-boxer with relentless inside pressure; a slugger knocks out a swarmer with devastating counter uppercuts; an out-boxer frustrates a slugger with lateral footwork and jabs. Understanding the rock-paper-scissors geometry of pugilism allows you to adapt mid-fight.',
    conceptualBreakdown: [
      {
        step: 'The Swarmer Formula',
        explanation: 'Relentless forward pressure, head movement, body assault. Countered by pivots, jabs, and uppercuts.',
      },
      {
        step: 'The Out-Boxer Formula',
        explanation: 'Distance, speed, ring perimeter. Countered by ring-cutting, body shots, and feints.',
      },
      {
        step: 'The Counter-Puncher Formula',
        explanation: 'Traps, baits, precision. Countered by feints, broken rhythm, and active volume.',
      },
    ],
    commonMistakes: [
      'Trying to slug with a slugger or out-run an Olympic out-boxer.',
      'Failing to adapt when an opponent changes styles mid-fight.',
    ],
    safetyConsiderations: ['Use tactical study to reduce unnecessary physical wear and tear in the ring.'],
    suggestedPractice: 'Watch a championship bout and create a written dossier mapping both fighters’ archetypes and adjustments.',
    knowledgeCheck: [
      {
        id: 'kc-19-01',
        question: 'What is the most effective tactical antidote to a swarming infighter who charges relentlessly forward?',
        options: [
          'Standing completely flat-footed on the ropes and exchanging wild swings.',
          'Lateral pivots (45° and L-steps), stiff jabs, and compact rising uppercuts.',
          'Closing your eyes and holding your breath.',
          'Backing up in a straight line.',
        ],
        correctIndex: 1,
        explanation:
          'Pivoting takes you off their forward charging vector, while jabs and compact uppercuts punish their forward momentum.',
      },
    ],
    reflectionPrompt: 'What is your natural stylistic archetype, and what style gives you the greatest technical difficulty?',
    completionCriteria: 'Pass quiz and submit archetype study notes.',
    xpReward: 500,
    relatedLessonIds: ['les-18-01', 'les-20-01'],
    relatedTechniqueIds: ['tech-archetype-dossier'],
  },

  // --- LEVEL 20 LESSONS ---
  {
    id: 'les-20-01',
    levelNumber: 20,
    phaseNumber: 5,
    title: 'Creating a Personal Technical Study Plan',
    description:
      'Design an individualized, periodized weekly training roadmap balancing volume, intensity, skill acquisition, and recovery.',
    pillars: ['Tactics and Boxing IQ', 'Recovery and Reflection'],
    difficulty: 'Mastery',
    estimatedDurationMin: 45,
    prerequisiteLessonIds: ['les-19-01'],
    learningObjectives: [
      'Structure weekly microcycles (technical drills, heavy bag, conditioning, rest).',
      'Isolate personal technical deficiencies and schedule targeted remediation.',
      'Incorporate structured recovery protocols to prevent overtraining.',
    ],
    mainExplanation:
      'Mastery is self-directed. A fighter cannot rely indefinitely on generic gym routines. You must assess your reach, stance, foot speed, and endurance to construct a deliberate study plan. Every round must have an explicit objective: not merely "working out," but calibrating a specific pivot or honing non-telegraphic snap.',
    conceptualBreakdown: [
      {
        step: 'Deficiency Audit',
        explanation: 'Review your training journal: what faults reappear under fatigue?',
      },
      {
        step: 'Weekly Volume Allocation',
        explanation: 'Balance 3-4 technical sessions with aerobic base work and deliberate mobility days.',
      },
      {
        step: 'Targeted Remediation',
        explanation: 'Dedicate the first 2 rounds of every session to your weakest fundamental mechanic.',
      },
    ],
    commonMistakes: [
      'Training at 100% maximum intensity every single day, leading to nervous system burnout and injury.',
      'Neglecting recovery and technical reflection.',
    ],
    safetyConsiderations: ['Autoregulate volume: reduce load when resting heart rate is elevated or sleep is compromised.'],
    suggestedPractice: 'Draft your personal 4-week training schedule in the Academy Training Journal.',
    knowledgeCheck: [
      {
        id: 'kc-20-01',
        question: 'Why is deloading and scheduled recovery essential in an advanced boxing study plan?',
        options: [
          'Because muscles and the central nervous system adapt and rebuild during recovery, not during exhaustion.',
          'To save money on gym dues.',
          'Because boxing is not an athletic sport.',
          'To let wraps dry.',
        ],
        correctIndex: 0,
        explanation:
          'Continuous chronic fatigue degrades motor patterns, causes technical regressions, and increases injury risk.',
      },
    ],
    reflectionPrompt: 'What is the single most glaring mechanical weakness in your arsenal today, and how will you drill it this month?',
    completionCriteria: 'Pass quiz and draft personal study blueprint.',
    xpReward: 500,
    relatedLessonIds: ['les-19-01', 'les-21-01'],
    relatedTechniqueIds: ['tech-personal-blueprint'],
  },

  // --- LEVEL 21 LESSONS ---
  {
    id: 'les-21-01',
    levelNumber: 21,
    phaseNumber: 5,
    title: 'Autonomous Synthesis: Offense, Defense & Movement',
    description:
      'Erase the lag between stimulus and response. Move seamlessly between slipping, pivoting, and power strikes without hesitation.',
    pillars: ['Conditioning and Movement', 'Offense and Punch Mechanics', 'Defense and Awareness'],
    difficulty: 'Mastery',
    estimatedDurationMin: 50,
    prerequisiteLessonIds: ['les-20-01'],
    learningObjectives: [
      'Execute continuous 6-round technical flow state shadowboxing.',
      'Slip while advancing and pivot while punching without breaking balance.',
      'Demonstrate absolute economy of movement.',
    ],
    mainExplanation:
      'In Phase I, every punch and step is conscious and mechanical. In Phase V, the mechanics have been grooved through thousands of repetitions into unconscious autonomic pathways. Offense, defense, and footwork blend into an unbroken, flowing continuum.',
    conceptualBreakdown: [
      {
        step: 'Centerline Weaving in Motion',
        explanation: 'Slipping off the line on each forward and lateral step.',
      },
      {
        step: 'Punching Off the Angle',
        explanation: 'Firing the hook mid-pivot as the rear foot touches canvas.',
      },
      {
        step: 'Effortless Economy',
        explanation: 'Zero wasted muscle tension; relax until the instant of impact.',
      },
    ],
    commonMistakes: [
      'Tensing shoulders and holding breath during long combinations.',
      'Losing form when increasing pace.',
    ],
    safetyConsiderations: ['Stay hydrated and maintain rhythmic nasal breathing to keep mental composure.'],
    suggestedPractice: '6-Round continuous shadowboxing session: focus on effortless fluid transitions.',
    knowledgeCheck: [
      {
        id: 'kc-21-01',
        question: 'What defines true economy of movement in grandmaster pugilism?',
        options: [
          'Throwing every punch with maximum muscular tension from start to finish.',
          'Total muscular relaxation through trajectory, tensing only at the microsecond of impact, and moving only the minimum distance required.',
          'Standing completely still.',
          'Jumping continuously.',
        ],
        correctIndex: 1,
        explanation:
          'Relaxation delivers maximum velocity and preserves cardiovascular reserves, stiffening only at impact.',
      },
    ],
    reflectionPrompt: 'Did you notice any moments where you held your breath? How can you sync exhalations with your punches?',
    completionCriteria: 'Pass quiz and complete 6-round autonomous shadowboxing protocol.',
    xpReward: 550,
    relatedLessonIds: ['les-20-01', 'les-22-01'],
    relatedTechniqueIds: ['tech-flow-state-matrix'],
  },

  // --- LEVEL 22 LESSONS ---
  {
    id: 'les-22-01',
    levelNumber: 22,
    phaseNumber: 5,
    title: 'Tactical Problem-Solving Under Pressure',
    description:
      'Solve live ring puzzles: breaking down awkward southpaws, neutralizing reach disadvantages, and surviving pocket storms.',
    pillars: ['Tactics and Boxing IQ', 'Defense and Awareness'],
    difficulty: 'Mastery',
    estimatedDurationMin: 50,
    prerequisiteLessonIds: ['les-21-01'],
    learningObjectives: [
      'Win the lead-foot battle against southpaws (outside foot dominance).',
      'Manage severe reach disadvantages by slipping inside long jabs.',
      'Clinch safely and tie up inside arms without taking illegal fouls.',
    ],
    mainExplanation:
      'In the ring, things rarely go to plan. Opponents switch stances, possess unexpected reach, or press with unhinged aggression. The tactical master has a prepared solution for every contingency: winning the outside foot against a southpaw to line up the straight cross, or using safe collar ties to neutralize infighting flurries.',
    conceptualBreakdown: [
      {
        step: 'The Southpaw Foot Battle',
        explanation: 'Keep your lead foot outside the southpaw’s lead foot to take away their left hand angle.',
      },
      {
        step: 'Slipping the Reach Advantage',
        explanation: 'Slip outside their long jab and step in with an overhand cross over their shoulder.',
      },
      {
        step: 'The Safe Clinch Protocol',
        explanation: 'Clamp upper biceps and control head posture against chest to nullify inside strikes.',
      },
    ],
    commonMistakes: [
      'Stepping inside a southpaw’s lead foot, directly into their power left hand.',
      'Backing straight up when trapped on the ropes.',
    ],
    safetyConsiderations: ['Clinch control must be executed cleanly with zero headbutting or dangerous neck torquing.'],
    suggestedPractice: 'Shadowbox 3 rounds specifically simulating southpaw outside-foot dominance.',
    knowledgeCheck: [
      {
        id: 'kc-22-01',
        question: 'When an orthodox fighter faces a southpaw, why is winning the "lead foot battle" (stepping outside their lead foot) critical?',
        options: [
          'It lines up your rear power cross with their chin while moving your head away from their power left cross.',
          'It lets you trip the opponent legally.',
          'It causes the southpaw’s shoes to untie.',
          'It is required by boxing judging rules.',
        ],
        correctIndex: 0,
        explanation:
          'Outside foot positioning aligns your rear cross right down their centerline while moving you outside their dominant power line.',
      },
    ],
    reflectionPrompt: 'Have you ever sparred or drilled against a southpaw? What was the most disorienting visual cue?',
    completionCriteria: 'Pass southpaw tactical quiz and demonstrate outside-foot positioning.',
    xpReward: 550,
    relatedLessonIds: ['les-21-01', 'les-23-01'],
    relatedTechniqueIds: ['tech-southpaw-tactics', 'tech-clinch-safety'],
  },

  // --- LEVEL 23 LESSONS ---
  {
    id: 'les-23-01',
    levelNumber: 23,
    phaseNumber: 5,
    title: 'Sustainable Training & Long-Term Athletic Longevity',
    description:
      'Protect your brain, joints, and spine. Master autoregulation, CNS diagnostics, hydration protocols, and lifelong health.',
    pillars: ['Technical Practice and Equipment Safety', 'Recovery and Reflection'],
    difficulty: 'Mastery',
    estimatedDurationMin: 45,
    prerequisiteLessonIds: ['les-22-01'],
    learningObjectives: [
      'Understand sub-concussive threshold and safety protocols: zero hard sparring without coach supervision.',
      'Master rotator cuff, thoracic, and hip mobility preservation.',
      'Reject dangerous dehydration weight-cutting myths and protect neurological safety.',
    ],
    mainExplanation:
      'Boxing is a brutal sport, but boxing education and technical training should enhance your physical vitality for life. True professionals reject dangerous machismo: hitting brick walls, taking unnecessary concussive blows, or dehydrating in plastic suits. Longevity is built on clean technique, smart equipment, and deep respect for neurological preservation.',
    conceptualBreakdown: [
      {
        step: 'Neurological Protection Protocol',
        explanation: 'Head contact is never required for technical mastery. Heavy bag, shadowboxing, and touch drills build 95% of fight IQ.',
      },
      {
        step: 'Joint Preservation Matrix',
        explanation: 'Thoracic rotations, wrist extension stretches, and rotator cuff band work before and after every session.',
      },
      {
        step: 'Hydration and Nutrition Sanity',
        explanation: 'Hydrated brain tissue is cushioned; dehydrated brain tissue is vulnerable to catastrophic concussive shear.',
      },
    ],
    commonMistakes: [
      'Believing taking hits to the head "toughens your chin" (it causes cumulative neurological damage).',
      'Training through sharp, acute joint pain.',
    ],
    safetyConsiderations: [
      'NEVER participate in unsupervised hard sparring.',
      'Never attempt rapid water cuts or saunas without medical monitoring.',
    ],
    suggestedPractice: 'Perform full 20-minute post-session mobility and breathing recovery protocol.',
    knowledgeCheck: [
      {
        id: 'kc-23-01',
        question: 'Why is severe dehydration (e.g., plastic sweat suits, excessive saunas) particularly dangerous for boxers?',
        options: [
          'It depletes cerebrospinal fluid, reducing the brain’s protective hydraulic cushion and drastically increasing traumatic concussion risk.',
          'It makes your boxing shorts too loose.',
          'It only affects your punch speed slightly.',
          'It turns your sweat blue.',
        ],
        correctIndex: 0,
        explanation:
          'Dehydration shrinks fluid cushions around the brain, making brain tissue strike the skull wall with far greater concussive force.',
      },
    ],
    reflectionPrompt: 'How will you balance your competitive fire with the wisdom to protect your long-term physical health?',
    completionCriteria: 'Pass safety longevity audit and pledge strict training safety protocol.',
    xpReward: 600,
    relatedLessonIds: ['les-22-01', 'les-24-01'],
    relatedTechniqueIds: ['tech-safety-codex', 'tech-mobility-routine'],
  },

  // --- LEVEL 24 LESSONS ---
  {
    id: 'les-24-01',
    levelNumber: 24,
    phaseNumber: 5,
    title: 'The Apex Pugilist: Comprehensive Knowledge Thesis',
    description:
      'The final capstone evaluation of the DRVZZY ACADEMY curriculum: 24-level synthesis, ring generalship, and the sweet science transcended.',
    pillars: [
      'Conditioning and Movement',
      'Offense and Punch Mechanics',
      'Defense and Awareness',
      'Technical Practice and Equipment Safety',
      'Tactics and Boxing IQ',
      'Recovery and Reflection',
    ],
    difficulty: 'Mastery',
    estimatedDurationMin: 60,
    prerequisiteLessonIds: ['les-23-01'],
    learningObjectives: [
      'Synthesize all six standardized training pillars into a comprehensive thesis.',
      'Demonstrate absolute mastery of stance, footwork, non-telegraphic power, and multi-layer defense.',
      'Earn the title of Apex Pugilist (Rank VIII) in DRVZZY ACADEMY.',
    ],
    mainExplanation:
      'You have traversed the entire 24-level blueprint: from the beginner diagonal tape line and 180-inch wrap, through combination sequencing and lateral pivots, up to pull counters and ring-cutting geometry. Boxing is no longer a collection of isolated punches—it is an art form, a science of movement, balance, and strategic dominance. Study the craft. Earn your level.',
    conceptualBreakdown: [
      {
        step: 'Phase I Foundation Recall',
        explanation: 'Stance integrity and 55/45 weight balance remaining unshakeable under any pressure.',
      },
      {
        step: 'Phase II & III Kinetic Torque',
        explanation: 'Non-telegraphic snap, hip-driven cross, compact hooks, and smooth defensive exit slips.',
      },
      {
        step: 'Phase IV & V Ring Command',
        explanation: 'Ring geometry, counter-timing, feints, and lifelong sustainable athletic discipline.',
      },
    ],
    commonMistakes: [
      'Thinking learning is finished. The greatest grandmasters remain humble students of the craft forever.',
    ],
    safetyConsiderations: [
      'Carry the responsibility of this knowledge: boxing is an art of defense and self-discipline, never street aggression.',
    ],
    suggestedPractice: '12-Round Championship Simulation: 2 rounds for each of the 6 pillars in uninterrupted succession.',
    knowledgeCheck: [
      {
        id: 'kc-24-01',
        question: 'What is the true underlying motto and discipline of DRVZZY ACADEMY?',
        options: [
          'Swing wild and hope for knockouts.',
          'Study the craft. Earn your level.',
          'Punches matter more than footwork.',
          'Never wear hand wraps.',
        ],
        correctIndex: 1,
        explanation:
          'STUDY THE CRAFT. EARN YOUR LEVEL. Progression is earned through verified benchmark tests and technical discipline.',
      },
      {
        id: 'kc-24-02',
        question: 'Which element is the irreplaceable foundation of all punch power, defensive evasion, and ring mobility?',
        options: [
          'Bicep size.',
          'Balance and footwork grounded on a solid kinetic base.',
          'Glove color.',
          'Shouting while punching.',
        ],
        correctIndex: 1,
        explanation:
          'Without balance and footwork, power cannot transfer and defense collapses. Everything starts from the canvas.',
      },
    ],
    reflectionPrompt: 'Look back at your Level 1 self. How has your perception of boxing transformed from raw fighting into the Sweet Science?',
    completionCriteria: 'Pass the Grandmaster Knowledge Thesis and earn Level 24 completion.',
    xpReward: 1000,
    relatedLessonIds: ['les-01-01', 'les-09-01', 'les-16-01', 'les-23-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-piston-jab', 'tech-rear-cross', 'tech-pull-counter'],
  },
];

export const TECHNIQUE_CATALOG: TechniqueItem[] = [
  // 1. Stance & Guard
  {
    id: 'tech-orthodox-stance',
    code: 'STN-01',
    name: 'Orthodox Stance & Guard',
    pillar: 'Conditioning and Movement',
    phase: 1,
    category: 'Stance & Guard',
    difficulty: 'Novice',
    description:
      'The foundational stance for right-hand dominant fighters. Left foot and left shoulder forward along a 45-degree angle, chin tucked, 55/45 weight distribution.',
    educationalExplanation:
      'The orthodox stance arranges the body along a diagonal plane to minimize the target area presented to the opponent while positioning the dominant rear hand in maximum kinetic winding position. The lead hand acts as a rangefinder, shield, and probe.',
    biomechanics: [
      'Place feet shoulder-width apart along a 45-degree diagonal line.',
      'Slight bend in knees (15-20 degrees); rear heel elevated 1 inch off canvas.',
      'Distribute weight 55% rear foot, 45% lead foot.',
      'Tuck chin securely into left clavicle; hands at cheekbone height, elbows tucked into ribs.',
    ],
    commonMistakes: [
      'Standing flat on the rear heel, causing backward balance collapse.',
      'Placing feet on a straight line (tightrope), destroying lateral balance.',
      'Flaring elbows out, exposing floating ribs.',
    ],
    safetyConsiderations: [
      'Always practice on level ground; avoid twisting ankles on uneven surfaces.',
      'Never lock knees straight.',
    ],
    ringApplication:
      'Provides the stable base for all forward penetration, lateral pivots, and immediate defensive slip maneuvers.',
    relatedLessonIds: ['les-01-01', 'les-04-01'],
    relatedTechniqueIds: ['tech-high-guard', 'tech-step-drag'],
  },
  {
    id: 'tech-southpaw-stance',
    code: 'STN-02',
    name: 'Southpaw Stance Geometry',
    pillar: 'Conditioning and Movement',
    phase: 1,
    category: 'Stance & Guard',
    difficulty: 'Novice',
    description:
      'The mirror stance for left-hand dominant fighters. Right foot and right shoulder lead, with the powerful left hand in the rear slot.',
    educationalExplanation:
      'Southpaws present unique open-stance angles against orthodox opponents. The front feet clash along the outside channel, making outside-foot positioning the primary tactical battleground.',
    biomechanics: [
      'Right foot and right hand forward at 45-degree angle.',
      'Left rear heel elevated; 55% weight on rear left ball of foot.',
      'Chin tucked behind right shoulder; rear left hand glued to cheekbone.',
    ],
    commonMistakes: [
      'Stepping inside an orthodox opponent’s lead foot.',
      'Dropping rear power hand when probing with right jab.',
    ],
    safetyConsiderations: ['Watch for clash of heads when stepping in against orthodox opponents.'],
    ringApplication:
      'Allows devastating left cross straight down the middle and right lead hook around orthodox high guards.',
    relatedLessonIds: ['les-01-01', 'les-22-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-southpaw-tactics'],
  },
  {
    id: 'tech-high-guard',
    code: 'DEF-01',
    name: 'High Guard (Pyramid Wall)',
    pillar: 'Defense and Awareness',
    phase: 1,
    category: 'Defense & Evasion',
    difficulty: 'Novice',
    description:
      'A compact, structural forearm shield held firmly against temples and cheekbones to absorb and deflect straight punches and hooks.',
    educationalExplanation:
      'The high guard creates a rigid skeletal frame where glove impact is transmitted directly through the forearms and knees into the ground, rather than snapping the neck backward.',
    biomechanics: [
      'Thumbs pressed against temples/cheekbones.',
      'Elbows clamped together, guarding the sternum and floating ribs.',
      'Maintain 2-inch sightline window between gloves; gaze forward at chest.',
      'Absorb impact by softening knees, not collapsing arms.',
    ],
    commonMistakes: [
      'Holding gloves floating away from face (punch smashes own gloves into nose).',
      'Closing eyes or ducking head completely down.',
    ],
    safetyConsiderations: ['Ensure 16oz gloves and wraps are used when catching heavy shots in partner drills.'],
    ringApplication:
      'Essential for walking through mid-range fire, surviving corner traps, and setting up tight counter uppercuts.',
    relatedLessonIds: ['les-01-02', 'les-15-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-forearm-frame'],
  },

  // 2. Footwork & Movement
  {
    id: 'tech-step-drag',
    code: 'FTW-01',
    name: 'Linear Step-Drag Locomotion',
    pillar: 'Conditioning and Movement',
    phase: 1,
    category: 'Footwork',
    difficulty: 'Novice',
    description:
      'The fundamental method of moving forward and backward while preserving stance width, balance, and punch readiness.',
    educationalExplanation:
      'By pushing off the foot furthest from the intended direction, you maintain maximum traction and instantly restore your 55/45 base without crossing your feet.',
    biomechanics: [
      'Forward: push with rear ball of foot; step 6 inches with lead foot; drag rear foot 6 inches.',
      'Backward: push with lead ball of foot; step 6 inches with rear foot; drag lead foot 6 inches.',
      'Keep head at constant elevation; do not bob up and down.',
    ],
    commonMistakes: [
      'Crossing feet, completely destroying balance.',
      'Hopping or taking strides too wide, pulling the legs into a split.',
    ],
    safetyConsiderations: ['Ensure shoes have adequate grip to prevent slips during fast pushes.'],
    ringApplication:
      'Used on every advance and retreat in the ring to enter punching range and escape counters.',
    relatedLessonIds: ['les-02-01', 'les-04-01'],
    relatedTechniqueIds: ['tech-orthodox-stance', 'tech-lateral-shuffle'],
  },
  {
    id: 'tech-lateral-shuffle',
    code: 'FTW-02',
    name: 'Lateral Step-Slide',
    pillar: 'Conditioning and Movement',
    phase: 1,
    category: 'Footwork',
    difficulty: 'Fundamental',
    description:
      'Moving laterally to the left and right without crossing ankles or narrowing the base.',
    educationalExplanation:
      'Moving left requires the right foot to push; moving right requires the left foot to push. Preserves guard integrity against lateral hooks.',
    biomechanics: [
      'Moving Left: Push off right inside edge; step left foot out; drag right foot in.',
      'Moving Right: Push off left inside edge; step right foot out; drag left foot in.',
      'Never allow feet to click together.',
    ],
    commonMistakes: [
      'Narrowing stance on the drag step, leaving yourself vulnerable to being tipped over.',
    ],
    safetyConsiderations: ['Avoid stepping on opponent feet in close quarters.'],
    ringApplication:
      'Essential for circling away from an opponent’s power hand and executing ring-cutting maneuvers.',
    relatedLessonIds: ['les-02-01', 'les-17-01'],
    relatedTechniqueIds: ['tech-step-drag', 'tech-45-pivot'],
  },
  {
    id: 'tech-45-pivot',
    code: 'FTW-03',
    name: 'The 45-Degree Pivot',
    pillar: 'Conditioning and Movement',
    phase: 3,
    category: 'Footwork',
    difficulty: 'Intermediate',
    description:
      'Planting the lead foot and swinging the rear leg 45 degrees to exit the opponent’s firing line and create an acute attacking angle.',
    educationalExplanation:
      'The pivot rotates your entire axis around the planted ball of your lead foot. You exit the opponent’s centerline while keeping your weapons trained on their flank.',
    biomechanics: [
      'Throw jab or slip lead side; anchor ball of lead foot.',
      'Swing rear foot in a 45-degree arc behind you.',
      'Hips and shoulders snap to face the opponent’s new position.',
    ],
    commonMistakes: [
      'Pivoting on the heel, causing backward fall.',
      'Dropping guard hands during the turn.',
    ],
    safetyConsiderations: ['Ensure ankle stability; do not twist knee with a flat-footed shoe.'],
    ringApplication:
      'Turns aggressive forward-charging sluggers into empty canvas, opening up devastating liver hooks and counter crosses.',
    relatedLessonIds: ['les-12-01', 'les-17-01'],
    relatedTechniqueIds: ['tech-l-step', 'tech-step-drag'],
  },
  {
    id: 'tech-l-step',
    code: 'FTW-04',
    name: 'The L-Step Cutback',
    pillar: 'Conditioning and Movement',
    phase: 3,
    category: 'Footwork',
    difficulty: 'Intermediate',
    description:
      'A defensive repositioning maneuver: step straight back, then cut 90 degrees laterally to break an opponent’s pursuit vector.',
    educationalExplanation:
      'Instead of retreating in a straight predictable line to the ropes, the L-step creates an "L" shaped trajectory that completely derails linear bull-rushes.',
    biomechanics: [
      'Step rear foot straight back.',
      'Push off rear foot and step lead foot laterally 90 degrees.',
      'Reset stance in the clear zone.',
    ],
    commonMistakes: ['Rushing the lateral step and tripping over your own feet.'],
    safetyConsiderations: ['Practice at half-speed first to groove ankle coordination.'],
    ringApplication: 'The ultimate escape hatch when pressed toward the ropes.',
    relatedLessonIds: ['les-12-01', 'les-17-01'],
    relatedTechniqueIds: ['tech-45-pivot', 'tech-lateral-shuffle'],
  },

  // 3. Strikes & Mechanics
  {
    id: 'tech-piston-jab',
    code: 'STR-01',
    name: 'The Piston Jab',
    pillar: 'Offense and Punch Mechanics',
    phase: 2,
    category: 'Strikes & Mechanics',
    difficulty: 'Fundamental',
    description:
      'The master key of boxing. A laser-straight lead punch firing from the shoulder with thumb-down pronation and instant recoil.',
    educationalExplanation:
      'Non-telegraphic speed, eye disruption, distance gauge, and setup weapon. The lead shoulder rises to cover the chin on extension.',
    biomechanics: [
      'Fist launches straight from cheek without preparatory dip.',
      'Pronate forearm 90 degrees; land with index and middle knuckles.',
      'Lead shoulder tucks against left chin.',
      'Rear hand remains glued to right cheek.',
      'Recoil instantly along the exact same path.',
    ],
    commonMistakes: [
      'Elbow flaring out (chicken wing).',
      'Dropping rear hand to chest.',
      'Hyperextending the elbow joint.',
    ],
    safetyConsiderations: ['Keep microscopic bend in elbow at peak reach during shadowboxing.'],
    ringApplication:
      'Dictates range, establishes pace, blinds guard, and sets up every power combination.',
    relatedLessonIds: ['les-05-01', 'les-09-01'],
    relatedTechniqueIds: ['tech-rear-cross', 'tech-body-jab'],
  },
  {
    id: 'tech-rear-cross',
    code: 'STR-02',
    name: 'The Rear Straight (Cross)',
    pillar: 'Offense and Punch Mechanics',
    phase: 2,
    category: 'Strikes & Mechanics',
    difficulty: 'Fundamental',
    description:
      'The primary power weapon. Generated by the rear ball-of-foot pivot, driving the hip forward and snapping the straight right hand.',
    educationalExplanation:
      'Transfers ground reaction force through ankle extension, hip rotation, thoracic snap, and locked wrist impact.',
    biomechanics: [
      'Pivot rear ball of foot 45 degrees outward (squash the bug).',
      'Drive rear hip forward until belt buckle faces opponent.',
      'Right hand launches straight down the centerline; rear shoulder covers right jaw.',
      'Lead glove stays glued to left cheekbone.',
    ],
    commonMistakes: [
      'Flat rear foot preventing hip rotation.',
      'Dropping lead hand, inviting counter left hook.',
      'Leaning torso forward over the lead knee.',
    ],
    safetyConsiderations: ['Ensure wraps are tight to prevent wrist buckling on heavy bag impacts.'],
    ringApplication:
      'Devastating knockout strike down the pipe after setting up with the jab or slipping an opponent’s punch.',
    relatedLessonIds: ['les-06-01', 'les-09-01'],
    relatedTechniqueIds: ['tech-piston-jab', 'tech-pull-counter'],
  },
  {
    id: 'tech-lead-hook',
    code: 'STR-03',
    name: 'The Lead Hook',
    pillar: 'Offense and Punch Mechanics',
    phase: 2,
    category: 'Strikes & Mechanics',
    difficulty: 'Fundamental',
    description:
      'A rotational strike around the opponent’s guard. Torqued around the spine with elbow level with wrist.',
    educationalExplanation:
      'Turn the entire body as one cohesive unit around the central spinal axis. The arm stays locked in a 90-degree frame.',
    biomechanics: [
      'Pivot lead ball of foot 90 degrees; lead hip drives inward.',
      'Elbow rises level with fist in horizontal plane.',
      'Thumb can face up or inward depending on range.',
      'Rear hand clamped to right cheek; stop punch at centerline.',
    ],
    commonMistakes: [
      'Winding up by pulling hand back first.',
      'Dropping elbow below wrist, turning strike into weak slap.',
      'Over-rotating past the centerline.',
    ],
    safetyConsiderations: ['Maintain strict wrist stiffness; off-center hook impact causes wrist sprains.'],
    ringApplication:
      'Attacks temple, jaw, or liver when opponent guards straight down the middle.',
    relatedLessonIds: ['les-07-01', 'les-10-01'],
    relatedTechniqueIds: ['tech-rear-cross', 'tech-shovel-hook'],
  },
  {
    id: 'tech-rear-uppercut',
    code: 'STR-04',
    name: 'The Rear Uppercut',
    pillar: 'Offense and Punch Mechanics',
    phase: 2,
    category: 'Strikes & Mechanics',
    difficulty: 'Fundamental',
    description:
      'A compact, rising vertical strike driven by knee extension rather than arm pulling, designed to split guards.',
    educationalExplanation:
      'Generated by a micro knee dip followed by explosive upward drive through the quads and hips, traveling along an 18-inch vertical arc.',
    biomechanics: [
      'Dip hips 2 inches to load legs.',
      'Drive upward through floor, turning palm toward your own chest.',
      'Keep elbow tight to body; punch travels straight upward between opponent’s gloves.',
      'Opposite hand stays glued to jaw.',
    ],
    commonMistakes: [
      'Dropping hand down to waist to build momentum.',
      'Swinging arm wide like a bowling ball.',
    ],
    safetyConsiderations: ['Never hyperextend lumbar spine when driving upward.'],
    ringApplication:
      'Punishes opponents who duck their heads, lean forward, or shell up in tight peek-a-boo guards.',
    relatedLessonIds: ['les-08-01', 'les-10-01'],
    relatedTechniqueIds: ['tech-lead-hook', 'tech-shovel-hook'],
  },
  {
    id: 'tech-body-jab',
    code: 'STR-05',
    name: 'The Body Jab',
    pillar: 'Offense and Punch Mechanics',
    phase: 3,
    category: 'Strikes & Mechanics',
    difficulty: 'Intermediate',
    description:
      'Level change with hip and knee dip to plant a stiff jab into the solar plexus or floating ribs.',
    educationalExplanation:
      'Forces opponent’s eyes and guard downward, interrupting their breathing rhythm and opening the head for overhand crosses.',
    biomechanics: [
      'Dip hips and knees simultaneously; do not bend at waist.',
      'Step lead foot forward as jab launches straight into solar plexus.',
      'Lead shoulder covers chin; head remains off the centerline.',
    ],
    commonMistakes: [
      'Bending at waist with straight legs, leaning chin directly into an uppercut.',
    ],
    safetyConsiderations: ['Keep rear hand glued to temple to protect against counter left hooks.'],
    ringApplication:
      'Drains stamina, slows down fast movers, and sets up high-low conversion combinations.',
    relatedLessonIds: ['les-10-01', 'les-18-01'],
    relatedTechniqueIds: ['tech-piston-jab', 'tech-shovel-hook'],
  },
  {
    id: 'tech-shovel-hook',
    code: 'STR-06',
    name: 'The 45-Degree Shovel Hook',
    pillar: 'Offense and Punch Mechanics',
    phase: 4,
    category: 'Strikes & Mechanics',
    difficulty: 'Advanced',
    description:
      'A hybrid punch blending the arc of a hook with the elevation of an uppercut, designed specifically to spear the liver.',
    educationalExplanation:
      'Strikes upward and inward at a 45-degree angle beneath the lower right rib cage, transmitting shock into the liver capsule.',
    biomechanics: [
      'Level change with left hip drop.',
      'Palm faces upward-inward at 45 degrees.',
      'Drive upward through lead quad into the ribs.',
      'Right glove clamped to jaw.',
    ],
    commonMistakes: [
      'Striking flat against the hip bone instead of angled upward beneath the ribs.',
    ],
    safetyConsiderations: ['High risk of organ bruising in live contact; drill with controlled touch.'],
    ringApplication:
      'The premier fight-ending body blow in infighting and corner traps.',
    relatedLessonIds: ['les-18-01'],
    relatedTechniqueIds: ['tech-lead-hook', 'tech-body-jab'],
  },

  // 4. Defensive Maneuvers
  {
    id: 'tech-slip-outside',
    code: 'DEF-02',
    name: 'The Outside Slip',
    pillar: 'Defense and Awareness',
    phase: 2,
    category: 'Defense & Evasion',
    difficulty: 'Fundamental',
    description:
      'Moving the head 3 to 4 inches off the centerline to the outside of an incoming straight punch while loading a counter.',
    educationalExplanation:
      'Subtle knee and hip flexion shifts the head off the firing line without disconnecting your base or vision.',
    biomechanics: [
      'Flex lead knee and rotate torso 15 degrees to the outside of incoming jab.',
      'Move head just enough for punch to graze cheek; keep eyes locked on opponent.',
      'Weight loads onto lead leg, priming a return hook or cross.',
    ],
    commonMistakes: [
      'Bending forward at the waist and looking down at the canvas.',
      'Slipping too far (over-slipping), taking you out of counter range.',
    ],
    safetyConsiderations: ['Never take your eyes off the opponent’s chest while slipping.'],
    ringApplication:
      'Makes opponent miss cleanly and loads your kinetic chain for instant counter-punching.',
    relatedLessonIds: ['les-09-01', 'les-11-01'],
    relatedTechniqueIds: ['tech-high-guard', 'tech-rear-parry'],
  },
  {
    id: 'tech-rear-parry',
    code: 'DEF-03',
    name: 'The Rear Hand Parry',
    pillar: 'Defense and Awareness',
    phase: 2,
    category: 'Defense & Evasion',
    difficulty: 'Fundamental',
    description:
      'A micro deflection using the open palm of the rear glove to redirect an incoming jab off its trajectory.',
    educationalExplanation:
      'Requires minimal movement (1-2 inches). Taps the incoming glove downward and inward, disrupting the opponent’s balance.',
    biomechanics: [
      'Open rear glove at cheek level.',
      'Flick palm 2 inches forward to meet incoming jab wrist/glove.',
      'Deflect punch past your lead shoulder; immediately return hand to jaw.',
    ],
    commonMistakes: [
      'Reaching forward with both hands to swat at the punch like catching butterflies.',
    ],
    safetyConsiderations: ['Keep parry short; reaching exposes your chin to feint-hooks.'],
    ringApplication:
      'Neutralizes the opponent’s primary rangefinder and opens the door for the catch-and-shoot cross.',
    relatedLessonIds: ['les-09-01', 'les-11-01'],
    relatedTechniqueIds: ['tech-catch-and-pitch', 'tech-high-guard'],
  },
  {
    id: 'tech-catch-and-pitch',
    code: 'DEF-04',
    name: 'The Catch-and-Pitch Counter',
    pillar: 'Defense and Awareness',
    phase: 3,
    category: 'Defense & Evasion',
    difficulty: 'Intermediate',
    description:
      'Catching opponent’s jab on the rear palm and immediately firing a return right cross over their extended arm.',
    educationalExplanation:
      'Eliminates the reaction lag between defense and offense. The impact of their punch on your palm acts as the trigger for your cross.',
    biomechanics: [
      'Absorb incoming jab on rear palm held 1 inch in front of cheek.',
      'The moment impact is felt, drive through rear ball of foot and explode with return cross.',
      'Keep lead hand glued to jaw.',
    ],
    commonMistakes: [
      'Waiting a full beat after catching before firing.',
    ],
    safetyConsiderations: ['Ensure thumb is tucked in glove to prevent jamming thumb on impact.'],
    ringApplication:
      'Punishes lazy or repetitive jabbing opponents with sudden, unexpected power.',
    relatedLessonIds: ['les-11-01', 'les-16-01'],
    relatedTechniqueIds: ['tech-rear-cross', 'tech-rear-parry'],
  },
  {
    id: 'tech-pull-counter',
    code: 'DEF-05',
    name: 'The Pull Counter',
    pillar: 'Tactics and Boxing IQ',
    phase: 4,
    category: 'Defense & Evasion',
    difficulty: 'Advanced',
    description:
      'Retracting head 2 inches backward by compressing rear knee, letting jab miss by millimeters, and springing forward with a cross.',
    educationalExplanation:
      'The loaded rear leg acts as a coil spring. When the punch misses, the spring uncoils forward with devastating kinetic acceleration.',
    biomechanics: [
      'Bait opponent jab by holding head on centerline.',
      'Compress rear knee; pull head back 2 inches.',
      'Opponent punch grazes through empty space.',
      'Uncoil rear leg; drive straight cross over opponent’s extended shoulder.',
    ],
    commonMistakes: [
      'Leaning back on a straight rear leg and losing balance.',
      'Pulling chin up in the air.',
    ],
    safetyConsiderations: ['Requires pristine timing; do not attempt in live sparring without coach clearance.'],
    ringApplication:
      'The trademark weapon of elite defensive counter-punchers.',
    relatedLessonIds: ['les-16-01', 'les-24-01'],
    relatedTechniqueIds: ['tech-rear-cross', 'tech-slip-outside'],
  },

  // 5. Tactical Concepts
  {
    id: 'tech-lead-feint',
    code: 'TAC-01',
    name: 'The Lead Shoulder & Glove Feint',
    pillar: 'Tactics and Boxing IQ',
    phase: 3,
    category: 'Ring Awareness & Tactics',
    difficulty: 'Intermediate',
    description:
      'A sharp micro-twitch of the shoulder and half-step designed to trigger an opponent’s defensive reflex without throwing a strike.',
    educationalExplanation:
      'Forces opponent to commit their guard or balance, mapping their habits and creating openings for real strikes.',
    biomechanics: [
      'Flick lead shoulder and step forward 2 inches.',
      'Keep chin tucked and guard tight.',
      'Observe reaction: do they drop hands, raise guard, or step back?',
      'Follow immediately with counter weapon.',
    ],
    commonMistakes: ['Exaggerating movement and throwing yourself off balance.'],
    safetyConsiderations: ['Maintain stance discipline during feints; never lean forward.'],
    ringApplication:
      'Dismantles tight defensive shells by baiting parries and creating holes.',
    relatedLessonIds: ['les-13-01'],
    relatedTechniqueIds: ['tech-piston-jab', 'tech-distance-management'],
  },
  {
    id: 'tech-ring-cutting',
    code: 'TAC-02',
    name: 'Ring-Cutting Geometry',
    pillar: 'Conditioning and Movement',
    phase: 4,
    category: 'Ring Awareness & Tactics',
    difficulty: 'Advanced',
    description:
      'Herding elusive fighters by stepping along diagonal chords to take away perimeter exits and trap them against ropes.',
    educationalExplanation:
      'Reduces the physical distance you must travel while doubling the distance the runner must cover, eventually cornering them.',
    biomechanics: [
      'Step along inner diagonal paths, not behind the runner.',
      'Use lead hand to barrier their lateral escape.',
      'Widen base and clamp ropes when they reach the corner.',
    ],
    commonMistakes: ['Chasing directly in a circle behind the runner.'],
    safetyConsiderations: ['Watch for check hooks while cutting off the ring.'],
    ringApplication:
      'Essential for aggressive pressure fighters dismantling slick out-boxers.',
    relatedLessonIds: ['les-17-01'],
    relatedTechniqueIds: ['tech-lateral-shuffle', 'tech-45-pivot'],
  },
  {
    id: 'tech-distance-management',
    code: 'TAC-03',
    name: 'Distance & Range Management',
    pillar: 'Tactics and Boxing IQ',
    phase: 3,
    category: 'Ring Awareness & Tactics',
    difficulty: 'Intermediate',
    description:
      'Controlling the spatial border: long range (probing), mid range (exchanges), and infighting range (body/clinch).',
    educationalExplanation:
      'Mastery of being a half-inch out of opponent reach while keeping them within yours.',
    biomechanics: [
      'Use lead jab as measuring stick.',
      'Micro step-drags to stay on the edge of the critical danger zone.',
      'Enter range only with a jab or feint; never walk in unprotected.',
    ],
    commonMistakes: ['Lingering in no-man’s land where you can be hit but cannot hit back.'],
    safetyConsiderations: ['Never drop guard when transitioning ranges.'],
    ringApplication:
      'Dictates where the fight takes place, neutralizing opponent strengths.',
    relatedLessonIds: ['les-13-01', 'les-21-01'],
    relatedTechniqueIds: ['tech-piston-jab', 'tech-step-drag'],
  },

  // 6. Safety & Wrapping
  {
    id: 'tech-hand-wrap-protocol',
    code: 'SAF-01',
    name: '180-Inch Semi-Elastic Wrap Protocol',
    pillar: 'Technical Practice and Equipment Safety',
    phase: 1,
    category: 'Recovery & Training Safety',
    difficulty: 'Novice',
    description:
      'Professional hand wrapping protocol locking the 27 bones of the human hand into a unified, shock-absorbing structure.',
    educationalExplanation:
      'Protects metacarpals from fractures, immobilizes wrist joint against hyperextension, and cushions knuckles.',
    biomechanics: [
      '3 wraps around wrist.',
      '4-5 accordion knuckle folds for thick pad.',
      'X-wrap between each finger anchoring to wrist.',
      'Thumb lock figure-eight; finish firm around wrist.',
    ],
    commonMistakes: [
      'Wrapping fingers in a closed fist (too tight, cuts off blood).',
      'Neglecting wrist joint.',
    ],
    safetyConsiderations: [
      'Never hit bags bare-handed.',
      'Unwrap immediately if tingling or numbness occurs.',
    ],
    ringApplication: 'Mandatory prerequisite for every single boxing training session.',
    relatedLessonIds: ['les-03-01'],
    relatedTechniqueIds: ['tech-orthodox-stance'],
  },
  {
    id: 'tech-safety-codex',
    code: 'SAF-02',
    name: 'Drvzzy Academy Safety & Longevity Codex',
    pillar: 'Technical Practice and Equipment Safety',
    phase: 5,
    category: 'Recovery & Training Safety',
    difficulty: 'Mastery',
    description:
      'The unshakeable ethical code: zero unsupervised hard sparring, zero extreme dehydration, and lifelong neurological health.',
    educationalExplanation:
      'Boxing is a technical sweet science of movement and discipline. Protect your brain and joints for a lifetime of vitality.',
    biomechanics: [
      'Mandatory mouthguard and 16oz gloves for all contact drills.',
      'Autoregulate training loads based on recovery metrics.',
      'Immediate medical clearance required after any concussive head blow.',
    ],
    commonMistakes: ['Engaging in gym gym-wars or street bravado.'],
    safetyConsiderations: ['Health is non-negotiable; safety precedes ego.'],
    ringApplication: 'Guarantees you stay healthy, fast, and sharp for decades.',
    relatedLessonIds: ['les-23-01', 'les-24-01'],
    relatedTechniqueIds: ['tech-hand-wrap-protocol'],
  },
];
