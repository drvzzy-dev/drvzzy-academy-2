import React, { useState, useEffect } from 'react';
import {
  NavigationPage,
  FighterProfile,
  Rank,
  JournalSession,
  OnboardingProfile,
  CurriculumLevel,
  ActivityRecord,
  AppState,
  KnowledgeCheckSubmission,
} from './types/academy';
import {
  INITIAL_FIGHTER,
  RANKS_DATA,
} from './data/initialData';
import {
  CURRICULUM_LEVELS,
  LESSON_CATALOG,
  TECHNIQUE_CATALOG,
} from './data/curriculumData';
import { getRankForLevel } from './utils/progression';
import { loadAppState, saveAppState, clearAppState, INITIAL_APP_STATE } from './utils/storage';
import { Header } from './components/layout/Header';
import { SidebarNav } from './components/layout/SidebarNav';
import { MobileNav } from './components/layout/MobileNav';
import { SafetyBanner } from './components/layout/SafetyBanner';
import { SafetyModal } from './components/layout/SafetyModal';
import { OnboardingModal } from './components/onboarding/OnboardingModal';

// Pages
import { DashboardPage } from './pages/DashboardPage';
import { AcademyPage } from './pages/AcademyPage';
import { TrainingPage } from './pages/TrainingPage';
import { TechniqueLibraryPage } from './pages/TechniqueLibraryPage';
import { TacticalStudyPage } from './pages/TacticalStudyPage';
import { TrainingJournalPage } from './pages/TrainingJournalPage';
import { VideoReviewPage } from './pages/VideoReviewPage';
import { ProgressionPage } from './pages/ProgressionPage';
import { FighterProfilePage } from './pages/FighterProfilePage';
import { SettingsPage } from './pages/SettingsPage';

// Quick bottom bar icons for mobile
import {
  LayoutDashboard,
  GraduationCap,
  Dumbbell,
  ScrollText,
  User,
  Menu,
} from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [safetyModalOpen, setSafetyModalOpen] = useState(false);
  const [onboardingModalOpen, setOnboardingModalOpen] = useState(false);
  const [activeDrillToast, setActiveDrillToast] = useState<string | null>(null);
  const [externalLevelToInspect, setExternalLevelToInspect] = useState<CurriculumLevel | null>(null);
  const [externalSelectedLessonId, setExternalSelectedLessonId] = useState<string | null>(null);

  // Centralized App State with Local Persistence
  const [appState, setAppState] = useState<AppState>(() => loadAppState());

  // Automatically save state on updates
  useEffect(() => {
    saveAppState(appState);
  }, [appState]);

  // Open onboarding on first load if user has never completed it
  useEffect(() => {
    if (!appState.onboarding) {
      setOnboardingModalOpen(true);
    }
  }, []);

  const fighter = appState.fighter;
  const currentRank = getRankForLevel(fighter.currentLevel, RANKS_DATA);

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOnboardingComplete = (profile: OnboardingProfile) => {
    setAppState((prev) => {
      const updatedFighter: FighterProfile = {
        ...prev.fighter,
        callsign: profile.displayName || prev.fighter.callsign,
        fullName: profile.displayName || prev.fighter.fullName,
      };

      const onboardingActivity: ActivityRecord = {
        id: `act-${Date.now()}`,
        type: 'onboarding_completed',
        title: 'Admissions Interview Completed',
        subtitle: `Custom roadmap generated for ${profile.displayName} (${profile.experience.replace('_', ' ')})`,
        timestamp: 'JUST NOW',
        xpEarned: 50,
        targetPage: 'dashboard',
      };

      const newHistory = [onboardingActivity, ...prev.activityHistory];
      const newWeeklyGoal = Math.max(1, profile.availableDays.length || 3);

      return {
        ...prev,
        onboarding: profile,
        fighter: {
          ...updatedFighter,
          currentXp: updatedFighter.currentXp + 50,
        },
        activityHistory: newHistory,
        weeklyGoalSessions: newWeeklyGoal,
      };
    });

    setOnboardingModalOpen(false);
    setActiveDrillToast(`ACADEMY BLUEPRINT INITIALIZED FOR ${profile.displayName.toUpperCase()}`);
    setTimeout(() => setActiveDrillToast(null), 4000);
  };

  const handleUpdateFighter = (updated: Partial<FighterProfile>) => {
    setAppState((prev) => ({
      ...prev,
      fighter: {
        ...prev.fighter,
        ...updated,
      },
    }));
  };

  const handleSessionLogged = (session: JournalSession) => {
    setAppState((prev) => {
      const newXp = prev.fighter.currentXp + session.xpEarned;
      const newRounds = prev.fighter.totalRoundsLogged + session.rounds;
      const newHours = Number((prev.fighter.totalHoursTrained + (session.rounds * 3) / 60).toFixed(1));

      const sessionActivity: ActivityRecord = {
        id: `act-${Date.now()}`,
        type: 'training_session',
        title: `${session.rounds} Rounds ${session.sessionType}`,
        subtitle: `${session.focusPillar} (${session.intensity})`,
        timestamp: session.date,
        xpEarned: session.xpEarned,
        targetPage: 'journal',
      };

      return {
        ...prev,
        fighter: {
          ...prev.fighter,
          currentXp: newXp,
          totalRoundsLogged: newRounds,
          totalHoursTrained: newHours,
        },
        journalSessions: [session, ...prev.journalSessions],
        activityHistory: [sessionActivity, ...prev.activityHistory],
      };
    });

    setActiveDrillToast(`LOGGED ${session.rounds} ROUNDS — +${session.xpEarned} XP AWARDED`);
    setTimeout(() => setActiveDrillToast(null), 4000);
  };

  const handleCompleteLesson = (lessonId: string, reflection?: string) => {
    if (appState.completedLessonIds.includes(lessonId)) {
      return; // XP granted only once; avoid duplicate awards
    }

    const lesson = LESSON_CATALOG.find((l) => l.id === lessonId);
    if (!lesson) return;

    setAppState((prev) => {
      const newCompleted = [...prev.completedLessonIds, lessonId];
      const newXp = prev.fighter.currentXp + lesson.xpReward;

      // Find if this completes an entire Level
      const levelLessons = LESSON_CATALOG.filter((l) => l.levelNumber === lesson.levelNumber);
      const allLevelLessonsDone = levelLessons.every((l) => newCompleted.includes(l.id));

      const updatedLevelIds = allLevelLessonsDone && !prev.completedLevelIds.includes(lesson.levelNumber)
        ? [...prev.completedLevelIds, lesson.levelNumber]
        : prev.completedLevelIds;

      const newLevelNumber = allLevelLessonsDone
        ? Math.min(24, Math.max(prev.fighter.currentLevel, lesson.levelNumber + 1))
        : prev.fighter.currentLevel;

      // Advance in-progress lessons list
      const filteredInProgress = prev.inProgressLessonIds.filter((id) => id !== lessonId);
      const nextLesson = LESSON_CATALOG.find(
        (l) => !newCompleted.includes(l.id) && l.prerequisiteLessonIds.every((req) => newCompleted.includes(req))
      );
      const nextInProgress = nextLesson && !filteredInProgress.includes(nextLesson.id)
        ? [...filteredInProgress, nextLesson.id]
        : filteredInProgress;

      const activity: ActivityRecord = {
        id: `act-${Date.now()}`,
        type: 'lesson_completed',
        title: `Lvl ${lesson.levelNumber}: ${lesson.title}`,
        subtitle: `Completed syllabus & verified comprehension checks (+${lesson.xpReward} XP)`,
        timestamp: 'JUST NOW',
        xpEarned: lesson.xpReward,
        targetPage: 'academy',
        targetId: lesson.id,
      };

      return {
        ...prev,
        completedLessonIds: newCompleted,
        completedLevelIds: updatedLevelIds,
        inProgressLessonIds: nextInProgress,
        fighter: {
          ...prev.fighter,
          currentLevel: newLevelNumber,
          currentXp: newXp,
        },
        activityHistory: [activity, ...prev.activityHistory],
      };
    });

    setActiveDrillToast(`LESSON COMPLETED: ${lesson.title.toUpperCase()} (+${lesson.xpReward} XP EARNED)`);
    setTimeout(() => setActiveDrillToast(null), 4500);
  };

  const handleSaveKnowledgeCheck = (lessonId: string, submission: KnowledgeCheckSubmission) => {
    setAppState((prev) => ({
      ...prev,
      knowledgeCheckResults: {
        ...prev.knowledgeCheckResults,
        [lessonId]: submission,
      },
    }));
  };

  const handleToggleBookmarkTechnique = (techniqueId: string) => {
    setAppState((prev) => {
      const exists = prev.bookmarkedTechniqueIds.includes(techniqueId);
      const updated = exists
        ? prev.bookmarkedTechniqueIds.filter((id) => id !== techniqueId)
        : [...prev.bookmarkedTechniqueIds, techniqueId];

      return {
        ...prev,
        bookmarkedTechniqueIds: updated,
      };
    });
  };

  const handleOpenLessonById = (lessonId: string) => {
    setExternalSelectedLessonId(lessonId);
    setCurrentPage('academy');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToTechnique = (techniqueId: string) => {
    setCurrentPage('techniques');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCompleteLevel = (level: CurriculumLevel) => {
    if (appState.completedLevelIds.includes(level.levelNumber)) return;

    setAppState((prev) => {
      const xpReward = level.levelNumber * 100;
      const newCompleted = [...prev.completedLevelIds, level.levelNumber];
      const newXp = prev.fighter.currentXp + xpReward;

      // Determine new level if eligible
      const newLevelNumber = Math.max(prev.fighter.currentLevel, level.levelNumber + 1);

      const levelActivity: ActivityRecord = {
        id: `act-${Date.now()}`,
        type: 'lesson_completed',
        title: `Level ${level.levelNumber}: ${level.title}`,
        subtitle: `Passed Benchmark Test: ${level.benchmarkTest.substring(0, 50)}...`,
        timestamp: 'TODAY',
        xpEarned: xpReward,
        targetPage: 'academy',
      };

      return {
        ...prev,
        completedLevelIds: newCompleted,
        fighter: {
          ...prev.fighter,
          currentLevel: Math.min(24, newLevelNumber),
          currentXp: newXp,
        },
        activityHistory: [levelActivity, ...prev.activityHistory],
      };
    });

    setActiveDrillToast(`BENCHMARK PASSED: LEVEL ${level.levelNumber} COMPLETED (+${level.levelNumber * 100} XP)`);
    setTimeout(() => setActiveDrillToast(null), 4500);
  };

  const handleResetProgress = () => {
    clearAppState();
    setAppState(INITIAL_APP_STATE);
    setCurrentPage('dashboard');
  };

  const handleStartTodayDrill = () => {
    setActiveDrillToast("SESSION PROTOCOL INITIALIZED — PROCEED TO TRAINING PILLAR");
    setCurrentPage('training');
    setTimeout(() => setActiveDrillToast(null), 4000);
  };

  const handleOpenLesson = (level: CurriculumLevel) => {
    setExternalLevelToInspect(level);
    setCurrentPage('academy');
  };

  const handleUpdateWeeklyGoal = (goal: number) => {
    setAppState((prev) => ({
      ...prev,
      weeklyGoalSessions: goal,
    }));
  };

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <DashboardPage
            fighter={fighter}
            currentRank={currentRank}
            onboarding={appState.onboarding}
            completedLevelIds={appState.completedLevelIds}
            journalSessions={appState.journalSessions}
            activityHistory={appState.activityHistory}
            weeklyGoalSessions={appState.weeklyGoalSessions}
            onNavigate={handleNavigate}
            onStartTodayDrill={handleStartTodayDrill}
            onOpenLesson={handleOpenLesson}
            onOpenOnboarding={() => setOnboardingModalOpen(true)}
          />
        );
      case 'academy':
        return (
          <AcademyPage
            completedLevelIds={appState.completedLevelIds}
            completedLessonIds={appState.completedLessonIds}
            inProgressLessonIds={appState.inProgressLessonIds}
            knowledgeCheckResults={appState.knowledgeCheckResults}
            onCompleteLevel={handleCompleteLevel}
            onCompleteLesson={handleCompleteLesson}
            onSaveKnowledgeCheck={handleSaveKnowledgeCheck}
            onNavigateToTechnique={handleNavigateToTechnique}
            externalSelectedLessonId={externalSelectedLessonId}
            onClearExternalLessonId={() => setExternalSelectedLessonId(null)}
          />
        );
      case 'training':
        return (
          <TrainingPage
            completedLessonIds={appState.completedLessonIds}
            onOpenLesson={handleOpenLessonById}
          />
        );
      case 'techniques':
        return (
          <TechniqueLibraryPage
            bookmarkedTechniqueIds={appState.bookmarkedTechniqueIds}
            onToggleBookmarkTechnique={handleToggleBookmarkTechnique}
            onOpenLesson={handleOpenLessonById}
          />
        );
      case 'tactical':
        return <TacticalStudyPage />;
      case 'journal':
        return (
          <TrainingJournalPage
            sessions={appState.journalSessions}
            onSessionLogged={handleSessionLogged}
          />
        );
      case 'video-review':
        return <VideoReviewPage />;
      case 'progression':
        return (
          <ProgressionPage fighter={fighter} currentRank={currentRank} />
        );
      case 'profile':
        return (
          <FighterProfilePage
            fighter={fighter}
            currentRank={currentRank}
            onboarding={appState.onboarding}
            onUpdateFighter={handleUpdateFighter}
            onOpenOnboarding={() => setOnboardingModalOpen(true)}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            onboarding={appState.onboarding}
            onOpenOnboarding={() => setOnboardingModalOpen(true)}
            weeklyGoalSessions={appState.weeklyGoalSessions}
            onUpdateWeeklyGoal={handleUpdateWeeklyGoal}
            onResetProgress={handleResetProgress}
          />
        );
      default:
        return (
          <DashboardPage
            fighter={fighter}
            currentRank={currentRank}
            onboarding={appState.onboarding}
            completedLevelIds={appState.completedLevelIds}
            journalSessions={appState.journalSessions}
            activityHistory={appState.activityHistory}
            weeklyGoalSessions={appState.weeklyGoalSessions}
            onNavigate={handleNavigate}
            onStartTodayDrill={handleStartTodayDrill}
            onOpenLesson={handleOpenLesson}
            onOpenOnboarding={() => setOnboardingModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#090909] text-[#F5F5F5] flex flex-col font-sans selection:bg-[#D7263D] selection:text-[#FFFFFF]">
      {/* 1. Header */}
      <Header
        fighter={fighter}
        currentRank={currentRank}
        mobileMenuOpen={mobileMenuOpen}
        onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
        onOpenSafetyModal={() => setSafetyModalOpen(true)}
      />

      {/* 2. Safety & Medical Protocol Disclaimer */}
      <SafetyBanner onOpenFullProtocols={() => setSafetyModalOpen(true)} />

      {/* 3. Toast Banner for Drill execution feedback */}
      {activeDrillToast && (
        <div className="bg-[#D7263D] text-[#F5F5F5] px-4 py-2 font-mono-tech text-xs uppercase tracking-wider text-center font-bold animate-in fade-in slide-in-from-top duration-150">
          ✓ {activeDrillToast}
        </div>
      )}

      {/* 4. Main Body: Desktop Sidebar + Content Viewport */}
      <div className="flex-1 flex max-w-[1920px] w-full mx-auto">
        <SidebarNav
          activePage={currentPage}
          onNavigate={handleNavigate}
          fighter={fighter}
          currentRank={currentRank}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 pb-24 lg:pb-12 overflow-x-hidden min-w-0">
          {renderActivePage()}
        </main>
      </div>

      {/* 5. Mobile Navigation Drawer */}
      <MobileNav
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        activePage={currentPage}
        onNavigate={handleNavigate}
      />

      {/* 6. Quick Mobile Bottom Bar for High-Frequency Navigation */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 bg-[#0d0d0d] border-t border-[#303030] z-30 px-2 py-1.5 flex items-center justify-around select-none">
        <button
          onClick={() => handleNavigate('dashboard')}
          className={`flex flex-col items-center py-1 px-2 cursor-pointer transition-colors ${
            currentPage === 'dashboard' ? 'text-[#D7263D]' : 'text-[#777777]'
          }`}
          aria-label="Dashboard"
        >
          <LayoutDashboard className="w-4 h-4" />
          <span className="text-[10px] font-condensed uppercase tracking-wider mt-0.5">
            HQ
          </span>
        </button>

        <button
          onClick={() => handleNavigate('academy')}
          className={`flex flex-col items-center py-1 px-2 cursor-pointer transition-colors ${
            currentPage === 'academy' ? 'text-[#D7263D]' : 'text-[#777777]'
          }`}
          aria-label="Academy Curriculum"
        >
          <GraduationCap className="w-4 h-4" />
          <span className="text-[10px] font-condensed uppercase tracking-wider mt-0.5">
            CURRICULUM
          </span>
        </button>

        <button
          onClick={() => handleNavigate('training')}
          className={`flex flex-col items-center py-1 px-2 cursor-pointer transition-colors ${
            currentPage === 'training' ? 'text-[#D7263D]' : 'text-[#777777]'
          }`}
          aria-label="Training Pillars"
        >
          <Dumbbell className="w-4 h-4" />
          <span className="text-[10px] font-condensed uppercase tracking-wider mt-0.5">
            TRAIN
          </span>
        </button>

        <button
          onClick={() => handleNavigate('journal')}
          className={`flex flex-col items-center py-1 px-2 cursor-pointer transition-colors ${
            currentPage === 'journal' ? 'text-[#D7263D]' : 'text-[#777777]'
          }`}
          aria-label="Journal"
        >
          <ScrollText className="w-4 h-4" />
          <span className="text-[10px] font-condensed uppercase tracking-wider mt-0.5">
            LOG
          </span>
        </button>

        <button
          onClick={() => setMobileMenuOpen(true)}
          className="flex flex-col items-center py-1 px-2 text-[#777777] hover:text-[#F5F5F5] cursor-pointer"
          aria-label="All 10 Modules"
        >
          <Menu className="w-4 h-4" />
          <span className="text-[10px] font-condensed uppercase tracking-wider mt-0.5">
            ALL
          </span>
        </button>
      </div>

      {/* 7. Safety Codex Modal */}
      <SafetyModal
        isOpen={safetyModalOpen}
        onClose={() => setSafetyModalOpen(false)}
      />

      {/* 8. Admissions Onboarding Interview Modal */}
      <OnboardingModal
        isOpen={onboardingModalOpen}
        onClose={() => setOnboardingModalOpen(false)}
        existingProfile={appState.onboarding}
        onComplete={handleOnboardingComplete}
        canDismiss={Boolean(appState.onboarding)}
      />
    </div>
  );
}
