export type NavigationPage =
  | 'dashboard'
  | 'academy'
  | 'training'
  | 'techniques'
  | 'tactical'
  | 'journal'
  | 'video-review'
  | 'progression'
  | 'profile'
  | 'settings';

export type StanceType = 'Orthodox' | 'Southpaw' | 'Switch';

export interface FighterProfile {
  id: string;
  fullName: string;
  callsign: string;
  stance: StanceType;
  weightClass: string;
  division: string;
  reachInches: number;
  heightCm: number;
  currentLevel: number;
  currentXp: number;
  rankId: number;
  streakDays: number;
  totalRoundsLogged: number;
  totalHoursTrained: number;
  primaryFocus: string;
  joinedDate: string;
  safetyClearance: boolean;
  handWrapConfirmed: boolean;
}

export interface Rank {
  id: number;
  code: string;
  name: string;
  title: string;
  minLevel: number;
  maxLevel: number;
  insignia: string;
  description: string;
  tacticalFocus: string;
}

export interface CurriculumPhase {
  phaseNumber: number;
  romanId: string;
  title: string;
  subtitle: string;
  description: string;
  levelRange: [number, number];
  coreThemes: string[];
}

export interface CurriculumLevel {
  levelNumber: number;
  phaseNumber: number;
  title: string;
  subtitle: string;
  xpRequired: number;
  status: 'completed' | 'current' | 'locked';
  estimatedHours: number;
  drillsCount: number;
  keySkills: string[];
  benchmarkTest: string;
  lessonIds?: string[];
}

export interface TrainingPillar {
  id: string;
  code: string;
  name: string; // Conditioning and Movement | Offense and Punch Mechanics | Defense and Awareness | Technical Practice and Equipment Safety | Tactics and Boxing IQ | Recovery and Reflection
  shortDesc: string;
  description: string;
  drillsOverview: string[];
  importanceMetric: string;
  relatedConcepts?: string[];
}

export interface LessonKnowledgeCheck {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonItem {
  id: string;
  levelNumber: number;
  phaseNumber: number;
  title: string;
  description: string;
  pillars: string[];
  difficulty: 'Novice' | 'Fundamental' | 'Intermediate' | 'Advanced' | 'Mastery';
  estimatedDurationMin: number;
  prerequisiteLessonIds: string[];
  learningObjectives: string[];
  mainExplanation: string;
  conceptualBreakdown: { step: string; explanation: string }[];
  commonMistakes: string[];
  safetyConsiderations: string[];
  suggestedPractice: string;
  knowledgeCheck: LessonKnowledgeCheck[];
  reflectionPrompt: string;
  completionCriteria: string;
  xpReward: number;
  relatedLessonIds: string[];
  relatedTechniqueIds: string[];
}

export interface TechniqueItem {
  id: string;
  code: string;
  name: string;
  pillar: string;
  phase: number;
  category:
    | 'Stance & Guard'
    | 'Footwork'
    | 'Strikes & Mechanics'
    | 'Combinations'
    | 'Defense & Evasion'
    | 'Ring Awareness & Tactics'
    | 'Recovery & Training Safety'
    | 'Offense'
    | 'Defense'
    | 'Tactical Maneuver';
  difficulty: 'Novice' | 'Fundamental' | 'Intermediate' | 'Advanced' | 'Mastery';
  description: string;
  educationalExplanation?: string;
  biomechanics: string[];
  commonMistakes: string[];
  commonFaults?: string[];
  safetyConsiderations: string[];
  ringApplication: string;
  relatedLessonIds: string[];
  relatedTechniqueIds: string[];
}

export interface TacticalLegend {
  id: string;
  name: string;
  epithet: string;
  record: string;
  archetype: 'Out-Boxer' | 'Swarmer' | 'Slugger' | 'Boxer-Puncher' | 'Counter-Puncher';
  signatureAttributes: string[];
  masteryBreakdown: string;
  iconicHabits: string[];
  tacticalCounters: string;
}

export interface JournalSession {
  id: string;
  date: string;
  sessionType: 'Heavy Bag' | 'Shadowboxing' | 'Pads / Mitts' | 'Technical Sparring' | 'Conditioning & Roadwork' | 'Footwork Matrix';
  rounds: number;
  roundMinutes: number;
  intensity: 'Technical Recovery' | 'Moderate Cadence' | 'High Championship Intensity';
  focusPillar: string;
  notes: string;
  drillsCompleted: string[];
  xpEarned: number;
}

export interface VideoReviewItem {
  id: string;
  title: string;
  sourceFighters: string;
  category: 'Slip & Rip' | 'Footwork Angles' | 'High Guard Breakdown' | 'Distance Management' | 'Counter-Timing';
  durationMin: number;
  analysisFocus: string;
  keyTimestamps: { time: string; cue: string }[];
  annotated: boolean;
}

export interface AchievementItem {
  id: string;
  code: string;
  title: string;
  category: 'Discipline' | 'Technical' | 'Ring IQ' | 'Milestone';
  description: string;
  xpValue: number;
  unlocked: boolean;
  unlockedDate?: string;
  progressPercent: number;
}

export interface SafetyProtocol {
  id: string;
  title: string;
  severity: 'Mandatory' | 'Critical Rule' | 'Medical Advisory';
  rule: string;
  rationale: string;
}

export type BoxingExperience = 'complete_beginner' | 'some_experience' | 'experienced_learner';
export type LearningStyle = 'reading' | 'structured_drills' | 'video_study' | 'mixture';
export type SessionDurationOption = '15_30' | '30_45' | '45_60' | '60_plus';
export type PracticeEnvironment = 'home' | 'supervised_gym' | 'other';

export interface AccessibilityPreferences {
  highContrast: boolean;
  reducedMotion: boolean;
  audioBells: boolean;
}

export interface OnboardingProfile {
  displayName: string;
  experience: BoxingExperience;
  primaryGoals: string[];
  learningStyle: LearningStyle;
  availableDays: string[];
  sessionDuration: SessionDurationOption;
  equipment: string[];
  practiceEnvironment: PracticeEnvironment;
  favoriteTopics: string[];
  accessibilityPrefs: AccessibilityPreferences;
  trainingNotes: string;
  completedAt: string | null;
}

export interface RecommendedRoadmap {
  startingLevel: number;
  weeklyTargetSessions: number;
  targetSessionMinutes: number;
  cadenceDescription: string;
  recommendedLevels: CurriculumLevel[];
  primaryPillars: TrainingPillar[];
  recommendedTopics: string[];
  disclaimer: string;
}

export interface ActivityRecord {
  id: string;
  type: 'lesson_completed' | 'training_session' | 'study_notes' | 'onboarding_completed';
  title: string;
  subtitle: string;
  timestamp: string;
  xpEarned: number;
  targetPage?: NavigationPage;
  targetId?: string;
}

export interface KnowledgeCheckSubmission {
  passed: boolean;
  selectedAnswers: number[];
  reflectionText?: string;
  completedAt: string;
}

export interface AppState {
  onboarding: OnboardingProfile | null;
  fighter: FighterProfile;
  completedLevelIds: number[];
  completedLessonIds: string[];
  inProgressLessonIds: string[];
  knowledgeCheckResults: Record<string, KnowledgeCheckSubmission>;
  bookmarkedTechniqueIds: string[];
  bookmarkedLessonIds: string[];
  journalSessions: JournalSession[];
  activityHistory: ActivityRecord[];
  weeklyGoalSessions: number;
}


